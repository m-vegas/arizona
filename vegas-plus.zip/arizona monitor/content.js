(function () {
    'use strict';

    /* ============================================================
       CONFIG
       ============================================================ */
    const CONFIG = {
        REFRESH_INTERVAL: 60 * 1000,
        BATCH_SIZE: 10,
        FORUM_ORIGIN: 'https://forum.arizona-rp.com',
        DEV_ID: '882211',
        VERSION: 'v1.0',
        LINKS: { DISCORD: 'https://discord.gg/thmQmVSkT' },
        KEYS: {
            SECTIONS: 'arz_tracked_sections',
            DAYS: 'arz_stats_days',
            NICK: 'arz_user_nick',
            STATS_PARENT_URL: 'arz_stats_parent_url',
            STATS_SELECTED_SUBSECTIONS: 'arz_stats_selected_subsections',
            PROFILE: 'arz_user_profile',
            AUTHORIZED: 'arz_authorized_once',
            STATS_RESULT: 'arz_last_stats_result',
            INSTALL_DATE: 'arz_install_date',
            MINI_POS: 'arz_mini_pos',
            MODE: 'arz_ui_mode',
            THEME: 'arz_theme',
            NOTIF: 'arz_notifications',
            VISITS: 'arz_visits',
            SEEN_IDS: 'arz_seen_thread_ids',
            RECEIVED_IDS: 'arz_received_thread_ids',
            BASELINE_DONE: 'arz_baseline_done',
            FLAME_STREAK: 'arz_flame_streak',
            FLAME_BEST: 'arz_flame_best',
            FLAME_LAST: 'arz_flame_last',
            FLAME_TOTAL: 'arz_flame_total',
            DESKTOP_NOTIF: 'arz_desktop_notif',
            TG_CHAT_ID: 'arz_tg_chat_id',
            TG_USERNAME: 'arz_tg_username',
            TG_ENABLED: 'arz_tg_enabled'
        },
        PREFIX_CLOSED: new Set(['17', '18', '29', '30']),
        PREFIX_PENDING: new Set(['3'])
    };

    const THEMES = {
        blue:    { name: 'Синяя',       accent: '#3b82f6', accent2: '#60a5fa', glow: 'rgba(59,130,246,.5)',  effect: null },
        purple:  { name: 'Фиолетовая',  accent: '#8b5cf6', accent2: '#a78bfa', glow: 'rgba(139,92,246,.5)', effect: null },
        emerald: { name: 'Изумруд',     accent: '#10b981', accent2: '#34d399', glow: 'rgba(16,185,129,.5)', effect: null },
        rose:    { name: 'Роза',        accent: '#f43f5e', accent2: '#fb7185', glow: 'rgba(244,63,94,.5)',  effect: null },
        amber:   { name: 'Янтарь',      accent: '#f59e0b', accent2: '#fbbf24', glow: 'rgba(245,158,11,.5)', effect: null },
        neon:    { name: '⚡ Neon',      accent: '#e879f9', accent2: '#22d3ee', glow: 'rgba(232,121,249,.7)', effect: 'neon' },
        aurora:  { name: '🌌 Aurora',    accent: '#14b8a6', accent2: '#a78bfa', glow: 'rgba(20,184,166,.6)',  effect: 'aurora' },
        sunset:  { name: '🌅 Sunset',    accent: '#fb7185', accent2: '#fbbf24', glow: 'rgba(251,113,133,.6)', effect: 'sunset' },
        matrix:  { name: '🟢 Matrix',    accent: '#22c55e', accent2: '#4ade80', glow: 'rgba(34,197,94,.6)',   effect: 'matrix' },
        ice:     { name: '❄️ Ice',       accent: '#38bdf8', accent2: '#a5f3fc', glow: 'rgba(56,189,248,.6)',  effect: 'ice' }
    };

    const BADGES = [
        { id: 'dev', icon: '💎', name: 'Разработчик', tier: 'special',
          desc: 'Создатель Vegas+', how: 'Только для members/882211',
          check: c => c.userId === CONFIG.DEV_ID,
          progress: c => ({ now: c.userId === CONFIG.DEV_ID ? 1 : 0, max: 1 }) },
        { id: 'newbie', icon: '🌱', name: 'Новичок', tier: 'bronze',
          desc: 'Первая жалоба в мониторинге', how: 'Получи 1-ю жалобу',
          check: c => c.totalReceived >= 1,
          progress: c => ({ now: Math.min(c.totalReceived, 1), max: 1 }) },
        { id: 'active', icon: '🔥', name: 'Активист', tier: 'bronze',
          desc: 'Начало пути', how: 'Получи 10 жалоб',
          check: c => c.totalReceived >= 10,
          progress: c => ({ now: Math.min(c.totalReceived, 10), max: 10 }) },
        { id: 'pro', icon: '⚡', name: 'Профи', tier: 'silver',
          desc: 'Уверенный темп', how: 'Получи 50 жалоб',
          check: c => c.totalReceived >= 50,
          progress: c => ({ now: Math.min(c.totalReceived, 50), max: 50 }) },
        { id: 'expert', icon: '🏆', name: 'Эксперт', tier: 'gold',
          desc: 'Мастер мониторинга', how: 'Получи 100 жалоб',
          check: c => c.totalReceived >= 100,
          progress: c => ({ now: Math.min(c.totalReceived, 100), max: 100 }) },
        { id: 'sniper', icon: '🎯', name: 'Снайпер', tier: 'gold',
          desc: 'Всё видит', how: 'Получи 250 жалоб',
          check: c => c.totalReceived >= 250,
          progress: c => ({ now: Math.min(c.totalReceived, 250), max: 250 }) },
        { id: 'sheriff', icon: '🤠', name: 'Шериф', tier: 'platinum',
          desc: 'Гроза нарушителей', how: 'Получи 500 жалоб',
          check: c => c.totalReceived >= 500,
          progress: c => ({ now: Math.min(c.totalReceived, 500), max: 500 }) },
        { id: 'legend', icon: '👑', name: 'Легенда', tier: 'legendary',
          desc: 'Абсолютный лидер', how: 'Получи 1000 жалоб',
          check: c => c.totalReceived >= 1000,
          progress: c => ({ now: Math.min(c.totalReceived, 1000), max: 1000 }) },
        { id: 'watcher', icon: '🛡️', name: 'Страж', tier: 'silver',
          desc: 'Следит за порядком', how: 'Добавь 5+ разделов в мониторинг',
          check: c => c.sectionsCount >= 5,
          progress: c => ({ now: Math.min(c.sectionsCount, 5), max: 5 }) },
        { id: 'collector', icon: '🎁', name: 'Коллекционер', tier: 'gold',
          desc: 'Собирает всё', how: 'Открой 5 медалей',
          check: c => c.badgesCount >= 5,
          progress: c => ({ now: Math.min(c.badgesCount, 5), max: 5 }) },
        { id: 'early', icon: '🐦', name: 'Ранняя пташка', tier: 'silver',
          desc: 'Первым на форуме', how: 'Зайди на форум до 8:00 утра',
          check: c => c.earlyVisit,
          progress: c => ({ now: c.earlyVisit ? 1 : 0, max: 1 }) },
        { id: 'owl', icon: '🦉', name: 'Ночной страж', tier: 'silver',
          desc: 'Бодрствует ночью', how: 'Зайди на форум после 23:00',
          check: c => c.lateVisit,
          progress: c => ({ now: c.lateVisit ? 1 : 0, max: 1 }) },
        { id: 'loyal', icon: '⭐', name: 'Верный', tier: 'platinum',
          desc: 'Верен Vegas+', how: '30 дней с расширением',
          check: c => c.daysSinceInstall >= 30,
          progress: c => ({ now: Math.min(c.daysSinceInstall, 30), max: 30 }) },
        { id: 'flame', icon: '🔥', name: 'Пламя', tier: 'gold',
          desc: 'Зажёг огонь', how: 'Стрик пламени 7+ дней',
          check: c => c.flameStreak >= 7,
          progress: c => ({ now: Math.min(c.flameStreak, 7), max: 7 }) },
        { id: 'inferno', icon: '🌋', name: 'Инферно', tier: 'legendary',
          desc: 'Не гаснет никогда', how: 'Стрик пламени 30+ дней',
          check: c => c.flameStreak >= 30,
          progress: c => ({ now: Math.min(c.flameStreak, 30), max: 30 }) }
    ];

    /* ============================================================
       STORAGE
       ============================================================ */
    const Store = {
        _cache: {},
        async init() {
            const keys = Object.values(CONFIG.KEYS);
            this._cache = (await chrome.storage.local.get(keys)) || {};
            if (!this._cache[CONFIG.KEYS.INSTALL_DATE]) {
                this._cache[CONFIG.KEYS.INSTALL_DATE] = Date.now();
                chrome.storage.local.set({ [CONFIG.KEYS.INSTALL_DATE]: Date.now() });
            }
        },
        get(k, f) { return this._cache[k] !== undefined ? this._cache[k] : f; },
        set(k, v) { this._cache[k] = v; chrome.storage.local.set({ [k]: v }); }
    };

    const delay = ms => new Promise(r => setTimeout(r, ms));

    /* ============================================================
       HELPERS
       ============================================================ */
    function dateKey(d) {
        const y = d.getFullYear();
        const m = String(d.getMonth() + 1).padStart(2, '0');
        const day = String(d.getDate()).padStart(2, '0');
        return `${y}-${m}-${day}`;
    }

    function pluralRu(n, forms) {
        const m10 = n % 10, m100 = n % 100;
        if (m10 === 1 && m100 !== 11) return forms[0];
        if (m10 >= 2 && m10 <= 4 && (m100 < 10 || m100 >= 20)) return forms[1];
        return forms[2];
    }

    function escapeHtml(s) {
        return String(s || '').replace(/[&<>"']/g, c => ({
            '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
        })[c]);
    }

    /* ============================================================
       DESKTOP NOTIFICATIONS
       ============================================================ */
    let _notifIconUrl = null;

    function getNotifIcon() {
        if (_notifIconUrl) return _notifIconUrl;
        try {
            const c = document.createElement('canvas');
            c.width = 128; c.height = 128;
            const ctx = c.getContext('2d');
            const g = ctx.createLinearGradient(0, 0, 128, 128);
            g.addColorStop(0, '#f97316');
            g.addColorStop(1, '#dc2626');
            ctx.fillStyle = g;
            ctx.beginPath();
            if (ctx.roundRect) ctx.roundRect(0, 0, 128, 128, 28); else ctx.rect(0, 0, 128, 128);
            ctx.fill();
            ctx.fillStyle = '#fff';
            ctx.beginPath(); ctx.arc(64, 64, 38, 0, Math.PI * 2); ctx.fill();
            ctx.fillStyle = '#1a1a1a';
            ctx.beginPath(); ctx.arc(50, 54, 5.5, 0, Math.PI * 2); ctx.fill();
            ctx.beginPath(); ctx.arc(78, 54, 5.5, 0, Math.PI * 2); ctx.fill();
            ctx.strokeStyle = '#1a1a1a';
            ctx.lineWidth = 6; ctx.lineCap = 'round';
            ctx.beginPath(); ctx.arc(64, 72, 22, 0.15 * Math.PI, 0.85 * Math.PI); ctx.stroke();
            _notifIconUrl = c.toDataURL('image/png');
            return _notifIconUrl;
        } catch { return ''; }
    }

    function sendDesktopNotification(title, message) {
        try {
            chrome.runtime.sendMessage({
                type: 'ARZ_NOTIFY',
                title, message,
                icon: getNotifIcon()
            }, () => { void chrome.runtime.lastError; });
        } catch (_) {}
    }

    /* ============================================================
       FLAME STREAK
       ============================================================ */
    function getFlameState() {
        return {
            streak: Store.get(CONFIG.KEYS.FLAME_STREAK, 0) || 0,
            best: Store.get(CONFIG.KEYS.FLAME_BEST, 0) || 0,
            last: Store.get(CONFIG.KEYS.FLAME_LAST, '') || '',
            total: Store.get(CONFIG.KEYS.FLAME_TOTAL, 0) || 0
        };
    }

    function getFlameDisplay() {
        const s = getFlameState();
        const today = dateKey(new Date());
        const yesterday = dateKey(new Date(Date.now() - 86400000));
        const checkedToday = s.last === today;
        const alive = s.last === today || s.last === yesterday;
        return { streak: alive ? s.streak : 0, best: s.best, total: s.total, checkedToday, alive };
    }

    function getFlameLevel(streak) {
        if (streak === 0) return 0;
        if (streak < 3) return 1;
        if (streak < 7) return 2;
        if (streak < 14) return 3;
        if (streak < 30) return 4;
        return 5;
    }

    function getFlameThresholds() { return [0, 1, 3, 7, 14, 30]; }

    function checkInFlame() {
        const s = getFlameState();
        const today = dateKey(new Date());
        const yesterday = dateKey(new Date(Date.now() - 86400000));
        if (s.last === today) { addNotification('🔥 Уже отмечено', 'Приходи завтра!', 'warn', '🔥'); return; }

        const prevStreak = s.streak;
        const newStreak = s.last === yesterday ? s.streak + 1 : 1;
        const newBest = Math.max(s.best, newStreak);
        const newTotal = s.total + 1;

        Store.set(CONFIG.KEYS.FLAME_STREAK, newStreak);
        Store.set(CONFIG.KEYS.FLAME_BEST, newBest);
        Store.set(CONFIG.KEYS.FLAME_LAST, today);
        Store.set(CONFIG.KEYS.FLAME_TOTAL, newTotal);

        const prevLevel = getFlameLevel(prevStreak);
        const newLevel = getFlameLevel(newStreak);

        if (newLevel > prevLevel) {
            addNotification(`🔥 Пламя выросло до уровня ${newLevel}!`,
                `Стрик: ${newStreak} ${pluralRu(newStreak, ['день','дня','дней'])} подряд`, 'badge', '🔥');
        } else if (newStreak === 1 && prevStreak > 1) {
            addNotification('🔥 Пламя зажжено заново',
                `Прошлый стрик был ${prevStreak} дн.`, 'warn', '🔥');
        } else {
            addNotification('🔥 Отмечено!',
                `Стрик: ${newStreak} ${pluralRu(newStreak, ['день','дня','дней'])}`, 'success', '🔥');
        }

        checkNewBadges();
        renderView();
    }

    /* ============================================================
       TELEGRAM
       ============================================================ */
    const TG_BOT = 'vegas_notification_bot';
    const TG_URL = `https://t.me/${TG_BOT}`;

    function isTgConnected() {
        return !!Store.get(CONFIG.KEYS.TG_CHAT_ID, null);
    }

    function getTgInfo() {
        return {
            chatId: Store.get(CONFIG.KEYS.TG_CHAT_ID, null),
            username: Store.get(CONFIG.KEYS.TG_USERNAME, ''),
            enabled: Store.get(CONFIG.KEYS.TG_ENABLED, true)
        };
    }

    function genConnectCode() {
        return String(Math.floor(100000 + Math.random() * 900000));
    }

    async function connectTelegram() {
        const code = genConnectCode();
        showTgModal(code);

        try {
            const res = await new Promise(resolve => {
                chrome.runtime.sendMessage({ type: 'TG_POLL_CONNECT', code, timeout: 90000 }, r => {
                    if (chrome.runtime.lastError) return resolve({ ok: false, error: chrome.runtime.lastError.message });
                    resolve(r || { ok: false });
                });
            });

            if (res.ok) {
                Store.set(CONFIG.KEYS.TG_CHAT_ID, res.chatId);
                Store.set(CONFIG.KEYS.TG_USERNAME, res.username || res.firstName || '');
                Store.set(CONFIG.KEYS.TG_ENABLED, true);
                showTgModalSuccess(res);
                setTimeout(() => {
                    hideTgModal();
                    if (currentView === 'settings') renderView();
                }, 2200);
                addNotification('✈️ Telegram подключён',
                    res.username ? `Уведомления будут приходить на @${res.username}` : 'Уведомления включены',
                    'success', '✈️');
            } else if (res.error === 'timeout') {
                showTgModalTimeout();
                addNotification('✈️ Telegram', 'Таймаут подключения. Попробуйте ещё раз', 'warn', '✈️');
            } else if (res.error === 'cancelled') {
                hideTgModal();
            } else {
                showTgModalError(res.error || 'Ошибка');
                addNotification('✈️ Telegram', 'Не удалось подключить: ' + (res.error || ''), 'error', '✈️');
            }
        } catch (e) {
            showTgModalError(String(e));
        }
    }

    function disconnectTelegram() {
        Store.set(CONFIG.KEYS.TG_CHAT_ID, null);
        Store.set(CONFIG.KEYS.TG_USERNAME, '');
        Store.set(CONFIG.KEYS.TG_ENABLED, false);
        addNotification('✈️ Telegram отключён', 'Уведомления больше не приходят', 'info', '✈️');
        renderView();
    }

    function toggleTg() {
        if (!isTgConnected()) return;
        const cur = Store.get(CONFIG.KEYS.TG_ENABLED, true);
        Store.set(CONFIG.KEYS.TG_ENABLED, !cur);
        renderView();
    }

    function sendTelegramNotification(title, text, url) {
        const info = getTgInfo();
        if (!info.chatId || !info.enabled) return;
        const html = `<b>${escapeHtml(title)}</b>\n\n${escapeHtml(text)}${url ? `\n\n<a href="${url}">Открыть жалобу</a>` : ''}`;
        try {
            chrome.runtime.sendMessage({
                type: 'TG_SEND',
                chatId: info.chatId,
                text: html
            }, () => { void chrome.runtime.lastError; });
        } catch (_) {}
    }

    let tgModalEl = null;

    function ensureTgModal() {
        if (tgModalEl) return tgModalEl;
        const wrap = document.createElement('div');
        wrap.className = 'vp-tg-modal';
        wrap.innerHTML = `
            <div class="vp-tg-modal-card">
                <button class="vp-tg-modal-close" id="vp-tg-close">${ICONS.x}</button>
                <div id="vp-tg-modal-content"></div>
            </div>`;
        appEl.appendChild(wrap);
        wrap.querySelector('#vp-tg-close').onclick = () => {
            try { chrome.runtime.sendMessage({ type: 'TG_POLL_CANCEL' }, () => { void chrome.runtime.lastError; }); } catch (_) {}
            hideTgModal();
        };
        tgModalEl = wrap;
        return wrap;
    }

    function showTgModal(code) {
        ensureTgModal();
        const content = tgModalEl.querySelector('#vp-tg-modal-content');
        content.innerHTML = `
            <div class="vp-tg-head">
                <div class="vp-tg-icon">
                    <svg viewBox="0 0 24 24" fill="currentColor"><path d="M9.78 18.65l.28-4.23 7.68-6.92c.34-.31-.07-.46-.52-.19L7.74 13.3 3.64 12c-.88-.25-.89-.86.2-1.3l15.97-6.16c.73-.33 1.43.18 1.15 1.3l-2.72 12.81c-.19.91-.74 1.13-1.5.71L12.6 16.3l-1.99 1.93c-.23.23-.42.42-.83.42z"/></svg>
                </div>
                <div class="vp-tg-title">Подключение Telegram</div>
                <div class="vp-tg-sub">Уведомления о новых жалобах на твой ник прямо в Telegram</div>
            </div>

            <div class="vp-tg-steps">
                <div class="vp-tg-step">
                    <div class="vp-tg-step-num">1</div>
                    <div class="vp-tg-step-text">Открой бота <b>@${TG_BOT}</b> и нажми <b>Start</b></div>
                </div>
                <div class="vp-tg-step">
                    <div class="vp-tg-step-num">2</div>
                    <div class="vp-tg-step-text">Отправь боту команду:</div>
                </div>
            </div>

            <div class="vp-tg-code">
                <code id="vp-tg-code-text">/connect ${code}</code>
                <button class="vp-tg-copy" id="vp-tg-copy" title="Скопировать">Копировать</button>
            </div>

            <div class="vp-tg-actions">
                <a class="vp-btn vp-tg-btn-primary" href="${TG_URL}" target="_blank">
                    <svg viewBox="0 0 24 24" fill="currentColor" style="width:16px;height:16px;"><path d="M9.78 18.65l.28-4.23 7.68-6.92c.34-.31-.07-.46-.52-.19L7.74 13.3 3.64 12c-.88-.25-.89-.86.2-1.3l15.97-6.16c.73-.33 1.43.18 1.15 1.3l-2.72 12.81c-.19.91-.74 1.13-1.5.71L12.6 16.3l-1.99 1.93c-.23.23-.42.42-.83.42z"/></svg>
                    Открыть @${TG_BOT}
                </a>
            </div>

            <div class="vp-tg-waiting" id="vp-tg-waiting">
                <div class="vp-tg-waiting-dots"><span></span><span></span><span></span></div>
                <div class="vp-tg-waiting-text">Ожидание подключения…</div>
            </div>`;

        content.querySelector('#vp-tg-copy').onclick = () => {
            const txt = content.querySelector('#vp-tg-code-text').textContent;
            navigator.clipboard.writeText(txt).then(() => {
                content.querySelector('#vp-tg-copy').textContent = '✓ Скопировано';
                setTimeout(() => {
                    const btn = content.querySelector('#vp-tg-copy');
                    if (btn) btn.textContent = 'Копировать';
                }, 1500);
            }).catch(() => {});
        };

        tgModalEl.classList.add('vp-open');
        requestAnimationFrame(() => tgModalEl.classList.add('vp-visible'));
    }

    function showTgModalSuccess(res) {
        if (!tgModalEl) return;
        const content = tgModalEl.querySelector('#vp-tg-modal-content');
        content.innerHTML = `
            <div class="vp-tg-head vp-tg-success-head">
                <div class="vp-tg-icon vp-tg-icon-success">
                    <svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
                </div>
                <div class="vp-tg-title">Telegram подключён!</div>
                <div class="vp-tg-sub">${res.username ? 'Аккаунт: <b>@' + escapeHtml(res.username) + '</b>' : 'Уведомления активированы'}</div>
            </div>`;
    }

    function showTgModalTimeout() {
        if (!tgModalEl) return;
        const content = tgModalEl.querySelector('#vp-tg-modal-content');
        content.innerHTML = `
            <div class="vp-tg-head">
                <div class="vp-tg-icon vp-tg-icon-warn">⏱</div>
                <div class="vp-tg-title">Время вышло</div>
                <div class="vp-tg-sub">Сообщение от бота не пришло. Проверь правильность команды и попробуй снова.</div>
            </div>
            <div class="vp-tg-actions">
                <button class="vp-btn vp-tg-btn-primary" id="vp-tg-retry">Попробовать снова</button>
            </div>`;
        content.querySelector('#vp-tg-retry').onclick = () => {
            hideTgModal();
            setTimeout(() => connectTelegram(), 250);
        };
    }

    function showTgModalError(err) {
        if (!tgModalEl) return;
        const content = tgModalEl.querySelector('#vp-tg-modal-content');
        content.innerHTML = `
            <div class="vp-tg-head">
                <div class="vp-tg-icon vp-tg-icon-error">✕</div>
                <div class="vp-tg-title">Ошибка подключения</div>
                <div class="vp-tg-sub">${escapeHtml(err)}</div>
            </div>
            <div class="vp-tg-actions">
                <button class="vp-btn vp-tg-btn-primary" id="vp-tg-retry">Попробовать снова</button>
            </div>`;
        content.querySelector('#vp-tg-retry').onclick = () => {
            hideTgModal();
            setTimeout(() => connectTelegram(), 250);
        };
    }

    function hideTgModal() {
        if (!tgModalEl) return;
        tgModalEl.classList.remove('vp-visible');
        setTimeout(() => tgModalEl?.classList.remove('vp-open'), 250);
    }

    /* ============================================================
       CSS
       ============================================================ */
    const CSS = `
    :host { all: initial; }
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

    .vp-scope {
        --accent: #3b82f6;
        --accent-2: #60a5fa;
        --accent-glow: rgba(59,130,246,.5);
        --bg-app: #0a0e1a;
        --bg-side: #070a13;
        --bg-card: #0f1424;
        --bg-card-2: #161c2e;
        --border: #1e2740;
        --border-2: #2a3352;
        --text: #e8ecf5;
        --text-dim: #8b93a8;
        --text-mute: #4d5570;
    }
    .vp-scope[data-theme="purple"]  { --accent:#8b5cf6; --accent-2:#a78bfa; --accent-glow:rgba(139,92,246,.5); }
    .vp-scope[data-theme="emerald"] { --accent:#10b981; --accent-2:#34d399; --accent-glow:rgba(16,185,129,.5); }
    .vp-scope[data-theme="rose"]    { --accent:#f43f5e; --accent-2:#fb7185; --accent-glow:rgba(244,63,94,.5); }
    .vp-scope[data-theme="amber"]   { --accent:#f59e0b; --accent-2:#fbbf24; --accent-glow:rgba(245,158,11,.5); }
    .vp-scope[data-theme="neon"]    { --accent:#e879f9; --accent-2:#22d3ee; --accent-glow:rgba(232,121,249,.8); }
    .vp-scope[data-theme="aurora"]  { --accent:#14b8a6; --accent-2:#a78bfa; --accent-glow:rgba(20,184,166,.7); }
    .vp-scope[data-theme="sunset"]  { --accent:#fb7185; --accent-2:#fbbf24; --accent-glow:rgba(251,113,133,.7); }
    .vp-scope[data-theme="matrix"]  { --accent:#22c55e; --accent-2:#4ade80; --accent-glow:rgba(34,197,94,.7); }
    .vp-scope[data-theme="ice"]     { --accent:#38bdf8; --accent-2:#a5f3fc; --accent-glow:rgba(56,189,248,.7); }

    .vp-scope[data-theme="neon"] .vp-side-logo-icon,
    .vp-scope[data-theme="neon"] .vp-btn.vp-primary {
        box-shadow: 0 0 20px var(--accent-glow), 0 0 40px var(--accent-glow), inset 0 0 12px rgba(255,255,255,.1);
    }
    .vp-scope[data-theme="aurora"] .vp-app::before {
        content: ''; position: absolute; inset: 0; pointer-events: none; border-radius: 20px;
        background:
            radial-gradient(ellipse 60% 40% at 20% 0%, var(--accent-glow), transparent 60%),
            radial-gradient(ellipse 50% 40% at 100% 100%, rgba(167,139,250,.25), transparent 60%);
        animation: vp-aurora 12s ease-in-out infinite alternate;
        z-index: 0; opacity: .5;
    }
    @keyframes vp-aurora {
        0%   { transform: translate(0,0) scale(1);   opacity: .4; }
        50%  { transform: translate(-4%,2%) scale(1.05); opacity: .6; }
        100% { transform: translate(3%,-2%) scale(1);  opacity: .4; }
    }
    .vp-scope[data-theme="sunset"] .vp-app::before {
        content: ''; position: absolute; inset: 0; pointer-events: none; border-radius: 20px;
        background: linear-gradient(135deg, rgba(251,113,133,.14), rgba(251,191,36,.1) 50%, transparent 90%);
        z-index: 0;
    }
    .vp-scope[data-theme="matrix"] .vp-app::before {
        content: ''; position: absolute; inset: 0; pointer-events: none; border-radius: 20px;
        background-image: repeating-linear-gradient(0deg, rgba(34,197,94,.05) 0 1px, transparent 1px 3px);
        z-index: 0; animation: vp-matrix 8s linear infinite;
    }
    @keyframes vp-matrix { to { background-position: 0 100px; } }
    .vp-scope[data-theme="ice"] .vp-app::before {
        content: ''; position: absolute; inset: 0; pointer-events: none; border-radius: 20px;
        background: radial-gradient(circle at 30% -20%, rgba(165,243,252,.15), transparent 60%),
                    radial-gradient(circle at 80% 120%, rgba(56,189,248,.12), transparent 55%);
        z-index: 0;
    }
    .vp-app > * { position: relative; z-index: 1; }

    .vp-backdrop {
        position: fixed; inset: 0; z-index: 2147483644;
        background: rgba(4, 6, 12, 0.72);
        backdrop-filter: blur(8px); -webkit-backdrop-filter: blur(8px);
        opacity: 0; pointer-events: none; transition: opacity .3s;
    }
    .vp-backdrop.vp-show { opacity: 1; pointer-events: auto; }

    /* ============ SPLASH ============ */
    .vp-splash {
        position: fixed; inset: 0; z-index: 2147483647;
        display: flex; align-items: center; justify-content: center;
        background:
            radial-gradient(ellipse 80% 60% at 50% 0%, rgba(59,130,246,.16), transparent 60%),
            radial-gradient(ellipse 70% 50% at 50% 100%, rgba(139,92,246,.14), transparent 60%),
            rgba(4, 6, 12, 0.88);
        backdrop-filter: blur(22px) saturate(150%);
        -webkit-backdrop-filter: blur(22px) saturate(150%);
        opacity: 0; transition: opacity .45s ease;
        font-family: -apple-system, BlinkMacSystemFont, "SF Pro Text", "Segoe UI", Roboto, sans-serif;
        color: #e6e8ee; overflow: hidden;
    }
    .vp-splash.vp-show { opacity: 1; }
    .vp-splash.vp-hide { opacity: 0; pointer-events: none; }
    .vp-splash-particles { position: absolute; inset: 0; pointer-events: none; overflow: hidden; }
    .vp-splash-particle {
        position: absolute; bottom: -20px;
        border-radius: 50%;
        background: var(--accent-2);
        box-shadow: 0 0 10px var(--accent-2), 0 0 20px var(--accent-glow);
        opacity: 0;
        animation: vp-particle-rise 6s linear infinite;
    }
    @keyframes vp-particle-rise {
        0%   { transform: translateY(0) scale(.4); opacity: 0; }
        15%  { opacity: 1; }
        85%  { opacity: .9; }
        100% { transform: translateY(-110vh) scale(1.1); opacity: 0; }
    }
    .vp-splash-card {
        position: relative;
        width: 400px; padding: 34px 30px 26px;
        border-radius: 24px;
        background: linear-gradient(180deg, rgba(28,30,40,.96), rgba(16,18,24,.96));
        border: 1px solid #2e323e;
        box-shadow:
            0 40px 100px -20px rgba(0,0,0,.9),
            0 0 0 1px rgba(255,255,255,.03),
            inset 0 1px 0 rgba(255,255,255,.06),
            0 0 60px -10px var(--accent-glow);
        display: flex; flex-direction: column; align-items: center; gap: 16px;
        transform: translateY(16px) scale(.96);
        transition: transform .55s cubic-bezier(.34, 1.56, .64, 1);
    }
    .vp-splash.vp-show .vp-splash-card { transform: none; }
    .vp-splash-logo-wrap { position: relative; width: 96px; height: 96px; display: flex; align-items: center; justify-content: center; }
    .vp-splash-ring {
        position: absolute; inset: 0;
        border-radius: 26px;
        border: 2px solid var(--accent-2);
        pointer-events: none;
        opacity: 0;
        animation: vp-ring-out 2.6s ease-out infinite;
    }
    .vp-splash-ring:nth-child(2) { animation-delay: .85s; }
    .vp-splash-ring:nth-child(3) { animation-delay: 1.7s; }
    @keyframes vp-ring-out {
        0%   { transform: scale(1);   opacity: .7; }
        100% { transform: scale(2.3); opacity: 0; }
    }
    .vp-splash-logo {
        width: 82px; height: 82px; border-radius: 24px;
        background: linear-gradient(135deg, var(--accent-2), var(--accent));
        display: flex; align-items: center; justify-content: center;
        box-shadow: 0 18px 40px -10px var(--accent-glow), 0 0 40px -8px var(--accent-glow), inset 0 2px 0 rgba(255,255,255,.25);
        position: relative;
        animation: vp-float 2.6s ease-in-out infinite;
        z-index: 2;
    }
    @keyframes vp-float { 0%,100% { transform: translateY(0); } 50% { transform: translateY(-5px); } }
    .vp-splash-logo svg { width: 46px; height: 46px; filter: drop-shadow(0 2px 6px rgba(0,0,0,.35)); }
    .vp-splash-title {
        font-size: 24px; font-weight: 700; letter-spacing: -.02em;
        background: linear-gradient(135deg, #fff 30%, #c7b8ff);
        -webkit-background-clip: text; background-clip: text; -webkit-text-fill-color: transparent;
        text-align: center;
    }
    .vp-splash-tagline {
        font-size: 10.5px; color: var(--text-mute);
        letter-spacing: .14em; font-weight: 700; text-transform: uppercase;
        margin-top: -10px;
    }
    .vp-splash-sub {
        font-size: 12.5px; color: #8b90a0; text-align: center; line-height: 1.5;
        min-height: 36px; padding: 0 8px;
    }
    .vp-splash-sub b { color: var(--accent-2); font-weight: 600; }
    .vp-splash-bar { width: 100%; height: 5px; border-radius: 5px; background: #1b1e26; overflow: hidden; position: relative; }
    .vp-splash-bar-fill {
        position: absolute; top: 0; left: 0; height: 100%; width: 0%;
        border-radius: 5px;
        background: linear-gradient(90deg, var(--accent), var(--accent-2));
        box-shadow: 0 0 14px var(--accent-glow);
        transition: width .5s cubic-bezier(.4,0,.2,1);
        overflow: hidden;
    }
    .vp-splash-bar-fill::after {
        content: ''; position: absolute; inset: 0;
        background: linear-gradient(90deg, transparent, rgba(255,255,255,.55), transparent);
        animation: vp-shimmer 1.4s linear infinite;
    }
    @keyframes vp-shimmer { 0% { transform: translateX(-100%); } 100% { transform: translateX(100%); } }
    .vp-splash-steps { display: flex; flex-direction: column; gap: 7px; width: 100%; margin-top: 4px; }
    .vp-step { display: flex; align-items: center; gap: 9px; font-size: 11px; color: #5c6172; transition: color .3s; }
    .vp-step-dot {
        width: 7px; height: 7px; border-radius: 50%;
        background: #2e323e; flex-shrink: 0;
        transition: all .3s; position: relative;
    }
    .vp-step.vp-active { color: #e6e8ee; }
    .vp-step.vp-active .vp-step-dot {
        background: var(--accent-2);
        box-shadow: 0 0 10px var(--accent-2), 0 0 20px var(--accent-glow);
        animation: vp-dot-pulse 1.2s ease-in-out infinite;
    }
    @keyframes vp-dot-pulse {
        0%,100% { transform: scale(1); opacity: 1; }
        50%     { transform: scale(1.35); opacity: .55; }
    }
    .vp-step.vp-done { color: #8b90a0; }
    .vp-step.vp-done .vp-step-dot {
        background: #34d399;
        box-shadow: 0 0 8px rgba(52,211,153,.7);
        animation: vp-dot-done .4s ease-out;
    }
    @keyframes vp-dot-done { 0% { transform: scale(.4); } 60% { transform: scale(1.5); } 100% { transform: scale(1); } }
    .vp-splash-footer {
        margin-top: 6px;
        font-size: 10px; color: #4a4f5e;
        letter-spacing: .1em; text-transform: uppercase; font-weight: 700;
        display: flex; align-items: center; gap: 6px;
    }
    .vp-splash-footer-dot {
        width: 5px; height: 5px; border-radius: 50%;
        background: var(--accent-2);
        box-shadow: 0 0 8px var(--accent-2);
        animation: vp-dot-pulse 1.5s ease-in-out infinite;
    }

    /* ============ APP ============ */
    .vp-app {
        position: fixed; top: 50%; left: 50%;
        transform: translate(-50%, -50%) scale(.96);
        width: min(1000px, calc(100vw - 60px));
        height: min(760px, calc(100vh - 60px));
        z-index: 2147483645;
        background: var(--bg-app);
        border: 1px solid var(--border);
        border-radius: 20px;
        box-shadow: 0 40px 100px -20px rgba(0,0,0,.9), 0 0 0 1px rgba(255,255,255,.02);
        display: none;
        grid-template-columns: 220px 1fr;
        overflow: hidden;
        color: var(--text);
        font: 13px/1.5 -apple-system, BlinkMacSystemFont, "SF Pro Text", "Segoe UI", Roboto, sans-serif;
        opacity: 0;
        transition: opacity .3s, transform .3s cubic-bezier(.4,0,.2,1);
        -webkit-font-smoothing: antialiased;
    }
    .vp-app.vp-open { display: grid; }
    .vp-app.vp-visible { opacity: 1; transform: translate(-50%, -50%) scale(1); }

    ::-webkit-scrollbar { width: 8px; height: 8px; }
    ::-webkit-scrollbar-track { background: transparent; }
    ::-webkit-scrollbar-thumb { background: #1e2740; border-radius: 8px; }
    ::-webkit-scrollbar-thumb:hover { background: #2a3352; }

    .vp-side {
        background: var(--bg-side);
        border-right: 1px solid var(--border);
        display: flex; flex-direction: column;
        padding: 20px 0 14px;
        min-height: 0;
    }
    .vp-side-logo { padding: 0 18px 20px; display: flex; align-items: center; gap: 11px; }
    .vp-side-logo-icon {
        width: 42px; height: 42px; border-radius: 12px; flex-shrink: 0;
        display: flex; align-items: center; justify-content: center;
        background: linear-gradient(135deg, var(--accent-2), var(--accent));
        box-shadow: 0 6px 18px -4px var(--accent-glow), inset 0 1px 0 rgba(255,255,255,.25);
        position: relative; overflow: hidden;
    }
    .vp-side-logo-icon svg { width: 100%; height: 100%; display: block; }
    .vp-side-logo-text { min-width: 0; }
    .vp-side-logo-title {
        font-size: 14px; font-weight: 700; color: #fff;
        letter-spacing: -.01em; line-height: 1.1;
        white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
    }
    .vp-side-logo-version {
        display: inline-block; font-size: 9px; font-weight: 700;
        color: var(--text-dim); background: var(--bg-card);
        padding: 2px 6px; border-radius: 5px; margin-top: 4px;
        letter-spacing: .05em; border: 1px solid var(--border);
    }
    .vp-side-section {
        padding: 4px 20px 8px;
        font-size: 10px; color: var(--text-mute);
        letter-spacing: .12em; font-weight: 700;
        text-transform: uppercase;
    }
    .vp-side-nav { padding: 0 10px; display: flex; flex-direction: column; gap: 2px; }
    .vp-nav-item {
        display: flex; align-items: center; gap: 10px;
        padding: 9px 11px; border-radius: 9px;
        background: transparent; border: 1px solid transparent;
        color: var(--text-dim);
        cursor: pointer; font: inherit; font-size: 12px; font-weight: 500;
        text-align: left; width: 100%; transition: all .15s;
        font-family: inherit;
    }
    .vp-nav-item:hover { background: var(--bg-card); color: var(--text); }
    .vp-nav-item.vp-active {
        background: color-mix(in srgb, var(--accent) 14%, transparent);
        color: var(--accent-2);
        box-shadow: inset 0 0 0 1px var(--accent);
    }
    .vp-nav-item svg { width: 15px; height: 15px; flex-shrink: 0; }
    .vp-nav-item .vp-dev-chip {
        margin-left: auto; font-size: 8.5px; font-weight: 800;
        padding: 2px 5px; border-radius: 4px;
        background: rgba(245,158,11,.15); color: #fbbf24;
        border: 1px solid rgba(245,158,11,.3);
        letter-spacing: .04em;
    }
    .vp-side-bottom {
        margin-top: auto; padding: 12px 10px 0;
        display: flex; flex-direction: column; gap: 6px;
    }
    .vp-side-link {
        display: flex; align-items: center; gap: 10px;
        padding: 10px 12px; border-radius: 10px;
        background: linear-gradient(135deg, rgba(88,101,242,.12), rgba(88,101,242,.04));
        border: 1px solid rgba(88,101,242,.3);
        color: #a5b4fc; font-size: 11.5px; font-weight: 600;
        cursor: pointer; text-decoration: none; transition: all .15s;
    }
    .vp-side-link svg { width: 16px; height: 16px; flex-shrink: 0; }
    .vp-side-link:hover { background: rgba(88,101,242,.18); border-color: rgba(88,101,242,.55); color: #c7d2fe; }
    .vp-side-collapse {
        display: flex; align-items: center; gap: 10px;
        padding: 10px 12px; border-radius: 10px;
        background: transparent; border: 1px solid transparent;
        color: var(--text-dim); cursor: pointer; font: inherit;
        font-size: 11.5px; font-weight: 500;
        transition: all .15s; font-family: inherit;
    }
    .vp-side-collapse:hover { background: var(--bg-card); color: var(--text); }

    .vp-main { display: flex; flex-direction: column; overflow: hidden; min-height: 0; position: relative; }
    .vp-topbar {
        display: flex; align-items: center; justify-content: space-between;
        padding: 12px 20px;
        border-bottom: 1px solid var(--border);
        flex-shrink: 0; position: relative;
    }
    .vp-topbar-left { display: flex; align-items: center; gap: 8px; }
    .vp-topbar-btn {
        width: 38px; height: 38px; border-radius: 10px;
        background: var(--bg-card); border: 1px solid var(--border);
        color: var(--text-dim); cursor: pointer;
        display: flex; align-items: center; justify-content: center;
        transition: all .15s; position: relative;
    }
    .vp-topbar-btn:hover { background: var(--bg-card-2); color: var(--text); border-color: var(--border-2); }
    .vp-topbar-btn svg { width: 17px; height: 17px; }
    .vp-topbar-right { display: flex; align-items: center; gap: 10px; }
    .vp-bell-badge {
        position: absolute; top: -3px; right: -3px;
        min-width: 18px; height: 18px; padding: 0 5px;
        border-radius: 9px; background: #ef4444; color: #fff;
        font-size: 10px; font-weight: 700;
        display: none; align-items: center; justify-content: center;
        border: 2px solid var(--bg-app);
        box-shadow: 0 2px 8px rgba(239,68,68,.5);
    }
    .vp-bell-badge.vp-show { display: flex; }
    .vp-notif-panel {
        position: absolute; top: 62px; right: 20px;
        width: 360px; max-height: 420px;
        background: var(--bg-card);
        border: 1px solid var(--border-2);
        border-radius: 14px;
        box-shadow: 0 24px 60px -12px rgba(0,0,0,.85), 0 0 0 1px rgba(255,255,255,.03);
        z-index: 100; display: none; flex-direction: column; overflow: hidden;
        opacity: 0; transform: translateY(-8px);
        transition: opacity .2s, transform .2s;
    }
    .vp-notif-panel.vp-open { display: flex; }
    .vp-notif-panel.vp-visible { opacity: 1; transform: none; }
    .vp-notif-head {
        display: flex; align-items: center; justify-content: space-between;
        padding: 12px 14px;
        border-bottom: 1px solid var(--border);
        font-size: 12px; font-weight: 600; color: var(--text);
    }
    .vp-notif-clear {
        background: transparent; border: none;
        color: var(--text-mute); font-size: 11px; cursor: pointer;
        padding: 4px 8px; border-radius: 6px; transition: all .15s;
        font-family: inherit;
    }
    .vp-notif-clear:hover { background: var(--bg-card-2); color: var(--text); }
    .vp-notif-list {
        overflow-y: auto; flex: 1;
        display: flex; flex-direction: column;
        padding: 6px;
    }
    .vp-notif-item {
        display: flex; gap: 10px;
        padding: 10px; border-radius: 9px;
        transition: background .15s; position: relative;
    }
    .vp-notif-item:hover { background: var(--bg-card-2); }
    .vp-notif-item.vp-unread::before {
        content: ''; position: absolute; left: 3px; top: 50%;
        transform: translateY(-50%);
        width: 3px; height: 60%;
        background: var(--accent); border-radius: 2px;
    }
    .vp-notif-icon {
        width: 30px; height: 30px; border-radius: 8px; flex-shrink: 0;
        display: flex; align-items: center; justify-content: center;
        background: var(--bg-app); color: var(--accent-2);
        font-size: 15px;
    }
    .vp-notif-icon.vp-success { color: #34d399; }
    .vp-notif-icon.vp-error   { color: #f87171; }
    .vp-notif-icon.vp-warn    { color: #f59e0b; }
    .vp-notif-icon.vp-badge   { color: #eab308; }
    .vp-notif-body { flex: 1; min-width: 0; }
    .vp-notif-title { font-size: 12px; font-weight: 600; color: var(--text); line-height: 1.3; }
    .vp-notif-text { font-size: 11.5px; color: var(--text-dim); margin-top: 2px; line-height: 1.4; }
    .vp-notif-time { font-size: 10px; color: var(--text-mute); margin-top: 4px; }
    .vp-notif-empty {
        padding: 40px 20px; text-align: center;
        color: var(--text-mute); font-size: 12px;
    }
    .vp-user-chip {
        display: flex; align-items: center; gap: 10px;
        padding: 4px 4px 4px 14px;
        background: var(--bg-card); border: 1px solid var(--border);
        border-radius: 26px; cursor: pointer; transition: all .15s;
        max-width: 240px;
    }
    .vp-user-chip:hover { background: var(--bg-card-2); border-color: var(--border-2); }
    .vp-user-chip-name {
        font-size: 12.5px; font-weight: 600; color: var(--text);
        white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
    }
    .vp-user-chip-avatar {
        width: 30px; height: 30px; border-radius: 50%;
        overflow: hidden; flex-shrink: 0;
        background: var(--accent); color: #fff;
        display: flex; align-items: center; justify-content: center;
        font-weight: 700; font-size: 12px;
        border: 2px solid var(--accent);
    }
    .vp-user-chip-avatar img { width: 100%; height: 100%; object-fit: cover; }
    .vp-content {
        flex: 1; overflow-y: auto;
        padding: 20px;
        display: flex; flex-direction: column; gap: 14px;
        min-height: 0;
    }
    .vp-welcome {
        display: flex; align-items: center; justify-content: center;
        padding: 14px;
        background: var(--bg-card); border: 1px solid var(--border);
        border-radius: 12px;
        font-size: 13px; color: var(--text); font-weight: 500;
    }
    .vp-service {
        display: flex; align-items: center; gap: 14px;
        padding: 14px 18px;
        background: var(--bg-card); border: 1px solid var(--border);
        border-radius: 14px;
        cursor: pointer; transition: all .15s;
    }
    .vp-service:hover { border-color: var(--accent); background: var(--bg-card-2); }
    .vp-service-icon {
        width: 42px; height: 42px; border-radius: 11px;
        background: linear-gradient(135deg, var(--accent), var(--accent-2));
        display: flex; align-items: center; justify-content: center;
        color: #fff; flex-shrink: 0;
        box-shadow: 0 6px 16px -4px var(--accent-glow);
    }
    .vp-service-icon svg { width: 21px; height: 21px; }
    .vp-service-text { flex: 1; min-width: 0; }
    .vp-service-title { font-size: 13px; font-weight: 600; color: var(--text); display: flex; align-items: center; gap: 8px; }
    .vp-service-sub { font-size: 11px; color: var(--text-mute); margin-top: 2px; }
    .vp-service-dev {
        font-size: 8.5px; font-weight: 800;
        padding: 2px 6px; border-radius: 4px;
        background: rgba(245,158,11,.15); color: #fbbf24;
        border: 1px solid rgba(245,158,11,.3);
        letter-spacing: .04em;
    }
    .vp-service-arrow { color: var(--text-mute); display: flex; align-items: center; }
    .vp-service-arrow svg { width: 16px; height: 16px; }
    .vp-hero {
        display: flex; gap: 20px;
        padding: 20px;
        background:
            radial-gradient(circle at 0% 0%, color-mix(in srgb, var(--accent) 14%, transparent), transparent 55%),
            var(--bg-card);
        border: 1px solid var(--border);
        border-radius: 16px;
        align-items: center;
    }
    .vp-hero-avatar {
        width: 120px; height: 120px; border-radius: 16px; flex-shrink: 0;
        overflow: hidden;
        border: 2px solid var(--accent);
        background: var(--bg-card-2);
        box-shadow: 0 0 0 4px color-mix(in srgb, var(--accent) 12%, transparent), 0 12px 30px -8px var(--accent-glow);
        display: flex; align-items: center; justify-content: center;
        color: #fff; font-size: 48px; font-weight: 800;
    }
    .vp-hero-avatar img { width: 100%; height: 100%; object-fit: cover; display: block; }
    .vp-hero-body { flex: 1; display: flex; flex-direction: column; gap: 10px; min-width: 0; }
    .vp-hero-name-row { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; }
    .vp-hero-name {
        font-size: 24px; font-weight: 700; color: #fff;
        letter-spacing: -.025em; line-height: 1.1;
    }
    .vp-hero-tag {
        display: inline-flex; align-items: center; gap: 5px;
        padding: 4px 10px; border-radius: 7px;
        background: rgba(239,68,68,.12); color: #f87171;
        font-size: 10px; font-weight: 800;
        border: 1px solid rgba(239,68,68,.35);
        letter-spacing: .06em;
    }
    .vp-hero-tag.vp-tag-dev {
        background: color-mix(in srgb, var(--accent) 14%, transparent);
        color: var(--accent-2); border-color: var(--accent);
        box-shadow: 0 0 12px var(--accent-glow);
    }
    .vp-hero-tag svg { width: 11px; height: 11px; }
    .vp-hero-chips { display: flex; gap: 8px; flex-wrap: wrap; }
    .vp-chip {
        display: inline-flex; align-items: center; gap: 6px;
        padding: 6px 11px; border-radius: 8px;
        background: var(--bg-app); border: 1px solid var(--border);
        color: var(--text-dim); font-size: 11.5px; font-weight: 500;
    }
    .vp-chip b { color: var(--accent-2); font-weight: 700; font-size: 12.5px; }
    .vp-chip svg { width: 13px; height: 13px; }

    /* FLAME */
    .vp-flame-card {
        display: grid;
        grid-template-columns: 130px 1fr auto;
        gap: 22px;
        align-items: center;
        padding: 22px 26px;
        background:
            radial-gradient(circle at 12% 50%, rgba(249,115,22,.14), transparent 55%),
            radial-gradient(circle at 88% 50%, color-mix(in srgb, var(--accent) 10%, transparent), transparent 55%),
            var(--bg-card);
        border: 1px solid var(--border);
        border-radius: 16px;
        position: relative; overflow: hidden;
    }
    .vp-flame-card::before {
        content: ''; position: absolute;
        top: 0; left: 0; right: 0; height: 1px;
        background: linear-gradient(90deg, transparent, rgba(249,115,22,.4), transparent);
    }
    .vp-flame-visual {
        width: 130px; height: 130px; position: relative;
        display: flex; align-items: center; justify-content: center;
        flex-shrink: 0;
    }
    .vp-flame-visual::before {
        content: ''; position: absolute; inset: 0;
        border-radius: 50%;
        background: radial-gradient(circle, rgba(249,115,22,.25), transparent 65%);
        opacity: 0; transition: opacity .5s;
    }
    .vp-flame-visual.vp-flame-lv1::before,
    .vp-flame-visual.vp-flame-lv2::before { opacity: .5; }
    .vp-flame-visual.vp-flame-lv3::before { opacity: .8; animation: vp-flame-halo 2.4s ease-in-out infinite; }
    .vp-flame-visual.vp-flame-lv4::before { opacity: 1;  animation: vp-flame-halo 1.8s ease-in-out infinite; }
    .vp-flame-visual.vp-flame-lv5::before { opacity: 1;  animation: vp-flame-halo 1.4s ease-in-out infinite; }
    @keyframes vp-flame-halo {
        0%,100% { transform: scale(1);    opacity: .6; }
        50%     { transform: scale(1.15); opacity: 1; }
    }
    .vp-flame-emoji {
        font-size: 82px; line-height: 1;
        position: relative; z-index: 1;
        transition: transform .5s cubic-bezier(.34,1.56,.64,1), filter .5s, opacity .5s;
        user-select: none; -webkit-user-select: none;
    }
    .vp-flame-visual.vp-flame-lv0 .vp-flame-emoji { filter: grayscale(1) brightness(.6); opacity: .35; transform: scale(.7); }
    .vp-flame-visual.vp-flame-lv1 .vp-flame-emoji { filter: drop-shadow(0 0 12px rgba(249,115,22,.7)); transform: scale(.85); }
    .vp-flame-visual.vp-flame-lv2 .vp-flame-emoji { filter: drop-shadow(0 0 16px rgba(249,115,22,.85)); transform: scale(1); }
    .vp-flame-visual.vp-flame-lv3 .vp-flame-emoji { transform: scale(1.12); animation: vp-flame-shine 2.2s ease-in-out infinite; }
    .vp-flame-visual.vp-flame-lv4 .vp-flame-emoji { transform: scale(1.28); animation: vp-flame-shine 1.7s ease-in-out infinite; }
    .vp-flame-visual.vp-flame-lv5 .vp-flame-emoji { transform: scale(1.45); animation: vp-flame-shine 1.3s ease-in-out infinite, vp-flame-wobble 3s ease-in-out infinite; }
    @keyframes vp-flame-shine {
        0%,100% { filter: drop-shadow(0 0 18px rgba(249,115,22,.85)) drop-shadow(0 0 32px rgba(249,115,22,.4)); }
        50%     { filter: drop-shadow(0 0 28px rgba(249,115,22,1)) drop-shadow(0 0 55px rgba(249,115,22,.6)); }
    }
    @keyframes vp-flame-wobble {
        0%,100% { transform: scale(1.45) rotate(-3deg); }
        50%     { transform: scale(1.45) rotate(3deg); }
    }
    .vp-flame-spark {
        position: absolute;
        width: 4px; height: 4px;
        border-radius: 50%;
        background: #fb923c;
        box-shadow: 0 0 8px #fb923c, 0 0 16px rgba(249,115,22,.6);
        pointer-events: none;
        animation: vp-spark 2.2s ease-out infinite;
    }
    .vp-flame-spark:nth-child(1) { left: 12%; top: 70%; animation-delay: 0s; }
    .vp-flame-spark:nth-child(2) { left: 82%; top: 62%; animation-delay: .6s; }
    .vp-flame-spark:nth-child(3) { left: 30%; top: 88%; animation-delay: 1.2s; }
    .vp-flame-spark:nth-child(4) { left: 70%; top: 80%; animation-delay: 1.7s; }
    @keyframes vp-spark {
        0%   { transform: translateY(0) scale(1);   opacity: 0; }
        20%  { opacity: 1; }
        100% { transform: translateY(-60px) scale(.3); opacity: 0; }
    }
    .vp-flame-info { min-width: 0; }
    .vp-flame-title {
        font-size: 10.5px; color: var(--text-mute);
        letter-spacing: .12em; text-transform: uppercase; font-weight: 700;
        margin-bottom: 6px;
    }
    .vp-flame-streak { display: flex; align-items: baseline; gap: 8px; margin-bottom: 6px; }
    .vp-flame-streak-num {
        font-size: 34px; font-weight: 800; color: #fff;
        letter-spacing: -.03em; line-height: 1;
        font-variant-numeric: tabular-nums;
        background: linear-gradient(180deg, #fff, #fb923c);
        -webkit-background-clip: text; background-clip: text; -webkit-text-fill-color: transparent;
    }
    .vp-flame-streak-label { font-size: 12.5px; color: var(--text-dim); font-weight: 500; }
    .vp-flame-stats {
        display: flex; align-items: center; gap: 8px;
        font-size: 11.5px; color: var(--text-mute);
        margin-bottom: 8px;
    }
    .vp-flame-stats b { color: var(--text-dim); font-weight: 700; }
    .vp-flame-hint {
        display: inline-flex; align-items: center; gap: 6px;
        padding: 5px 10px; border-radius: 7px;
        background: rgba(249,115,22,.1);
        border: 1px solid rgba(249,115,22,.25);
        font-size: 11px; color: #fb923c; font-weight: 600;
    }
    .vp-flame-hint.vp-flame-max {
        background: linear-gradient(135deg, rgba(249,115,22,.2), rgba(239,68,68,.15));
        border-color: rgba(249,115,22,.5);
        box-shadow: 0 0 16px -4px rgba(249,115,22,.5);
    }
    .vp-flame-btn {
        padding: 14px 22px; border-radius: 12px;
        background: linear-gradient(180deg, #f97316, #ea580c);
        border: 1px solid #fb923c;
        color: #fff; font: inherit;
        font-size: 13px; font-weight: 700; font-family: inherit;
        cursor: pointer;
        transition: all .2s cubic-bezier(.4,0,.2,1);
        box-shadow: 0 10px 24px -8px rgba(249,115,22,.7), inset 0 1px 0 rgba(255,255,255,.2);
        display: inline-flex; align-items: center; gap: 8px;
        white-space: nowrap; flex-shrink: 0;
    }
    .vp-flame-btn:hover {
        transform: translateY(-2px);
        box-shadow: 0 14px 30px -8px rgba(249,115,22,.85), 0 0 30px -4px rgba(249,115,22,.5), inset 0 1px 0 rgba(255,255,255,.2);
    }
    .vp-flame-btn:active { transform: scale(.97); }
    .vp-flame-btn.vp-flame-btn-disabled {
        background: var(--bg-card-2); border-color: var(--border-2);
        color: var(--text-mute); box-shadow: none;
        cursor: not-allowed; transform: none !important;
    }
    .vp-flame-btn.vp-flame-btn-disabled:hover { transform: none; box-shadow: none; }

    .vp-page-title { font-size: 20px; font-weight: 700; color: #fff; letter-spacing: -.02em; margin-bottom: 2px; }
    .vp-page-sub { font-size: 12px; color: var(--text-dim); margin-bottom: 6px; }
    .vp-card {
        background: var(--bg-card); border: 1px solid var(--border);
        border-radius: 14px; padding: 16px;
        display: flex; flex-direction: column; gap: 10px;
    }
    .vp-label {
        font-size: 10px; font-weight: 700; color: var(--text-mute);
        text-transform: uppercase; letter-spacing: .08em;
    }
    .vp-field { display: flex; align-items: center; justify-content: space-between; gap: 10px; }
    .vp-field > span { font-size: 12.5px; color: var(--text-dim); flex-shrink: 0; }
    .vp-input {
        background: var(--bg-app); border: 1px solid var(--border-2);
        border-radius: 9px; padding: 9px 12px;
        color: var(--text); font-size: 12.5px; font-family: inherit;
        outline: none; transition: all .15s; width: 100%;
    }
    .vp-input:focus { border-color: var(--accent); box-shadow: 0 0 0 3px color-mix(in srgb, var(--accent) 20%, transparent); }
    .vp-input::placeholder { color: var(--text-mute); }
    .vp-btn {
        background: var(--bg-card-2); border: 1px solid var(--border-2);
        color: var(--text); border-radius: 9px; padding: 10px 16px;
        font-size: 12.5px; font-weight: 500; font-family: inherit;
        cursor: pointer; transition: all .15s;
        display: inline-flex; align-items: center; justify-content: center; gap: 7px;
    }
    .vp-btn:hover { background: #1c2438; border-color: #354063; }
    .vp-btn:active { transform: scale(.98); }
    .vp-btn:disabled { opacity: .5; cursor: not-allowed; }
    .vp-btn.vp-primary {
        background: linear-gradient(180deg, var(--accent), var(--accent));
        border-color: var(--accent); color: #fff;
        box-shadow: 0 6px 16px -4px var(--accent-glow), inset 0 1px 0 rgba(255,255,255,.15);
    }
    .vp-btn.vp-primary:hover { filter: brightness(1.1); }
    .vp-btn svg { width: 14px; height: 14px; }
    .vp-row {
        display: flex; align-items: center; gap: 12px;
        padding: 12px 14px; border-radius: 11px;
        background: var(--bg-card); border: 1px solid var(--border);
        transition: all .15s;
    }
    .vp-row[data-url], .vp-row[data-section-id] { cursor: pointer; }
    .vp-row[data-url]:hover, .vp-row[data-section-id]:hover { background: var(--bg-card-2); border-color: var(--border-2); }
    .vp-row-title {
        flex: 1; min-width: 0; white-space: nowrap; overflow: hidden;
        text-overflow: ellipsis; color: var(--text); font-size: 13px; font-weight: 500;
    }
    .vp-badge-count {
        flex-shrink: 0; min-width: 30px; height: 28px; padding: 0 10px;
        border-radius: 8px; font-weight: 700; font-size: 13px;
        display: inline-flex; align-items: center; justify-content: center;
        font-variant-numeric: tabular-nums;
    }
    .vp-badge-count.vp-has { background: rgba(248,113,113,.14); color: #f87171; }
    .vp-badge-count.vp-clear { background: rgba(52,211,153,.14); color: #34d399; }
    .vp-badge-count.vp-error { background: var(--bg-card-2); color: var(--text-mute); }
    .vp-empty {
        display: flex; flex-direction: column; align-items: center; gap: 10px;
        padding: 40px 20px; color: var(--text-mute); text-align: center;
    }
    .vp-empty svg { width: 36px; height: 36px; opacity: .35; }
    .vp-empty-text { font-size: 12.5px; }
    .vp-del {
        color: var(--text-mute); cursor: pointer;
        width: 28px; height: 28px; border-radius: 8px;
        display: inline-flex; align-items: center; justify-content: center;
        transition: all .12s;
    }
    .vp-del:hover { background: rgba(248,113,113,.14); color: #f87171; }
    .vp-del svg { width: 13px; height: 13px; }
    .vp-sublist {
        max-height: 220px; overflow-y: auto;
        background: var(--bg-app); border: 1px solid var(--border);
        border-radius: 10px; padding: 6px;
        display: flex; flex-direction: column; gap: 2px;
    }
    .vp-sub {
        display: flex; align-items: center; gap: 9px;
        padding: 7px 9px; border-radius: 8px;
        cursor: pointer; transition: background .12s;
    }
    .vp-sub:hover { background: var(--bg-card); }
    .vp-sub input[type="checkbox"] {
        appearance: none; -webkit-appearance: none;
        width: 16px; height: 16px; flex-shrink: 0;
        border-radius: 5px; background: var(--bg-card);
        border: 1.5px solid var(--border-2);
        cursor: pointer; position: relative; transition: all .15s;
    }
    .vp-sub input[type="checkbox"]:checked { background: var(--accent); border-color: var(--accent); }
    .vp-sub input[type="checkbox"]:checked::after {
        content: ''; position: absolute; left: 4px; top: 1px;
        width: 4px; height: 9px;
        border: solid #fff; border-width: 0 2px 2px 0;
        transform: rotate(45deg);
    }
    .vp-sub span {
        font-size: 12px; color: var(--text-dim); cursor: pointer;
        white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
        flex: 1; min-width: 0;
    }
    .vp-sub:hover span { color: var(--text); }
    .vp-stats { display: flex; flex-direction: column; gap: 12px; }
    .vp-stat { display: flex; flex-direction: column; gap: 7px; }
    .vp-stat-head { display: flex; align-items: center; justify-content: space-between; gap: 10px; }
    .vp-stat-name {
        font-size: 12.5px; color: var(--text-dim);
        white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
        flex: 1; min-width: 0;
    }
    .vp-stat-value {
        font-size: 13px; font-weight: 700; color: var(--text);
        font-variant-numeric: tabular-nums;
        display: inline-flex; align-items: baseline; gap: 6px;
    }
    .vp-stat-value small { font-size: 11px; font-weight: 500; color: var(--text-mute); }
    .vp-progress { height: 6px; border-radius: 6px; background: var(--bg-app); overflow: hidden; }
    .vp-progress-fill {
        height: 100%; border-radius: 6px;
        background: linear-gradient(90deg, var(--accent), var(--accent-2));
        transition: width .5s cubic-bezier(.4,0,.2,1);
        box-shadow: 0 0 8px var(--accent-glow);
    }
    .vp-stat.vp-total { padding-top: 14px; margin-top: 4px; border-top: 1px solid var(--border); }
    .vp-stat.vp-total .vp-stat-name { color: var(--text); font-weight: 600; font-size: 13px; }
    .vp-stat.vp-total .vp-stat-value { color: #34d399; font-size: 14px; }
    .vp-stat.vp-total .vp-stat-value small { color: #34d399; opacity: .75; }
    .vp-stat.vp-total .vp-progress { height: 8px; }
    .vp-stat.vp-total .vp-progress-fill { background: linear-gradient(90deg, #34d399, #6ee7b7); }

    .vp-admintools-hero {
        padding: 26px; border-radius: 16px;
        background:
            radial-gradient(circle at 20% 0%, color-mix(in srgb, var(--accent) 22%, transparent), transparent 60%),
            radial-gradient(circle at 90% 100%, color-mix(in srgb, var(--accent-2) 18%, transparent), transparent 55%),
            var(--bg-card);
        border: 1px solid var(--border-2);
        position: relative; overflow: hidden;
    }
    .vp-admintools-hero::after {
        content: ''; position: absolute; inset: -50%;
        background: conic-gradient(from 0deg, transparent 0 40%, color-mix(in srgb, var(--accent) 30%, transparent) 50%, transparent 60%);
        animation: vp-spin 8s linear infinite;
        opacity: .15; pointer-events: none;
    }
    @keyframes vp-spin { to { transform: rotate(360deg); } }
    .vp-admintools-hero > * { position: relative; z-index: 1; }
    .vp-admintools-icon {
        width: 64px; height: 64px; border-radius: 16px;
        background: linear-gradient(135deg, var(--accent), var(--accent-2));
        display: flex; align-items: center; justify-content: center;
        color: #fff; box-shadow: 0 14px 32px -8px var(--accent-glow);
        margin-bottom: 16px;
    }
    .vp-admintools-icon svg { width: 32px; height: 32px; }
    .vp-admintools-title {
        font-size: 24px; font-weight: 700; color: #fff; letter-spacing: -.02em;
        display: flex; align-items: center; gap: 12px; flex-wrap: wrap;
    }
    .vp-admintools-desc {
        font-size: 13px; color: var(--text-dim); margin-top: 8px; line-height: 1.6;
        max-width: 620px;
    }
    .vp-admintools-badge {
        font-size: 10px; font-weight: 800;
        padding: 4px 10px; border-radius: 6px;
        background: rgba(245,158,11,.15); color: #fbbf24;
        border: 1px solid rgba(245,158,11,.35);
        letter-spacing: .08em; text-transform: uppercase;
    }
    .vp-features-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 12px; }
    .vp-feature {
        display: flex; gap: 14px; padding: 16px;
        background: var(--bg-card); border: 1px solid var(--border);
        border-radius: 12px; transition: all .2s;
    }
    .vp-feature:hover { border-color: var(--accent); transform: translateY(-2px); }
    .vp-feature-icon {
        width: 40px; height: 40px; border-radius: 10px;
        background: color-mix(in srgb, var(--accent) 14%, transparent);
        border: 1px solid color-mix(in srgb, var(--accent) 30%, transparent);
        color: var(--accent-2);
        display: flex; align-items: center; justify-content: center;
        flex-shrink: 0;
    }
    .vp-feature-icon svg { width: 20px; height: 20px; }
    .vp-feature-body { flex: 1; min-width: 0; }
    .vp-feature-title { font-size: 13px; font-weight: 600; color: var(--text); }
    .vp-feature-text { font-size: 11.5px; color: var(--text-dim); margin-top: 4px; line-height: 1.5; }
    .vp-feature-status {
        display: inline-block; margin-top: 8px;
        font-size: 9.5px; font-weight: 700;
        padding: 2px 7px; border-radius: 4px;
        background: rgba(245,158,11,.12); color: #fbbf24;
        letter-spacing: .06em; text-transform: uppercase;
        border: 1px solid rgba(245,158,11,.25);
    }
    .vp-feature-status.vp-soon { background: rgba(148,163,184,.12); color: #94a3b8; border-color: rgba(148,163,184,.25); }

    .vp-badges-summary {
        display: flex; align-items: center; justify-content: space-between;
        padding: 16px 20px; border-radius: 14px;
        background: linear-gradient(135deg, color-mix(in srgb, var(--accent) 16%, transparent), transparent);
        border: 1px solid var(--accent);
    }
    .vp-badges-summary-l { display: flex; flex-direction: column; gap: 2px; }
    .vp-badges-summary-title { font-size: 12px; color: var(--text-dim); font-weight: 500; }
    .vp-badges-summary-count { font-size: 24px; font-weight: 700; color: #fff; letter-spacing: -.02em; }
    .vp-badges-summary-count small { font-size: 13px; color: var(--text-mute); font-weight: 500; }
    .vp-badges-summary-icon { font-size: 36px; line-height: 1; filter: drop-shadow(0 4px 10px var(--accent-glow)); }
    .vp-badges-list { display: flex; flex-direction: column; gap: 10px; }
    .vp-badge-card {
        display: flex; gap: 14px;
        padding: 14px 16px;
        background: var(--bg-card); border: 1px solid var(--border);
        border-radius: 13px;
        position: relative; overflow: hidden;
        transition: all .2s;
    }
    .vp-badge-card.vp-earned:hover { transform: translateY(-2px); border-color: var(--accent); }
    .vp-badge-card.vp-locked { opacity: .55; }
    .vp-badge-card.vp-locked .vp-badge-ic { filter: grayscale(1); }
    .vp-badge-card.vp-tier-bronze    { border-color: rgba(161,98,7,.5); }
    .vp-badge-card.vp-tier-silver    { border-color: rgba(148,163,184,.5); }
    .vp-badge-card.vp-tier-gold      { border-color: rgba(234,179,8,.5); box-shadow: 0 0 20px -10px rgba(234,179,8,.4); }
    .vp-badge-card.vp-tier-platinum  { border-color: rgba(226,232,240,.6); box-shadow: 0 0 22px -10px rgba(226,232,240,.5); }
    .vp-badge-card.vp-tier-legendary {
        border-color: rgba(245,158,11,.7);
        box-shadow: 0 0 24px -8px rgba(245,158,11,.55);
        animation: vp-legend-glow 3s ease-in-out infinite;
    }
    @keyframes vp-legend-glow {
        0%,100% { box-shadow: 0 0 24px -8px rgba(245,158,11,.55); }
        50%     { box-shadow: 0 0 32px -4px rgba(245,158,11,.8); }
    }
    .vp-badge-card.vp-tier-special {
        border-color: var(--accent);
        background: linear-gradient(135deg, color-mix(in srgb, var(--accent) 12%, var(--bg-card)), var(--bg-card));
        box-shadow: 0 0 28px -8px var(--accent-glow);
        animation: vp-spec-glow 2.5s ease-in-out infinite;
    }
    @keyframes vp-spec-glow {
        0%,100% { box-shadow: 0 0 28px -8px var(--accent-glow); }
        50%     { box-shadow: 0 0 40px -4px var(--accent-glow); }
    }
    .vp-badge-ic {
        width: 58px; height: 58px; flex-shrink: 0;
        border-radius: 14px;
        background: var(--bg-app); border: 1px solid var(--border);
        display: flex; align-items: center; justify-content: center;
        font-size: 30px; line-height: 1;
    }
    .vp-badge-card.vp-earned .vp-badge-ic { box-shadow: inset 0 0 20px -8px var(--accent-glow); }
    .vp-badge-body { flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 4px; }
    .vp-badge-head { display: flex; align-items: center; gap: 8px; }
    .vp-badge-name { font-size: 13px; font-weight: 700; color: var(--text); }
    .vp-badge-tier {
        font-size: 9px; font-weight: 800;
        padding: 2px 6px; border-radius: 4px;
        letter-spacing: .06em; text-transform: uppercase;
    }
    .vp-badge-tier.vp-bronze   { background: rgba(161,98,7,.2); color: #ca8a04; }
    .vp-badge-tier.vp-silver   { background: rgba(148,163,184,.2); color: #cbd5e1; }
    .vp-badge-tier.vp-gold     { background: rgba(234,179,8,.18); color: #eab308; }
    .vp-badge-tier.vp-platinum { background: rgba(226,232,240,.2); color: #f1f5f9; }
    .vp-badge-tier.vp-legendary{ background: rgba(245,158,11,.2); color: #f59e0b; }
    .vp-badge-tier.vp-special  { background: var(--accent-glow); color: #fff; }
    .vp-badge-check { margin-left: auto; color: #34d399; width: 20px; height: 20px; }
    .vp-badge-check svg { width: 100%; height: 100%; }
    .vp-badge-desc { font-size: 11.5px; color: var(--text-dim); }
    .vp-badge-how  { font-size: 11px; color: var(--text-mute); margin-top: 2px; }
    .vp-badge-how b { color: var(--accent-2); font-weight: 600; }
    .vp-badge-progress-wrap { margin-top: 8px; display: flex; align-items: center; gap: 8px; }
    .vp-badge-progress { flex: 1; height: 5px; border-radius: 5px; background: var(--bg-app); overflow: hidden; }
    .vp-badge-progress-fill {
        height: 100%; border-radius: 5px;
        background: linear-gradient(90deg, var(--accent), var(--accent-2));
        box-shadow: 0 0 6px var(--accent-glow);
        transition: width .5s cubic-bezier(.4,0,.2,1);
    }
    .vp-badge-progress-num {
        font-size: 10.5px; font-weight: 700; color: var(--text-dim);
        font-variant-numeric: tabular-nums; flex-shrink: 0;
    }
    .vp-badge-card.vp-earned .vp-badge-progress-fill { background: linear-gradient(90deg, #34d399, #6ee7b7); }

    .vp-theme-grid { display: grid; grid-template-columns: repeat(5, 1fr); gap: 10px; }
    .vp-theme-swatch {
        aspect-ratio: 1.6 / 1; border-radius: 12px;
        cursor: pointer; border: 2px solid transparent;
        position: relative; transition: all .2s;
        display: flex; align-items: center; justify-content: center;
        font-size: 10.5px; font-weight: 700; color: #fff;
        text-shadow: 0 1px 4px rgba(0,0,0,.6);
        overflow: hidden;
    }
    .vp-theme-swatch:hover { transform: translateY(-3px) scale(1.03); }
    .vp-theme-swatch.vp-active {
        border-color: #fff;
        box-shadow: 0 0 0 3px rgba(255,255,255,.1), 0 8px 20px rgba(0,0,0,.4);
    }
    .vp-theme-swatch.vp-active::after {
        content: '✓'; position: absolute; top: 6px; right: 8px;
        font-size: 14px; font-weight: 800;
    }
    .vp-user-card {
        display: flex; align-items: center; gap: 12px;
        padding: 12px; border-radius: 12px;
        background: var(--bg-app); border: 1px solid var(--border);
    }
    .vp-user-avatar {
        width: 46px; height: 46px; border-radius: 12px; flex-shrink: 0;
        overflow: hidden; background: var(--bg-card-2);
        display: flex; align-items: center; justify-content: center;
        color: var(--text-dim); font-weight: 700; font-size: 17px;
        border: 1px solid var(--border-2);
    }
    .vp-user-avatar img { width: 100%; height: 100%; object-fit: cover; display: block; }
    .vp-user-info { flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 3px; }
    .vp-user-name { font-size: 13.5px; font-weight: 600; color: var(--text); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .vp-user-status { font-size: 11px; color: var(--text-mute); display: flex; align-items: center; gap: 5px; }
    .vp-user-status::before { content: ''; width: 6px; height: 6px; border-radius: 50%; background: var(--text-mute); flex-shrink: 0; }
    .vp-user-status.vp-online::before { background: #34d399; box-shadow: 0 0 6px #34d399; }

    .vp-toggle-row { display: flex; align-items: center; justify-content: space-between; gap: 12px; }
    .vp-toggle-row-info { flex: 1; min-width: 0; }
    .vp-toggle-row-title { font-size: 12.5px; color: var(--text); font-weight: 500; }
    .vp-toggle-row-desc { font-size: 11px; color: var(--text-mute); margin-top: 2px; }
    .vp-toggle {
        position: relative; width: 42px; height: 24px; flex-shrink: 0;
        border-radius: 24px; background: var(--bg-app);
        border: 1px solid var(--border-2);
        cursor: pointer; transition: all .2s;
    }
    .vp-toggle::after {
        content: ''; position: absolute; top: 2px; left: 2px;
        width: 18px; height: 18px; border-radius: 50%;
        background: var(--text-mute);
        transition: all .2s cubic-bezier(.34,1.56,.64,1);
    }
    .vp-toggle.vp-on { background: var(--accent); border-color: var(--accent); }
    .vp-toggle.vp-on::after { left: 20px; background: #fff; box-shadow: 0 2px 6px rgba(0,0,0,.3); }

    .vp-mini {
        position: fixed; left: 22px; top: 50%;
        transform: translateY(-50%) scale(.8);
        width: 44px; height: 44px;
        border-radius: 50%;
        z-index: 2147483645;
        cursor: pointer;
        display: none;
        align-items: center; justify-content: center;
        background: linear-gradient(135deg, var(--accent-2), var(--accent));
        box-shadow: 0 8px 22px -6px var(--accent-glow), inset 0 1px 0 rgba(255,255,255,.2);
        color: #fff;
        transition: transform .3s cubic-bezier(.4,0,.2,1), box-shadow .3s;
        font-family: -apple-system, BlinkMacSystemFont, "SF Pro Text", "Segoe UI", sans-serif;
        user-select: none;
    }
    .vp-mini.vp-show { display: flex; transform: translateY(-50%) scale(1); }
    .vp-mini.vp-dragging { cursor: grabbing; transition: none; }
    .vp-mini:not(.vp-dragging).vp-show:hover { transform: translateY(-50%) scale(1.08); }
    .vp-mini-logo { position: relative; z-index: 1; display: flex; align-items: center; justify-content: center; pointer-events: none; }
    .vp-mini-logo svg { width: 22px; height: 22px; }
    .vp-mini-pulse {
        position: absolute; inset: -2px;
        border-radius: 50%;
        border: 2px solid var(--accent-2);
        opacity: 0; pointer-events: none;
        animation: vp-mini-ring 2.2s ease-out infinite;
    }
    @keyframes vp-mini-ring {
        0%   { transform: scale(.9); opacity: .7; }
        100% { transform: scale(1.7); opacity: 0; }
    }
    .vp-mini.vp-alert .vp-mini-pulse { border-color: #f43f5e; animation-duration: 1.3s; }
    .vp-mini.vp-alert { background: linear-gradient(135deg, #fb7185, #e11d48); box-shadow: 0 8px 22px -6px rgba(244,63,94,.6); }
    .vp-mini-hint {
        position: absolute; left: calc(100% + 10px);
        top: 50%; transform: translateY(-50%) translateX(-6px);
        background: #050810; border: 1px solid var(--border-2);
        color: var(--text); padding: 6px 10px; border-radius: 8px;
        font-size: 11px; white-space: nowrap;
        opacity: 0; pointer-events: none;
        transition: all .2s;
    }
    .vp-mini:hover .vp-mini-hint { opacity: 1; transform: translateY(-50%) translateX(0); }

    .vp-drawer-backdrop {
        position: absolute; inset: 0;
        background: rgba(4, 6, 12, 0.55);
        backdrop-filter: blur(3px); -webkit-backdrop-filter: blur(3px);
        opacity: 0; pointer-events: none;
        transition: opacity .25s; z-index: 50;
    }
    .vp-drawer-backdrop.vp-show { opacity: 1; pointer-events: auto; }
    .vp-drawer {
        position: absolute; top: 0; right: 0; bottom: 0;
        width: 460px; max-width: calc(100% - 80px);
        background: var(--bg-card);
        border-left: 1px solid var(--border-2);
        box-shadow: -24px 0 60px -12px rgba(0,0,0,.7);
        z-index: 60;
        display: none; flex-direction: column;
        transform: translateX(100%);
        transition: transform .3s cubic-bezier(.4,0,.2,1);
    }
    .vp-drawer.vp-open { display: flex; }
    .vp-drawer.vp-visible { transform: translateX(0); }
    .vp-drawer-head {
        padding: 16px 18px;
        border-bottom: 1px solid var(--border);
        display: flex; align-items: flex-start; gap: 12px;
        flex-shrink: 0;
    }
    .vp-drawer-head-info { flex: 1; min-width: 0; }
    .vp-drawer-head-title {
        font-size: 15px; font-weight: 700; color: #fff;
        white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
        letter-spacing: -.01em;
    }
    .vp-drawer-head-sub { font-size: 11.5px; color: var(--text-dim); margin-top: 3px; }
    .vp-drawer-close {
        width: 30px; height: 30px; border-radius: 8px;
        background: var(--bg-app); border: 1px solid var(--border);
        color: var(--text-dim); cursor: pointer;
        display: flex; align-items: center; justify-content: center;
        transition: all .15s; flex-shrink: 0;
    }
    .vp-drawer-close:hover { background: rgba(248,113,113,.14); color: #f87171; border-color: rgba(248,113,113,.3); }
    .vp-drawer-close svg { width: 14px; height: 14px; }
    .vp-drawer-actions {
        padding: 10px 14px;
        border-bottom: 1px solid var(--border);
        display: flex; gap: 8px;
        flex-shrink: 0;
    }
    .vp-drawer-actions .vp-btn { flex: 1; font-size: 11.5px; padding: 8px 12px; }
    .vp-drawer-body {
        flex: 1; overflow-y: auto;
        padding: 10px;
        display: flex; flex-direction: column; gap: 6px;
        min-height: 0;
    }
    .vp-drawer-thread {
        display: flex; align-items: flex-start; gap: 10px;
        padding: 11px 12px;
        border-radius: 10px;
        background: var(--bg-app);
        border: 1px solid var(--border);
        cursor: pointer;
        transition: all .15s;
        text-decoration: none; color: inherit;
    }
    .vp-drawer-thread:hover { background: var(--bg-card-2); border-color: var(--accent); }
    .vp-drawer-thread-icon {
        width: 28px; height: 28px; border-radius: 7px;
        background: var(--bg-card-2); border: 1px solid var(--border);
        display: flex; align-items: center; justify-content: center;
        color: var(--text-mute); flex-shrink: 0; font-size: 14px;
    }
    .vp-drawer-thread.vp-closed .vp-drawer-thread-icon { color: #34d399; background: rgba(52,211,153,.1); border-color: rgba(52,211,153,.25); }
    .vp-drawer-thread.vp-open .vp-drawer-thread-icon { color: #f87171; background: rgba(248,113,113,.1); border-color: rgba(248,113,113,.25); }
    .vp-drawer-thread-body { flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 3px; }
    .vp-drawer-thread-title {
        font-size: 12.5px; color: var(--text); font-weight: 500;
        line-height: 1.35; overflow: hidden;
        display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical;
    }
    .vp-drawer-thread-meta {
        font-size: 10.5px; color: var(--text-mute);
        display: flex; align-items: center; gap: 6px;
    }
    .vp-drawer-thread-tag {
        display: inline-block;
        padding: 1px 6px; border-radius: 4px;
        font-size: 9.5px; font-weight: 700;
        letter-spacing: .04em; text-transform: uppercase;
    }
    .vp-drawer-thread-tag.vp-open { background: rgba(248,113,113,.14); color: #f87171; }
    .vp-drawer-thread-tag.vp-closed { background: rgba(52,211,153,.14); color: #34d399; }
    .vp-drawer-thread-arrow { color: var(--text-mute); flex-shrink: 0; margin-top: 4px; }
    .vp-drawer-thread-arrow svg { width: 14px; height: 14px; }
    .vp-drawer-empty { padding: 40px 20px; text-align: center; color: var(--text-mute); font-size: 12.5px; }

    .vp-tg-block {
        margin-top: 4px; padding: 14px; border-radius: 12px;
        background: linear-gradient(135deg, rgba(41,182,246,.06), rgba(41,182,246,.02));
        border: 1px solid rgba(41,182,246,.2);
    }
    .vp-tg-block-head { display: flex; align-items: center; gap: 12px; margin-bottom: 12px; }
    .vp-tg-block-icon {
        width: 40px; height: 40px; border-radius: 10px;
        background: linear-gradient(135deg, #29b6f6, #0288d1);
        color: #fff;
        display: flex; align-items: center; justify-content: center;
        flex-shrink: 0;
        box-shadow: 0 6px 16px -4px rgba(41,182,246,.5);
    }
    .vp-tg-block-icon svg { width: 22px; height: 22px; }
    .vp-tg-block-info { flex: 1; min-width: 0; }
    .vp-tg-block-title { font-size: 13px; font-weight: 600; color: var(--text); }
    .vp-tg-block-desc { font-size: 11px; color: var(--text-mute); margin-top: 2px; }
    .vp-tg-status {
        display: flex; align-items: center; gap: 10px;
        padding: 10px 12px; border-radius: 10px;
        background: var(--bg-app); border: 1px solid var(--border);
    }
    .vp-tg-status.vp-connected { background: rgba(41,182,246,.08); border-color: rgba(41,182,246,.3); }
    .vp-tg-status-dot { width: 8px; height: 8px; border-radius: 50%; background: var(--text-mute); flex-shrink: 0; }
    .vp-tg-status.vp-connected .vp-tg-status-dot {
        background: #29b6f6; box-shadow: 0 0 8px #29b6f6;
        animation: vp-dot-pulse 2s ease-in-out infinite;
    }
    .vp-tg-status-info { flex: 1; min-width: 0; }
    .vp-tg-status-title {
        font-size: 12px; font-weight: 600; color: var(--text);
        white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
    }
    .vp-tg-status-desc { font-size: 10.5px; color: var(--text-mute); margin-top: 1px; }
    .vp-tg-status-btn {
        padding: 6px 12px; border-radius: 8px;
        background: var(--bg-card-2); border: 1px solid var(--border-2);
        color: var(--text); font-size: 11px; font-weight: 600;
        cursor: pointer; font-family: inherit;
        transition: all .15s; flex-shrink: 0;
    }
    .vp-tg-status-btn:hover { background: #1c2438; border-color: #354063; }
    .vp-tg-status-btn.vp-primary {
        background: linear-gradient(135deg, #29b6f6, #0288d1);
        border-color: #29b6f6; color: #fff;
        box-shadow: 0 4px 12px -3px rgba(41,182,246,.5);
    }
    .vp-tg-status-btn.vp-primary:hover { filter: brightness(1.1); }

    .vp-tg-modal {
        position: absolute; inset: 0; z-index: 200;
        background: rgba(4, 6, 12, 0.7);
        backdrop-filter: blur(8px); -webkit-backdrop-filter: blur(8px);
        display: none; align-items: center; justify-content: center;
        opacity: 0; transition: opacity .25s;
    }
    .vp-tg-modal.vp-open { display: flex; }
    .vp-tg-modal.vp-visible { opacity: 1; }
    .vp-tg-modal-card {
        position: relative;
        width: 400px; max-width: calc(100% - 40px);
        padding: 24px; border-radius: 18px;
        background: var(--bg-card);
        border: 1px solid var(--border-2);
        box-shadow: 0 30px 80px -20px rgba(0,0,0,.9);
        transform: translateY(12px) scale(.97);
        transition: transform .35s cubic-bezier(.34,1.56,.64,1);
    }
    .vp-tg-modal.vp-visible .vp-tg-modal-card { transform: none; }
    .vp-tg-modal-close {
        position: absolute; top: 12px; right: 12px;
        width: 28px; height: 28px; border-radius: 8px;
        background: transparent; border: 1px solid transparent;
        color: var(--text-mute); cursor: pointer;
        display: flex; align-items: center; justify-content: center;
        transition: all .15s;
    }
    .vp-tg-modal-close:hover { background: rgba(248,113,113,.14); color: #f87171; }
    .vp-tg-modal-close svg { width: 14px; height: 14px; }
    .vp-tg-head {
        display: flex; flex-direction: column; align-items: center; gap: 10px;
        text-align: center; padding: 4px 0 16px;
    }
    .vp-tg-icon {
        width: 64px; height: 64px; border-radius: 18px;
        background: linear-gradient(135deg, #29b6f6, #0288d1);
        color: #fff;
        display: flex; align-items: center; justify-content: center;
        box-shadow: 0 14px 32px -8px rgba(41,182,246,.6);
    }
    .vp-tg-icon svg { width: 32px; height: 32px; }
    .vp-tg-icon.vp-tg-icon-success { background: linear-gradient(135deg, #10b981, #059669); box-shadow: 0 14px 32px -8px rgba(16,185,129,.6); }
    .vp-tg-icon.vp-tg-icon-warn { background: linear-gradient(135deg, #f59e0b, #d97706); box-shadow: 0 14px 32px -8px rgba(245,158,11,.6); font-size: 30px; }
    .vp-tg-icon.vp-tg-icon-error { background: linear-gradient(135deg, #ef4444, #dc2626); box-shadow: 0 14px 32px -8px rgba(239,68,68,.6); font-size: 30px; }
    .vp-tg-title { font-size: 18px; font-weight: 700; color: #fff; letter-spacing: -.01em; }
    .vp-tg-sub { font-size: 12.5px; color: var(--text-dim); line-height: 1.5; max-width: 300px; }
    .vp-tg-sub b { color: var(--accent-2); }
    .vp-tg-steps { display: flex; flex-direction: column; gap: 10px; margin: 4px 0 12px; }
    .vp-tg-step { display: flex; gap: 10px; align-items: flex-start; }
    .vp-tg-step-num {
        width: 22px; height: 22px; border-radius: 50%;
        background: var(--bg-app); border: 1px solid var(--border-2);
        color: var(--text-dim); font-size: 11px; font-weight: 700;
        display: flex; align-items: center; justify-content: center;
        flex-shrink: 0; margin-top: 1px;
    }
    .vp-tg-step-text { font-size: 12.5px; color: var(--text); line-height: 1.5; }
    .vp-tg-step-text b { color: var(--accent-2); font-weight: 600; }
    .vp-tg-code {
        display: flex; align-items: center; gap: 8px;
        padding: 10px 12px;
        background: var(--bg-app);
        border: 1px dashed var(--border-2);
        border-radius: 10px; margin-bottom: 14px;
    }
    .vp-tg-code code {
        flex: 1; font-family: 'JetBrains Mono', 'SF Mono', Consolas, monospace;
        font-size: 14px; color: #29b6f6; font-weight: 700;
        letter-spacing: .04em; user-select: all; cursor: pointer;
    }
    .vp-tg-copy {
        padding: 5px 10px; border-radius: 7px;
        background: rgba(41,182,246,.12); border: 1px solid rgba(41,182,246,.3);
        color: #29b6f6; font-size: 10.5px; font-weight: 700;
        cursor: pointer; font-family: inherit;
        transition: all .15s; white-space: nowrap;
    }
    .vp-tg-copy:hover { background: rgba(41,182,246,.2); }
    .vp-tg-actions { display: flex; gap: 8px; }
    .vp-tg-actions .vp-btn { flex: 1; }
    .vp-tg-btn-primary {
        background: linear-gradient(135deg, #29b6f6, #0288d1) !important;
        border-color: #29b6f6 !important; color: #fff !important;
        box-shadow: 0 6px 16px -4px rgba(41,182,246,.5) !important;
    }
    .vp-tg-btn-primary:hover { filter: brightness(1.1); }
    .vp-tg-waiting {
        display: flex; align-items: center; justify-content: center; gap: 10px;
        padding: 14px 0 4px; color: var(--text-dim); font-size: 12px;
    }
    .vp-tg-waiting-dots { display: flex; gap: 4px; }
    .vp-tg-waiting-dots span {
        width: 6px; height: 6px; border-radius: 50%;
        background: #29b6f6;
        animation: vp-tg-dots 1.2s ease-in-out infinite;
    }
    .vp-tg-waiting-dots span:nth-child(2) { animation-delay: .2s; }
    .vp-tg-waiting-dots span:nth-child(3) { animation-delay: .4s; }
    @keyframes vp-tg-dots {
        0%,100% { opacity: .3; transform: translateY(0); }
        50%     { opacity: 1;  transform: translateY(-3px); }
    }
    `;

    /* ============================================================
       STATE
       ============================================================ */
    let trackedSections = [], fetchedSubsections = [];
    let isBusy = false, userProfile = null;
    let shadowRoot = null, hostEl = null;
    let splashEl = null, appEl = null, miniEl = null, backdropEl = null, notifPanelEl = null;
    let drawerEl = null, drawerBackdropEl = null;
    let toastRoot = null;
    let lastStats = null, earnedBadges = [];
    let currentTheme = 'blue';
    let currentView = 'home';
    let notifications = [];
    let sectionThreads = {};

    const $ = id => shadowRoot ? shadowRoot.getElementById(id) : null;

    /* ============================================================
       NETWORK
       ============================================================ */
    function fetchHtml(url) {
        return new Promise(resolve => {
            chrome.runtime.sendMessage({ type: 'ARZ_FETCH', url }, res => {
                if (chrome.runtime.lastError) return resolve(null);
                if (!res || !res.ok) return resolve(null);
                resolve(res.text);
            });
        });
    }

    /* ============================================================
       NOTIFICATIONS
       ============================================================ */
    let notifSeq = 0;

    function addNotification(title, text, type = 'info', icon = '🔔') {
        const n = { id: ++notifSeq, title, text, type, icon, ts: Date.now(), read: false };
        notifications.unshift(n);
        if (notifications.length > 60) notifications = notifications.slice(0, 60);
        Store.set(CONFIG.KEYS.NOTIF, notifications);
        updateBellBadge();
        if (notifPanelEl?.classList.contains('vp-open')) renderNotifList();
        return n;
    }

    function updateBellBadge() {
        const el = $('vp-bell-badge');
        if (!el) return;
        const unread = notifications.filter(n => !n.read).length;
        if (unread > 0) {
            el.textContent = unread > 99 ? '99+' : String(unread);
            el.classList.add('vp-show');
        } else {
            el.classList.remove('vp-show');
        }
    }

    function renderNotifList() {
        const listEl = $('vp-notif-list');
        if (!listEl) return;
        if (!notifications.length) {
            listEl.innerHTML = `<div class="vp-notif-empty">
                Пока нет уведомлений<br><span style="opacity:.6;font-size:11px;">Здесь появятся все события Vegas+</span>
            </div>`;
            return;
        }
        listEl.innerHTML = notifications.map(n => {
            const t = new Date(n.ts);
            const time = `${String(t.getHours()).padStart(2,'0')}:${String(t.getMinutes()).padStart(2,'0')} · ${t.getDate()}.${String(t.getMonth()+1).padStart(2,'0')}`;
            return `
                <div class="vp-notif-item ${n.read ? '' : 'vp-unread'}">
                    <div class="vp-notif-icon vp-${n.type}">${n.icon}</div>
                    <div class="vp-notif-body">
                        <div class="vp-notif-title">${n.title}</div>
                        <div class="vp-notif-text">${n.text}</div>
                        <div class="vp-notif-time">${time}</div>
                    </div>
                </div>`;
        }).join('');
        setTimeout(() => {
            notifications.forEach(n => n.read = true);
            Store.set(CONFIG.KEYS.NOTIF, notifications);
            updateBellBadge();
        }, 800);
    }

    function toggleNotifPanel() {
        if (!notifPanelEl) return;
        const open = notifPanelEl.classList.toggle('vp-open');
        if (open) {
            requestAnimationFrame(() => notifPanelEl.classList.add('vp-visible'));
            renderNotifList();
        } else {
            notifPanelEl.classList.remove('vp-visible');
        }
    }

    /* ============================================================
       PROFILE
       ============================================================ */
    function extractUserId(href) {
        if (!href) return '';
        const m = href.match(/\/members\/(?:[^/]*?\.)?(\d+)\/?/);
        return m ? m[1] : '';
    }

    function readProfileFromPage() {
        const userLink = document.querySelector('.p-navgroup-link--user, .p-account-username');
        const avatarImg = document.querySelector('.p-navgroup-link--user .avatar img, .p-account-username .avatar img, .avatar--xxs img');
        const usernameEl = document.querySelector('.p-navgroup-link--user .p-navgroup-linkText, .p-account-username');
        let username = usernameEl?.textContent.trim() || avatarImg?.getAttribute('alt')?.trim() || '';
        let avatar = avatarImg?.getAttribute('src') || '';
        if (avatar && avatar.startsWith('/')) avatar = CONFIG.FORUM_ORIGIN + avatar;
        let userId = userLink ? extractUserId(userLink.getAttribute('href')) : '';
        if (!userId && avatar) {
            const m = avatar.match(/\/(\d+)\.(?:jpg|png|jpeg|gif|webp)/);
            if (m) userId = m[1];
        }
        if (!username && !userId) return null;
        return { username, avatar, userId };
    }

    async function fetchProfileFromAccount() {
        const html = await fetchHtml(CONFIG.FORUM_ORIGIN + '/account/');
        if (!html) return null;
        const doc = new DOMParser().parseFromString(html, 'text/html');
        const titleText = doc.querySelector('.p-title-value')?.textContent || '';
        if (doc.querySelector('form[action*="/login"]') || titleText.includes('Вход')) return null;
        const usernameEl = doc.querySelector('.p-account-username, .p-navgroup-link--user .p-navgroup-linkText');
        const avatarImg = doc.querySelector('.p-account-username .avatar img, .avatar--xxs img, .p-navgroup-link--user .avatar img');
        const userLink = doc.querySelector('.p-navgroup-link--user, .p-account-username');
        const username = usernameEl?.textContent.trim() || avatarImg?.getAttribute('alt')?.trim() || '';
        let avatar = avatarImg?.getAttribute('src') || '';
        if (avatar && avatar.startsWith('/')) avatar = CONFIG.FORUM_ORIGIN + avatar;
        let userId = userLink ? extractUserId(userLink.getAttribute('href')) : '';
        if (!userId && avatar) {
            const m = avatar.match(/\/(\d+)\.(?:jpg|png|jpeg|gif|webp)/);
            if (m) userId = m[1];
        }
        if (!username) return null;
        return { username, avatar, userId };
    }

    async function detectProfile() {
        let profile = readProfileFromPage() || await fetchProfileFromAccount();
        if (profile) { userProfile = profile; Store.set(CONFIG.KEYS.PROFILE, profile); }
        else { userProfile = null; }
        renderTopbarUser();
        return profile;
    }

    function detectUsername() { return userProfile?.username || ''; }

    /* ============================================================
       SPLASH
       ============================================================ */
    const SPLASH_STEPS = [
        { id: 'init', label: 'Инициализация Vegas+' },
        { id: 'auth', label: 'Проходит авторизация в скрипте…' },
        { id: 'prof', label: 'Загрузка профиля пользователя' },
        { id: 'sync', label: 'Синхронизация данных' }
    ];

    const LOGO_SVG = `
        <svg viewBox="0 0 40 40" xmlns="http://www.w3.org/2000/svg">
            <defs>
                <linearGradient id="vpLogoGrad" x1="0" y1="0" x2="1" y2="1">
                    <stop offset="0%" style="stop-color: var(--accent-2);"/>
                    <stop offset="100%" style="stop-color: var(--accent);"/>
                </linearGradient>
            </defs>
            <rect width="40" height="40" rx="11" fill="url(#vpLogoGrad)"/>
            <rect width="40" height="40" rx="11" fill="none" stroke="rgba(255,255,255,.18)" stroke-width="1"/>
            <circle cx="20" cy="20" r="11" fill="#ffffff"/>
            <circle cx="16" cy="17" r="1.6" fill="#0a0e1a"/>
            <circle cx="24" cy="17" r="1.6" fill="#0a0e1a"/>
            <path d="M14 23 C16 26, 24 26, 26 23" stroke="#0a0e1a" stroke-width="1.9" fill="none" stroke-linecap="round"/>
        </svg>`;

    function buildParticles(count = 28) {
        let html = '';
        for (let i = 0; i < count; i++) {
            const left = Math.random() * 100;
            const delay = Math.random() * 8;
            const duration = 5 + Math.random() * 5;
            const size = 2 + Math.random() * 3;
            html += `<span class="vp-splash-particle" style="left:${left}%;animation-delay:-${delay}s;animation-duration:${duration}s;width:${size}px;height:${size}px;"></span>`;
        }
        return html;
    }

    function buildSplash() {
        const s = document.createElement('div');
        s.className = 'vp-splash vp-scope';
        s.dataset.theme = currentTheme;
        s.innerHTML = `
            <div class="vp-splash-particles">${buildParticles()}</div>
            <div class="vp-splash-card">
                <div class="vp-splash-logo-wrap">
                    <span class="vp-splash-ring"></span>
                    <span class="vp-splash-ring"></span>
                    <span class="vp-splash-ring"></span>
                    <div class="vp-splash-logo">
                        <svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
                            <circle cx="12" cy="12" r="9"/>
                            <path d="M8 10h.01M16 10h.01"/>
                            <path d="M8.5 14.5c.9 1 2.1 1.5 3.5 1.5s2.6-.5 3.5-1.5"/>
                        </svg>
                    </div>
                </div>
                <div class="vp-splash-title">Vegas+</div>
                <div class="vp-splash-tagline">Arizona RP · Admin Tools</div>
                <div class="vp-splash-sub" id="vp-splash-sub">Подготовка к запуску…</div>
                <div class="vp-splash-bar"><div class="vp-splash-bar-fill" id="vp-splash-bar"></div></div>
                <div class="vp-splash-steps" id="vp-splash-steps">
                    ${SPLASH_STEPS.map(s => `
                        <div class="vp-step" data-step="${s.id}">
                            <span class="vp-step-dot"></span><span>${s.label}</span>
                        </div>
                    `).join('')}
                </div>
                <div class="vp-splash-footer">
                    <span class="vp-splash-footer-dot"></span>
                    Vegas+ ${CONFIG.VERSION}
                </div>
            </div>`;
        return s;
    }

    function setStep(id, state = 'active', subText = null) {
        if (!splashEl) return;
        const el = splashEl.querySelector(`.vp-step[data-step="${id}"]`);
        if (el) {
            el.classList.remove('vp-active', 'vp-done');
            el.classList.add(state === 'done' ? 'vp-done' : 'vp-active');
        }
        if (subText) {
            const sub = splashEl.querySelector('#vp-splash-sub');
            if (sub) sub.innerHTML = subText;
        }
        const idx = SPLASH_STEPS.findIndex(s => s.id === id);
        const bar = splashEl.querySelector('#vp-splash-bar');
        if (bar && idx >= 0) bar.style.width = ((idx + 1) / SPLASH_STEPS.length * 100) + '%';
    }

    async function runSplash() {
        return new Promise(async (resolve) => {
            splashEl.classList.add('vp-show');
            setStep('init', 'active', 'Инициализация <b>Vegas+</b>…');
            await delay(420); setStep('init', 'done');
            setStep('auth', 'active', 'Проходит <b>авторизация в скрипте</b>…');
            await delay(560); setStep('auth', 'done');
            setStep('prof', 'active', 'Чтение <b>профиля пользователя</b>…');
            const prof = await detectProfile();
            await delay(340); setStep('prof', 'done',
                prof ? `Добро пожаловать, <b>${prof.username}</b>` : 'Вы не авторизованы'
            );
            setStep('sync', 'active', 'Синхронизация <b>данных</b>…');
            await delay(420); setStep('sync', 'done', 'Готово ✓');
            await delay(500);
            splashEl.classList.remove('vp-show');
            splashEl.classList.add('vp-hide');
            setTimeout(() => { splashEl?.remove(); splashEl = null; resolve(); }, 500);
        });
    }

    /* ============================================================
       ICONS
       ============================================================ */
    const ICONS = {
        home: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>`,
        eye: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7z"/><circle cx="12" cy="12" r="3"/></svg>`,
        chart: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 3v18h18"/><path d="m19 9-5 5-4-4-3 3"/></svg>`,
        award: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="8" r="6"/><path d="M15.477 12.89 17 22l-5-3-5 3 1.523-9.11"/></svg>`,
        cog: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>`,
        chevronLeft: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="m15 18-6-6 6-6"/></svg>`,
        chevronRight: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="m9 18 6-6-6-6"/></svg>`,
        refresh: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a9 9 0 1 1-3-6.7L21 8"/><path d="M21 3v5h-5"/></svg>`,
        bell: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/></svg>`,
        discord: `<svg viewBox="0 0 24 24" fill="currentColor"><path d="M20.317 4.369a19.79 19.79 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057 19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028c.462-.63.874-1.295 1.226-1.994a.076.076 0 0 0-.041-.106 13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.062 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.892.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.03zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.956-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.956 2.418-2.157 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.946 2.418-2.157 2.418z"/></svg>`,
        plus: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg>`,
        x: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg>`,
        check: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>`,
        star: `<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2l2.4 7.4H22l-6.2 4.5 2.4 7.4L12 16.8l-6.2 4.5 2.4-7.4L2 9.4h7.6z"/></svg>`,
        sparkles: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m12 3-1.9 5.8L4 10.6l5.9 1.9L12 18.3l1.9-5.8 5.9-1.9-5.9-1.9z"/><path d="M5 3v4"/><path d="M19 17v4"/><path d="M3 5h4"/><path d="M17 19h4"/></svg>`,
        gift: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="8" width="18" height="4" rx="1"/><path d="M12 8v13"/><path d="M19 12v7a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2v-7"/><path d="M7.5 8a2.5 2.5 0 0 1 0-5A4.8 8 0 0 1 12 8a4.8 8 0 0 1 4.5-5 2.5 2.5 0 0 1 0 5"/></svg>`,
        trophy: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 9H4.5a2.5 2.5 0 0 1 0-5H6"/><path d="M18 9h1.5a2.5 2.5 0 0 0 0-5H18"/><path d="M4 22h16"/><path d="M10 14.66V17c0 .55-.47.98-.97 1.21C7.85 18.75 7 20.24 7 22"/><path d="M14 14.66V17c0 .55.47.98.97 1.21C16.15 18.75 17 20.24 17 22"/><path d="M18 2H6v7a6 6 0 0 0 12 0V2Z"/></svg>`,
        users: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="8.5" cy="7" r="4"/><path d="M20 8v6"/><path d="M23 11h-6"/></svg>`,
        shuffle: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M16 3h5v5"/><path d="M4 20 21 3"/><path d="M21 16v5h-5"/><path d="m15 15 6 6"/><path d="M4 4l5 5"/></svg>`,
        shield: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>`,
        clock: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>`,
        inbox: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="22 12 16 12 14 15 10 15 8 12 2 12"/><path d="M5.45 5.11 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z"/></svg>`,
        external: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><path d="M15 3h6v6"/><path d="M10 14 21 3"/></svg>`,
        message: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>`
    };

    /* ============================================================
       APP
       ============================================================ */
    function buildApp() {
        const app = document.createElement('div');
        app.className = 'vp-app vp-scope';
        app.dataset.theme = currentTheme;
        app.innerHTML = `
            <aside class="vp-side">
                <div class="vp-side-logo">
                    <div class="vp-side-logo-icon">${LOGO_SVG}</div>
                    <div class="vp-side-logo-text">
                        <div class="vp-side-logo-title">Vegas+</div>
                        <div class="vp-side-logo-version">${CONFIG.VERSION.toUpperCase()}</div>
                    </div>
                </div>

                <div class="vp-side-section">Основное</div>
                <nav class="vp-side-nav">
                    <button class="vp-nav-item vp-active" data-view="home">${ICONS.home} Главная</button>
                    <button class="vp-nav-item" data-view="monitoring">${ICONS.eye} Мониторинг</button>
                    <button class="vp-nav-item" data-view="stats">${ICONS.chart} Статистика</button>
                    <button class="vp-nav-item" data-view="badges">${ICONS.award} Медальки</button>
                    <button class="vp-nav-item" data-view="admintools">${ICONS.sparkles} Vegas+ AdminTools <span class="vp-dev-chip">DEV</span></button>
                    <button class="vp-nav-item" data-view="settings">${ICONS.cog} Настройки</button>
                </nav>

                <div class="vp-side-bottom">
                    <a class="vp-side-link" href="${CONFIG.LINKS.DISCORD}" target="_blank">
                        ${ICONS.discord} Наш Discord
                    </a>
                    <button class="vp-side-collapse" id="vp-collapse">
                        ${ICONS.chevronLeft} Свернуть панель
                    </button>
                </div>
            </aside>

            <main class="vp-main">
                <header class="vp-topbar">
                    <div class="vp-topbar-left">
                        <button class="vp-topbar-btn" id="vp-refresh" title="Обновить">${ICONS.refresh}</button>
                    </div>
                    <div class="vp-topbar-right">
                        <button class="vp-topbar-btn" id="vp-bell" title="Уведомления">
                            ${ICONS.bell}
                            <span class="vp-bell-badge" id="vp-bell-badge">0</span>
                        </button>
                        <div class="vp-user-chip" id="vp-user-chip">
                            <span class="vp-user-chip-name" id="vp-user-chip-name">Гость</span>
                            <div class="vp-user-chip-avatar" id="vp-user-chip-avatar">?</div>
                        </div>
                    </div>
                </header>
                <div class="vp-content" id="vp-content"></div>
                <div class="vp-notif-panel" id="vp-notif-panel">
                    <div class="vp-notif-head">
                        <span>Уведомления</span>
                        <button class="vp-notif-clear" id="vp-notif-clear">Очистить</button>
                    </div>
                    <div class="vp-notif-list" id="vp-notif-list"></div>
                </div>

                <div class="vp-drawer-backdrop" id="vp-drawer-backdrop"></div>
                <div class="vp-drawer" id="vp-drawer">
                    <div class="vp-drawer-head">
                        <div class="vp-drawer-head-info">
                            <div class="vp-drawer-head-title" id="vp-drawer-title">—</div>
                            <div class="vp-drawer-head-sub" id="vp-drawer-sub">—</div>
                        </div>
                        <button class="vp-drawer-close" id="vp-drawer-close">${ICONS.x}</button>
                    </div>
                    <div class="vp-drawer-actions" id="vp-drawer-actions"></div>
                    <div class="vp-drawer-body" id="vp-drawer-body"></div>
                </div>
            </main>`;
        return app;
    }

    function bindApp() {
        appEl.querySelectorAll('.vp-nav-item[data-view]').forEach(btn => {
            btn.onclick = () => {
                closeDrawer();
                appEl.querySelectorAll('.vp-nav-item[data-view]').forEach(b => b.classList.remove('vp-active'));
                btn.classList.add('vp-active');
                currentView = btn.dataset.view;
                renderView();
            };
        });
        $('vp-collapse').onclick = () => collapseToMini();
        $('vp-refresh').onclick = () => { detectProfile(); updateStats(true); };
        $('vp-bell').onclick = () => toggleNotifPanel();
        $('vp-notif-clear').onclick = () => {
            notifications = [];
            Store.set(CONFIG.KEYS.NOTIF, []);
            renderNotifList();
            updateBellBadge();
        };
        drawerBackdropEl = $('vp-drawer-backdrop');
        drawerEl = $('vp-drawer');
        drawerBackdropEl.onclick = () => closeDrawer();
        $('vp-drawer-close').onclick = () => closeDrawer();
    }

    /* ============================================================
       DRAWER
       ============================================================ */
    function openSectionDrawer(sectionId) {
        const sec = trackedSections.find(s => s.id === sectionId);
        if (!sec) return;
        const threads = sectionThreads[sectionId] || [];
        const openThreads = threads.filter(t => !t.closed);

        $('vp-drawer-title').textContent = sec.title;
        $('vp-drawer-sub').textContent = `${threads.length} ${pluralRu(threads.length, ['жалоба','жалобы','жалоб'])} · открытых: ${openThreads.length}`;

        $('vp-drawer-actions').innerHTML = `
            <button class="vp-btn" id="vp-drawer-refresh">${ICONS.refresh} Обновить</button>
            <a class="vp-btn" href="${sec.url}" target="_blank" style="text-decoration:none;">${ICONS.external} Открыть на форуме</a>`;

        $('vp-drawer-refresh').onclick = () => {
            refreshSectionThreads(sectionId).then(() => openSectionDrawer(sectionId));
        };

        const body = $('vp-drawer-body');
        if (!threads.length) {
            body.innerHTML = `<div class="vp-drawer-empty">
                Нет жалоб в этом разделе<br>
                <span style="opacity:.6;font-size:11px;">Обнови мониторинг</span>
            </div>`;
        } else {
            body.innerHTML = threads.map(t => `
                <a class="vp-drawer-thread ${t.closed ? 'vp-closed' : 'vp-open'}" href="${t.url}" target="_blank">
                    <div class="vp-drawer-thread-icon">${t.closed ? ICONS.check : ICONS.message}</div>
                    <div class="vp-drawer-thread-body">
                        <div class="vp-drawer-thread-title">${t.title || 'Без названия'}</div>
                        <div class="vp-drawer-thread-meta">
                            <span class="vp-drawer-thread-tag ${t.closed ? 'vp-closed' : 'vp-open'}">${t.closed ? 'Закрыта' : 'Открыта'}</span>
                            <span>#${t.id}</span>
                        </div>
                    </div>
                    <div class="vp-drawer-thread-arrow">${ICONS.chevronRight}</div>
                </a>`).join('');
        }

        drawerEl.classList.add('vp-open');
        drawerBackdropEl.classList.add('vp-show');
        requestAnimationFrame(() => drawerEl.classList.add('vp-visible'));
    }

    function closeDrawer() {
        if (!drawerEl) return;
        drawerEl.classList.remove('vp-visible');
        drawerBackdropEl.classList.remove('vp-show');
        setTimeout(() => drawerEl.classList.remove('vp-open'), 300);
    }

    /* ============================================================
       VIEWS
       ============================================================ */
    function renderView() {
        const content = $('vp-content');
        if (!content) return;
        if (currentView === 'home') renderHome(content);
        else if (currentView === 'monitoring') renderMonitoring(content);
        else if (currentView === 'stats') renderStatsView(content);
        else if (currentView === 'badges') renderBadgesView(content);
        else if (currentView === 'admintools') renderAdminsToolsView(content);
        else if (currentView === 'settings') renderSettingsView(content);
    }

    function renderTopbarUser() {
        if (!appEl) return;
        const nameEl = $('vp-user-chip-name');
        const avatarEl = $('vp-user-chip-avatar');
        if (!nameEl || !avatarEl) return;
        if (userProfile) {
            nameEl.textContent = userProfile.username || 'Гость';
            if (userProfile.avatar) avatarEl.innerHTML = `<img src="${userProfile.avatar}" alt="">`;
            else avatarEl.textContent = (userProfile.username[0] || '?').toUpperCase();
        } else {
            nameEl.textContent = 'Гость';
            avatarEl.textContent = '?';
        }
    }

    function renderFlameCard() {
        const f = getFlameDisplay();
        const level = getFlameLevel(f.streak);
        const thresholds = getFlameThresholds();
        const nextThreshold = thresholds[Math.min(level + 1, thresholds.length - 1)];
        const remaining = Math.max(0, nextThreshold - f.streak);

        const sparks = level >= 3
            ? `<span class="vp-flame-spark"></span><span class="vp-flame-spark"></span><span class="vp-flame-spark"></span><span class="vp-flame-spark"></span>`
            : '';

        let hintHtml;
        if (level >= 5) {
            hintHtml = `<div class="vp-flame-hint vp-flame-max">🔥 Максимальный уровень</div>`;
        } else if (!f.alive && f.streak === 0 && f.best > 0) {
            hintHtml = `<div class="vp-flame-hint">Пламя погасло · Лучший стрик: ${f.best} дн.</div>`;
        } else {
            hintHtml = `<div class="vp-flame-hint">До след. уровня: ${remaining} ${pluralRu(remaining, ['день','дня','дней'])}</div>`;
        }

        const btnDisabled = f.checkedToday;
        const btnText = f.checkedToday ? '✓ Отмечено сегодня' : '🔥 Отметиться';

        return `
            <div class="vp-flame-card">
                <div class="vp-flame-visual vp-flame-lv${level}">
                    ${sparks}
                    <span class="vp-flame-emoji">🔥</span>
                </div>
                <div class="vp-flame-info">
                    <div class="vp-flame-title">Твоё пламя · Стрик посещений</div>
                    <div class="vp-flame-streak">
                        <span class="vp-flame-streak-num">${f.streak}</span>
                        <span class="vp-flame-streak-label">${pluralRu(f.streak, ['день','дня','дней'])} подряд</span>
                    </div>
                    <div class="vp-flame-stats">
                        <span>Лучший: <b>${f.best}</b></span>
                        <span>·</span>
                        <span>Всего: <b>${f.total}</b></span>
                    </div>
                    ${hintHtml}
                </div>
                <button class="vp-flame-btn ${btnDisabled ? 'vp-flame-btn-disabled' : ''}"
                        id="vp-flame-check"
                        ${btnDisabled ? 'disabled' : ''}>
                    ${btnText}
                </button>
            </div>`;
    }

    function renderHome(content) {
        const ctx = getBadgeContext();
        const isDev = userProfile?.userId === CONFIG.DEV_ID;
        const username = userProfile?.username || 'Гость';
        const letter = (username[0] || '?').toUpperCase();
        const avatarHtml = userProfile?.avatar
            ? `<img src="${userProfile.avatar}" alt="">` : letter;

        const tagHtml = isDev
            ? `<span class="vp-hero-tag vp-tag-dev">${ICONS.star} DEVELOPER</span>`
            : `<span class="vp-hero-tag">🛡 ARIZONA RP</span>`;

        content.innerHTML = `
            <div class="vp-welcome">С возвращением, ${username}! ❤️</div>

            <div class="vp-service" id="vp-service-card">
                <div class="vp-service-icon">${ICONS.sparkles}</div>
                <div class="vp-service-text">
                    <div class="vp-service-title">
                        Vegas+ AdminTools
                        <span class="vp-service-dev">IN DEV</span>
                    </div>
                    <div class="vp-service-sub">Инструменты для команд администрации серверов</div>
                </div>
                <div class="vp-service-arrow">${ICONS.chevronRight}</div>
            </div>

            ${renderFlameCard()}

            <div class="vp-hero">
                <div class="vp-hero-avatar">${avatarHtml}</div>
                <div class="vp-hero-body">
                    <div class="vp-hero-name-row">
                        <div class="vp-hero-name">${username}</div>
                        ${tagHtml}
                    </div>
                    <div class="vp-hero-chips">
                        <span class="vp-chip">${ICONS.inbox} Получено: <b>${ctx.totalReceived}</b></span>
                        <span class="vp-chip">${ICONS.award} Медалей: <b>${earnedBadges.length}</b></span>
                        <span class="vp-chip">${ICONS.eye} Разделов: <b>${trackedSections.length}</b></span>
                        <span class="vp-chip">${ICONS.clock} С Vegas+: <b>${ctx.daysSinceInstall}</b> дн.</span>
                    </div>
                </div>
            </div>`;

        $('vp-service-card').onclick = () => {
            appEl.querySelectorAll('.vp-nav-item[data-view]').forEach(b => b.classList.remove('vp-active'));
            appEl.querySelector('.vp-nav-item[data-view="admintools"]')?.classList.add('vp-active');
            currentView = 'admintools';
            renderView();
        };

        $('vp-flame-check')?.addEventListener('click', checkInFlame);
    }

    function renderMonitoring(content) {
        if (!trackedSections.length) {
            content.innerHTML = `
                <div class="vp-page-title">Мониторинг</div>
                <div class="vp-page-sub">Отслеживаемые разделы форума</div>
                <div class="vp-card"><div class="vp-empty">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>
                    <div class="vp-empty-text">Добавьте разделы в Настройках</div>
                </div></div>`;
            return;
        }
        content.innerHTML = `
            <div class="vp-page-title">Мониторинг</div>
            <div class="vp-page-sub">${trackedSections.length} ${pluralRu(trackedSections.length, ['раздел','раздела','разделов'])} отслеживается · клик для просмотра</div>
            <div id="vp-content-list" style="display:flex;flex-direction:column;gap:8px;"></div>`;
        const list = $('vp-content-list');
        list.innerHTML = trackedSections.map(sec => {
            const threads = sectionThreads[sec.id] || [];
            const cnt = threads.length;
            return `
                <div class="vp-row" data-section-id="${sec.id}">
                    <span class="vp-row-title">${sec.title}</span>
                    <span class="vp-badge-count ${cnt > 0 ? 'vp-has' : 'vp-clear'}">${cnt}</span>
                    <span style="color:var(--text-mute);flex-shrink:0;">${ICONS.chevronRight}</span>
                </div>`;
        }).join('');
        list.querySelectorAll('.vp-row[data-section-id]').forEach(row => {
            row.onclick = () => openSectionDrawer(row.dataset.sectionId);
        });
        updateStats(true);
    }

    function renderStatsView(content) {
        content.innerHTML = `
            <div class="vp-page-title">Статистика</div>
            <div class="vp-page-sub">Расчёт закрытых жалоб за период</div>

            <div class="vp-card">
                <div class="vp-field">
                    <span>Период, дней</span>
                    <input type="number" id="vp-days" class="vp-input" style="width:90px;text-align:center;"
                        value="${Store.get(CONFIG.KEYS.DAYS, 7)}" min="1" max="365">
                </div>
                <div class="vp-label">Родительский раздел</div>
                <div style="display:flex;gap:8px;">
                    <input type="text" id="vp-parent-url" class="vp-input" placeholder="/forums/523/"
                        value="${Store.get(CONFIG.KEYS.STATS_PARENT_URL, '')}">
                    <button class="vp-btn" id="vp-fetch-sub" style="flex-shrink:0;">Загрузить</button>
                </div>
                <div class="vp-sublist" id="vp-sublist"></div>
            </div>

            <div id="vp-stats-container"></div>

            <button class="vp-btn vp-primary" id="vp-calc" style="padding:12px;">${ICONS.chart} Рассчитать статистику</button>`;

        $('vp-fetch-sub').onclick = fetchSubsectionsFromParent;
        $('vp-calc').onclick = calculateMyClosedComplaints;
        $('vp-days').onchange = e => Store.set(CONFIG.KEYS.DAYS, Math.max(1, parseInt(e.target.value, 10) || 1));
        renderSubsectionsList(fetchedSubsections);
    }

    function renderBadgesView(content) {
        const ctx = getBadgeContext();
        earnedBadges = BADGES.filter(b => b.check(ctx));
        const earnedIds = new Set(earnedBadges.map(b => b.id));
        const topIcon = earnedBadges.find(b => b.tier === 'special')?.icon
            || earnedBadges.find(b => b.tier === 'legendary')?.icon
            || earnedBadges.find(b => b.tier === 'gold')?.icon || '🏅';

        const tierNames = { bronze: 'Bronze', silver: 'Silver', gold: 'Gold', platinum: 'Platinum', legendary: 'Legendary', special: 'Special' };

        content.innerHTML = `
            <div class="vp-page-title">Медальки</div>
            <div class="vp-page-sub">Достижения за жалобы, найденные мониторингом</div>

            <div class="vp-badges-summary">
                <div class="vp-badges-summary-l">
                    <span class="vp-badges-summary-title">Открыто медалей</span>
                    <span class="vp-badges-summary-count">${earnedBadges.length}<small>/${BADGES.length}</small></span>
                </div>
                <span class="vp-badges-summary-icon">${topIcon}</span>
            </div>

            <div class="vp-badges-list">
                ${BADGES.map(b => {
                    const earned = earnedIds.has(b.id);
                    const p = b.progress(ctx);
                    const pct = Math.min(100, Math.round((p.now / p.max) * 100));
                    return `
                        <div class="vp-badge-card ${earned ? 'vp-earned' : 'vp-locked'} vp-tier-${b.tier}">
                            <div class="vp-badge-ic">${b.icon}</div>
                            <div class="vp-badge-body">
                                <div class="vp-badge-head">
                                    <span class="vp-badge-name">${b.name}</span>
                                    <span class="vp-badge-tier vp-${b.tier}">${tierNames[b.tier] || b.tier}</span>
                                    ${earned ? `<span class="vp-badge-check">${ICONS.check}</span>` : ''}
                                </div>
                                <div class="vp-badge-desc">${b.desc}</div>
                                <div class="vp-badge-how">Как получить: <b>${b.how}</b></div>
                                <div class="vp-badge-progress-wrap">
                                    <div class="vp-badge-progress"><div class="vp-badge-progress-fill" style="width:${pct}%"></div></div>
                                    <span class="vp-badge-progress-num">${p.now}/${p.max}</span>
                                </div>
                            </div>
                        </div>`;
                }).join('')}
            </div>`;
    }

    function renderAdminsToolsView(content) {
        content.innerHTML = `
            <div class="vp-page-title">Vegas+ AdminTools</div>
            <div class="vp-page-sub">Внутренние инструменты для команд администрации серверов</div>

            <div class="vp-admintools-hero">
                <div class="vp-admintools-icon">${ICONS.sparkles}</div>
                <div class="vp-admintools-title">
                    Vegas+ AdminTools
                    <span class="vp-admintools-badge">В разработке</span>
                </div>
                <div class="vp-admintools-desc">
                    Набор сервисов для организации работы коллектива администрации:
                    система розыгрышей и конкурсов между админами, автоматизация наград,
                    подсчёт активностей и рейтинг состава.
                </div>
            </div>

            <div class="vp-features-grid">
                <div class="vp-feature">
                    <div class="vp-feature-icon">${ICONS.gift}</div>
                    <div class="vp-feature-body">
                        <div class="vp-feature-title">Система розыгрышей</div>
                        <div class="vp-feature-text">Автоматические розыгрыши призов между администраторами сервера.</div>
                        <span class="vp-feature-status">В разработке</span>
                    </div>
                </div>

                <div class="vp-feature">
                    <div class="vp-feature-icon">${ICONS.trophy}</div>
                    <div class="vp-feature-body">
                        <div class="vp-feature-title">Рейтинг состава</div>
                        <div class="vp-feature-text">Таблица лидеров по активности и качеству работы за период.</div>
                        <span class="vp-feature-status">В разработке</span>
                    </div>
                </div>

                <div class="vp-feature">
                    <div class="vp-feature-icon">${ICONS.users}</div>
                    <div class="vp-feature-body">
                        <div class="vp-feature-title">Конкурсы коллектива</div>
                        <div class="vp-feature-text">Внутрикомандные соревнования с автоматическим подведением итогов.</div>
                        <span class="vp-feature-status vp-soon">Скоро</span>
                    </div>
                </div>

                <div class="vp-feature">
                    <div class="vp-feature-icon">${ICONS.shuffle}</div>
                    <div class="vp-feature-body">
                        <div class="vp-feature-title">Random-активности</div>
                        <div class="vp-feature-text">Случайные челленджи дня или недели для администрации.</div>
                        <span class="vp-feature-status vp-soon">Скоро</span>
                    </div>
                </div>

                <div class="vp-feature">
                    <div class="vp-feature-icon">${ICONS.shield}</div>
                    <div class="vp-feature-body">
                        <div class="vp-feature-title">Аудит действий</div>
                        <div class="vp-feature-text">История по каждому админу с фильтрами по разделу и периоду.</div>
                        <span class="vp-feature-status vp-soon">Скоро</span>
                    </div>
                </div>

                <div class="vp-feature">
                    <div class="vp-feature-icon">${ICONS.sparkles}</div>
                    <div class="vp-feature-body">
                        <div class="vp-feature-title">Кастомные награды</div>
                        <div class="vp-feature-text">Создание персональных достижений для сервера.</div>
                        <span class="vp-feature-status vp-soon">Скоро</span>
                    </div>
                </div>
            </div>

            <div class="vp-card" style="margin-top:6px;">
                <div class="vp-label">Обратная связь</div>
                <div style="font-size:12.5px;color:var(--text-dim);line-height:1.6;">
                    Хочешь предложить идею для AdminTools или помочь с разработкой?
                    Заходи в наш Discord.
                </div>
                <a class="vp-btn vp-primary" href="${CONFIG.LINKS.DISCORD}" target="_blank" style="text-decoration:none;margin-top:4px;">
                    ${ICONS.discord} Присоединиться к Discord
                </a>
            </div>`;
    }

    function renderSettingsView(content) {
        const desktopOn = Store.get(CONFIG.KEYS.DESKTOP_NOTIF, true);
        const tgInfo = getTgInfo();
        const tgConnected = isTgConnected();

        const tgStatusHtml = tgConnected
            ? `<div class="vp-tg-status vp-connected">
                    <span class="vp-tg-status-dot"></span>
                    <div class="vp-tg-status-info">
                        <div class="vp-tg-status-title">Подключено${tgInfo.username ? ' · @' + escapeHtml(tgInfo.username) : ''}</div>
                        <div class="vp-tg-status-desc">Уведомления ${tgInfo.enabled ? 'включены' : 'выключены'}</div>
                    </div>
                    <button class="vp-tg-status-btn" id="vp-tg-reconnect">Переподключить</button>
               </div>`
            : `<div class="vp-tg-status">
                    <span class="vp-tg-status-dot"></span>
                    <div class="vp-tg-status-info">
                        <div class="vp-tg-status-title">Не подключено</div>
                        <div class="vp-tg-status-desc">Бот @${TG_BOT}</div>
                    </div>
                    <button class="vp-tg-status-btn vp-primary" id="vp-tg-connect">Подключить</button>
               </div>`;

        content.innerHTML = `
            <div class="vp-page-title">Настройки</div>
            <div class="vp-page-sub">Персонализация Vegas+</div>

            <div class="vp-card">
                <div class="vp-label">Уведомления</div>
                <div class="vp-toggle-row">
                    <div class="vp-toggle-row-info">
                        <div class="vp-toggle-row-title">Windows-уведомления</div>
                        <div class="vp-toggle-row-desc">Системные уведомления при новой жалобе с твоим ником</div>
                    </div>
                    <div class="vp-toggle ${desktopOn ? 'vp-on' : ''}" id="vp-desktop-toggle"></div>
                </div>

                <div class="vp-tg-block">
                    <div class="vp-tg-block-head">
                        <div class="vp-tg-block-icon">
                            <svg viewBox="0 0 24 24" fill="currentColor"><path d="M9.78 18.65l.28-4.23 7.68-6.92c.34-.31-.07-.46-.52-.19L7.74 13.3 3.64 12c-.88-.25-.89-.86.2-1.3l15.97-6.16c.73-.33 1.43.18 1.15 1.3l-2.72 12.81c-.19.91-.74 1.13-1.5.71L12.6 16.3l-1.99 1.93c-.23.23-.42.42-.83.42z"/></svg>
                        </div>
                        <div class="vp-tg-block-info">
                            <div class="vp-tg-block-title">Telegram-уведомления</div>
                            <div class="vp-tg-block-desc">Мгновенные уведомления в Telegram через @${TG_BOT}</div>
                        </div>
                        ${tgConnected ? `<div class="vp-toggle ${tgInfo.enabled ? 'vp-on' : ''}" id="vp-tg-toggle"></div>` : ''}
                    </div>
                    ${tgStatusHtml}
                </div>
            </div>

            <div class="vp-card">
                <div class="vp-label">Тема оформления</div>
                <div class="vp-theme-grid" id="vp-theme-grid"></div>
            </div>

            <div class="vp-card">
                <div class="vp-label">Профиль</div>
                <div class="vp-user-card" id="vp-user-card"></div>
            </div>

            <div class="vp-card">
                <div class="vp-label">Отслеживаемые разделы</div>
                <div id="vp-manage-list" style="max-height:240px;overflow-y:auto;display:flex;flex-direction:column;gap:6px;"></div>
                <div style="display:flex;gap:8px;">
                    <input type="text" class="vp-input" id="vp-new-url" placeholder="https://forum.arizona-rp.com/forums/…">
                    <button class="vp-btn vp-primary" id="vp-add" style="flex-shrink:0;padding:9px 14px;">${ICONS.plus}</button>
                </div>
            </div>`;

        renderThemeGrid();
        renderUserCard();
        renderSettingsList();

        $('vp-add').onclick = handleAddSection;
        $('vp-desktop-toggle').onclick = () => {
            const cur = Store.get(CONFIG.KEYS.DESKTOP_NOTIF, true);
            Store.set(CONFIG.KEYS.DESKTOP_NOTIF, !cur);
            renderSettingsView(content);
        };
        if ($('vp-tg-toggle')) $('vp-tg-toggle').onclick = () => toggleTg();
        if ($('vp-tg-connect')) $('vp-tg-connect').onclick = () => connectTelegram();
        if ($('vp-tg-reconnect')) $('vp-tg-reconnect').onclick = () => {
            if (confirm('Переподключить Telegram? Текущий аккаунт будет отключён.')) disconnectTelegram();
        };
    }

    function renderUserCard() {
        const c = $('vp-user-card');
        if (!c) return;
        if (!userProfile) {
            c.innerHTML = `
                <div class="vp-user-avatar">?</div>
                <div class="vp-user-info">
                    <div class="vp-user-name">Гость</div>
                    <div class="vp-user-status">Не авторизован</div>
                </div>
                <a class="vp-btn" href="${CONFIG.FORUM_ORIGIN}/login/" target="_blank" style="text-decoration:none;">Войти</a>`;
            return;
        }
        const letter = (userProfile.username[0] || '?').toUpperCase();
        const av = userProfile.avatar ? `<img src="${userProfile.avatar}" alt="">` : letter;
        c.innerHTML = `
            <div class="vp-user-avatar">${av}</div>
            <div class="vp-user-info">
                <div class="vp-user-name">${userProfile.username}</div>
                <div class="vp-user-status vp-online">Авторизован${userProfile.userId ? ' · ID ' + userProfile.userId : ''}</div>
            </div>`;
    }

    function renderThemeGrid() {
        const g = $('vp-theme-grid');
        if (!g) return;
        g.innerHTML = Object.entries(THEMES).map(([key, t]) => `
            <div class="vp-theme-swatch ${key === currentTheme ? 'vp-active' : ''}"
                data-theme="${key}" title="${t.name}"
                style="background: linear-gradient(135deg, ${t.accent2}, ${t.accent});">
                ${t.name.replace(/^[^\wа-яА-ЯёЁ]+\s*/, '')}
            </div>`).join('');
        g.querySelectorAll('.vp-theme-swatch').forEach(sw => {
            sw.onclick = () => applyTheme(sw.dataset.theme);
        });
    }

    function applyTheme(key) {
        if (!THEMES[key]) return;
        currentTheme = key;
        Store.set(CONFIG.KEYS.THEME, key);
        [appEl, miniEl, splashEl].forEach(el => { if (el) el.dataset.theme = key; });
        renderThemeGrid();
    }

    function renderSettingsList() {
        const el = $('vp-manage-list');
        if (!el) return;
        if (!trackedSections.length) {
            el.innerHTML = `<div class="vp-empty" style="padding:20px 8px;">
                <div class="vp-empty-text">Разделы не добавлены</div>
            </div>`;
            return;
        }
        el.innerHTML = trackedSections.map((sec, i) => `
            <div class="vp-row" style="cursor:default;">
                <span class="vp-row-title">${sec.title}</span>
                <span class="vp-del" data-idx="${i}">${ICONS.x}</span>
            </div>`).join('');
        el.querySelectorAll('.vp-del').forEach(btn => {
            btn.onclick = () => {
                const removed = trackedSections.splice(+btn.dataset.idx, 1)[0];
                if (removed) delete sectionThreads[removed.id];
                Store.set(CONFIG.KEYS.SECTIONS, trackedSections);
                renderSettingsList();
                updateStats();
            };
        });
    }

    function renderSubsectionsList(subsections) {
        const c = $('vp-sublist');
        if (!c) return;
        if (!subsections.length) {
            c.innerHTML = `<div class="vp-empty" style="padding:16px 6px;">
                <div class="vp-empty-text">Разделы не загружены</div>
            </div>`;
            return;
        }
        c.innerHTML = subsections.map(s => `
            <label class="vp-sub" title="${s.title}">
                <input type="checkbox" data-id="${s.id}" ${s.selected ? 'checked' : ''}>
                <span>${s.title}</span>
            </label>`).join('');
        c.querySelectorAll('input[type="checkbox"]').forEach(cb => {
            cb.onchange = () => {
                const s = subsections.find(x => x.id === cb.dataset.id);
                if (s) s.selected = cb.checked;
                Store.set(CONFIG.KEYS.STATS_SELECTED_SUBSECTIONS, fetchedSubsections);
            };
        });
    }

    /* ============================================================
       BADGE CONTEXT
       ============================================================ */
    function getBadgeContext() {
        const receivedArr = Store.get(CONFIG.KEYS.RECEIVED_IDS, []) || [];
        const installDate = Store.get(CONFIG.KEYS.INSTALL_DATE, Date.now());
        const hour = new Date().getHours();
        const v = Store.get(CONFIG.KEYS.VISITS, { early: false, late: false }) || {};
        if (hour < 8) { v.early = true; Store.set(CONFIG.KEYS.VISITS, v); }
        if (hour >= 23) { v.late = true; Store.set(CONFIG.KEYS.VISITS, v); }
        const flame = getFlameDisplay();
        return {
            userId: userProfile?.userId || '',
            username: userProfile?.username || '',
            totalReceived: receivedArr.length,
            sectionsCount: trackedSections.length,
            daysSinceInstall: Math.floor((Date.now() - installDate) / 86400000),
            badgesCount: earnedBadges.length,
            earlyVisit: !!v.early,
            lateVisit: !!v.late,
            flameStreak: flame.streak
        };
    }

    function checkNewBadges() {
        const ctx = getBadgeContext();
        const before = new Set(earnedBadges.map(b => b.id));
        earnedBadges = BADGES.filter(b => b.check(ctx));
        if (before.size > 0) {
            earnedBadges.forEach(b => {
                if (!before.has(b.id)) {
                    addNotification(`${b.icon} Медаль «${b.name}»!`, b.desc, 'badge', b.icon);
                }
            });
        }
    }

    /* ============================================================
       OPEN / COLLAPSE
       ============================================================ */
    function openApp() {
        if (!appEl || !backdropEl) return;
        backdropEl.classList.add('vp-show');
        appEl.classList.add('vp-open');
        requestAnimationFrame(() => appEl.classList.add('vp-visible'));
        miniEl.classList.remove('vp-show');
        Store.set(CONFIG.KEYS.MODE, 'modal');
        renderView();
        updateStats(true);
    }

    function collapseToMini() {
        if (!appEl || !miniEl || !backdropEl) return;
        closeDrawer();
        appEl.classList.remove('vp-visible');
        backdropEl.classList.remove('vp-show');
        if (notifPanelEl) notifPanelEl.classList.remove('vp-open', 'vp-visible');
        setTimeout(() => {
            appEl.classList.remove('vp-open');
            miniEl.classList.add('vp-show');
        }, 300);
        Store.set(CONFIG.KEYS.MODE, 'mini');
    }

    /* ============================================================
       ACTIONS
       ============================================================ */
    async function fetchForumTitle(url) {
        const forumId = (url.match(/\/forums\/(\d+)/) || [])[1] || '???';
        const html = await fetchHtml(url);
        if (!html) return `Раздел #${forumId}`;
        const m = html.match(/<h1 class="p-title-value"[^>]*>([\s\S]*?)<\/h1>/i);
        return m ? m[1].replace(/<[^>]+>/g, '').trim() : `Раздел #${forumId}`;
    }

    async function handleAddSection() {
        const input = $('vp-new-url');
        const url = input.value.trim();
        const m = url.match(/\/forums\/(\d+)/);
        if (!m) return addNotification('⚠️ Ошибка', 'Некорректная ссылка на раздел', 'error', '⚠️');
        const id = m[1];
        if (trackedSections.some(s => s.id === id)) return addNotification('⚠️ Уже добавлен', 'Этот раздел уже в мониторинге', 'warn', '⚠️');
        const btn = $('vp-add'); btn.disabled = true;
        const title = await fetchForumTitle(url);
        trackedSections.push({ id, title, url: `${CONFIG.FORUM_ORIGIN}/forums/${id}/` });
        Store.set(CONFIG.KEYS.SECTIONS, trackedSections);
        input.value = ''; btn.disabled = false;
        renderSettingsList();
        updateStats();
        addNotification('✅ Раздел добавлен', `«${title}» теперь в мониторинге`, 'success', '✅');
    }

    async function fetchSubsectionsFromParent() {
        const url = $('vp-parent-url').value.trim();
        if (!url.includes('/forums/')) return addNotification('⚠️ Ошибка', 'Укажите корректную ссылку', 'warn', '⚠️');
        const btn = $('vp-fetch-sub'); btn.disabled = true; btn.textContent = '…';
        Store.set(CONFIG.KEYS.STATS_PARENT_URL, url);
        const html = await fetchHtml(url);
        btn.disabled = false; btn.textContent = 'Загрузить';
        if (!html) return addNotification('⚠️ Ошибка', 'Не удалось загрузить страницу', 'error', '⚠️');
        const doc = new DOMParser().parseFromString(html, 'text/html');
        const nodes = doc.querySelectorAll('.node-body .node-title a');
        if (!nodes.length) return addNotification('⚠️ Ничего', 'Подразделы не найдены', 'warn', '⚠️');
        fetchedSubsections = Array.from(nodes).map(a => {
            const id = (a.getAttribute('href').match(/\/forums\/(\d+)/) || [])[1];
            if (!id) return null;
            const ex = fetchedSubsections.find(s => s.id === id);
            return { id, title: a.textContent.trim(), url: `${CONFIG.FORUM_ORIGIN}/forums/${id}/`, selected: ex ? ex.selected : true };
        }).filter(Boolean);
        Store.set(CONFIG.KEYS.STATS_SELECTED_SUBSECTIONS, fetchedSubsections);
        renderSubsectionsList(fetchedSubsections);
        addNotification('📥 Загружено', `${fetchedSubsections.length} ${pluralRu(fetchedSubsections.length, ['раздел','раздела','разделов'])}`, 'success', '📥');
    }

    async function refreshSectionThreads(sectionId) {
        const sec = trackedSections.find(s => s.id === sectionId);
        if (!sec) return;
        const html = await fetchHtml(sec.url);
        if (!html) return;
        const doc = new DOMParser().parseFromString(html, 'text/html');
        sectionThreads[sectionId] = parseThreadsFromDoc(doc);
    }

    /* ============================================================
       PARSING — обновлено под XenForo 2.3 (js-threadListItem-NNNN)
       ============================================================ */
    function parseThreadsFromDoc(doc) {
        const out = [];
        doc.querySelectorAll('.structItem--thread:not(.structItem--sticky)').forEach(t => {
            // ID любым способом
            let id = '';
            const cls = t.className || '';
            let m = cls.match(/js-threadListItem-(\d+)/);
            if (m) id = m[1];

            if (!id) {
                const dc = t.getAttribute('data-content') || '';
                const mm = dc.match(/thread-(\d+)/);
                if (mm) id = mm[1];
            }

            if (!id) {
                const a = t.querySelector('a[href*="/threads/"]');
                if (a) {
                    const m2 = (a.getAttribute('href') || '').match(/\.(\d+)\/?/);
                    if (m2) id = m2[1];
                }
            }
            if (!id) return;

            const titleEl = t.querySelector('.structItem-title a[href*="/threads/"]:not([href*="/unread"]):not([href*="/latest"])');
            const title = titleEl?.textContent.trim() || '';
            const href = titleEl?.getAttribute('href') || '';
            const url = href ? (href.startsWith('http') ? href : CONFIG.FORUM_ORIGIN + href) : `${CONFIG.FORUM_ORIGIN}/threads/${id}/`;

            const prefix = t.querySelector('a.labelLink')?.getAttribute('href') || '';
            const pm = prefix.match(/prefix_id=(\d+)/);
            const isClosedPrefix = pm && CONFIG.PREFIX_CLOSED.has(pm[1]);
            const isClosedClass = t.classList.contains('is-prefix17') || t.classList.contains('is-prefix18');
            const isLocked = !!t.querySelector('.structItem-status--locked');
            const closed = !!(isClosedPrefix || isClosedClass || isLocked);

            out.push({ id, title, url, closed });
        });
        return out;
    }

    function extractThreadIdsFromDoc(doc) {
        const ids = new Set();
        doc.querySelectorAll('.structItem--thread:not(.structItem--sticky)').forEach(t => {
            // Способ 1: js-threadListItem-NNNN
            const cls = t.className || '';
            let m = cls.match(/js-threadListItem-(\d+)/);
            if (m) { ids.add(m[1]); return; }

            // Способ 2: data-content
            const dc = t.getAttribute('data-content') || '';
            m = dc.match(/thread-(\d+)/);
            if (m) { ids.add(m[1]); return; }

            // Способ 3: ссылка
            const a = t.querySelector('a[href*="/threads/"]');
            if (a) {
                const m2 = (a.getAttribute('href') || '').match(/\.(\d+)\/?/);
                if (m2) ids.add(m2[1]);
            }
        });
        return ids;
    }

    function processThreadPage(html, username, cutoff) {
        if (!html) return { myClosedCount: 0, totalClosedCount: 0, stopSection: true, ids: new Set() };
        const doc = new DOMParser().parseFromString(html, 'text/html');
        const threads = doc.querySelectorAll('.structItem--thread:not(.structItem--sticky)');
        if (!threads.length) return { myClosedCount: 0, totalClosedCount: 0, stopSection: true, ids: new Set() };
        let myClosedCount = 0, totalClosedCount = 0, oldCount = 0;
        const lower = username.toLowerCase();
        const ids = new Set();
        threads.forEach(thread => {
            // ID любым способом
            const cls = thread.className || '';
            let im = cls.match(/js-threadListItem-(\d+)/);
            if (im) {
                ids.add(im[1]);
            } else {
                const dc = thread.getAttribute('data-content') || '';
                im = dc.match(/thread-(\d+)/);
                if (im) ids.add(im[1]);
            }

            const timeEl = thread.querySelector('.structItem-cell--latest time.u-dt, time.structItem-latestDate');
            const ts = timeEl ? parseInt(timeEl.getAttribute('data-timestamp'), 10) : 0;
            if (ts && ts < cutoff) { oldCount++; return; }
            const text = thread.innerText || '';
            const isClosed = thread.classList.contains('is-prefix17') ||
                             thread.classList.contains('is-prefix18') ||
                             thread.querySelector('a.labelLink[href*="prefix_id=17"], a.labelLink[href*="prefix_id=18"]') !== null ||
                             text.includes('Рассмотрено') || text.includes('Отказано');
            if (isClosed) {
                totalClosedCount++;
                const latest = thread.querySelector('.structItem-cell--latest .username, .structItem-cell--latest [data-user-id]');
                if (latest?.textContent.trim().toLowerCase() === lower) myClosedCount++;
            }
        });
        return { myClosedCount, totalClosedCount, stopSection: threads.length === oldCount, ids };
    }

    /* ============================================================
       STATISTICS
       ============================================================ */
    async function calculateMyClosedComplaints() {
        const username = detectUsername();
        if (!username) return addNotification('⚠️ Ошибка', 'Не удалось определить ник — войдите на форум', 'error', '⚠️');
        const target = fetchedSubsections.filter(s => s.selected).length
            ? fetchedSubsections.filter(s => s.selected) : [...trackedSections];
        if (!target.length) return addNotification('⚠️ Ошибка', 'Выберите хотя бы один раздел', 'warn', '⚠️');

        const btn = $('vp-calc'), container = $('vp-stats-container');
        btn.disabled = true; isBusy = true;

        const days = parseInt($('vp-days').value, 10) || 7;
        const cutoff = Math.floor(Date.now() / 1000) - days * 86400;
        let grandMy = 0, grandTotal = 0;
        const rows = [];

        for (const sec of target) {
            let page = 1, stop = false, my = 0, total = 0;
            while (!stop) {
                btn.textContent = `Стр. ${page}…`;
                const batch = Array.from({ length: CONFIG.BATCH_SIZE }, (_, i) => page + i);
                const results = await Promise.all(
                    batch.map(p => fetchHtml(`${CONFIG.FORUM_ORIGIN}/forums/${sec.id}/page-${p}?no_date_limit=1`))
                );
                for (const html of results) {
                    const r = processThreadPage(html, username, cutoff);
                    my += r.myClosedCount; total += r.totalClosedCount;
                    if (r.stopSection) { stop = true; break; }
                }
                page += CONFIG.BATCH_SIZE;
                if (!stop) await delay(300);
            }
            grandMy += my; grandTotal += total;
            const pct = total > 0 ? Math.round((my / total) * 100) : 0;
            rows.push({ title: sec.title, my, total, pct });
        }

        let html = '<div class="vp-card"><div class="vp-stats">';
        rows.forEach(r => {
            html += `
                <div class="vp-stat">
                    <div class="vp-stat-head">
                        <span class="vp-stat-name">${r.title}</span>
                        <span class="vp-stat-value">${r.my}<small>${r.pct}%</small></span>
                    </div>
                    <div class="vp-progress"><div class="vp-progress-fill" style="width:${r.pct}%"></div></div>
                </div>`;
        });
        if (target.length > 1) {
            const gp = grandTotal > 0 ? Math.round((grandMy / grandTotal) * 100) : 0;
            html += `
                <div class="vp-stat vp-total">
                    <div class="vp-stat-head">
                        <span class="vp-stat-name">Итого за ${days} дн.</span>
                        <span class="vp-stat-value">${grandMy}<small>${gp}%</small></span>
                    </div>
                    <div class="vp-progress"><div class="vp-progress-fill" style="width:${gp}%"></div></div>
                </div>`;
        }
        html += '</div></div>';
        container.innerHTML = html;

        lastStats = { grandMy, grandTotal, rows, days, ts: Date.now() };
        Store.set(CONFIG.KEYS.STATS_RESULT, lastStats);

        addNotification('📊 Статистика готова', `Закрыто жалоб за ${days} дн.: ${grandMy}`, 'success', '📊');

        btn.disabled = false;
        btn.innerHTML = `${ICONS.refresh} Обновить статистику`;
        isBusy = false;
    }

    /* ============================================================
       MONITORING — новая логика уведомлений по нику
       ============================================================ */
    async function updateStats(manual = false) {
        if (!trackedSections.length) {
            window.__vp_lastOpenCount = 0;
            updateMiniCount();
            return;
        }
        if (isBusy && !manual) return;
        isBusy = true;

        const results = [];
        let totalOpen = 0;
        const allCurrentIds = new Set();

        for (let i = 0; i < trackedSections.length; i += CONFIG.BATCH_SIZE) {
            const batch = trackedSections.slice(i, i + CONFIG.BATCH_SIZE);
            const r = await Promise.all(batch.map(async sec => {
                const html = await fetchHtml(sec.url);
                if (!html) return { sec, count: '!', ids: new Set(), threads: [] };
                const doc = new DOMParser().parseFromString(html, 'text/html');
                const threads = doc.querySelectorAll('.structItem--thread');
                let open = 0;
                threads.forEach(t => {
                    const prefix = t.querySelector('a.labelLink')?.getAttribute('href') || '';
                    const m = prefix.match(/prefix_id=(\d+)/);
                    if (m && CONFIG.PREFIX_PENDING.has(m[1])) return;
                    if (m && CONFIG.PREFIX_CLOSED.has(m[1])) return;
                    if (t.querySelector('.structItem-status--locked') ||
                        t.querySelector('.label--green, .label--red, .label--lightGreen')) return;
                    open++;
                });
                const ids = extractThreadIdsFromDoc(doc);
                ids.forEach(id => allCurrentIds.add(id));
                const parsed = parseThreadsFromDoc(doc);
                sectionThreads[sec.id] = parsed;
                return { sec, count: open, ids, threads: parsed };
            }));
            results.push(...r);
            if (i + CONFIG.BATCH_SIZE < trackedSections.length) await delay(200);
        }

        // ================= Логика уведомлений =================
        const receivedArr = Store.get(CONFIG.KEYS.RECEIVED_IDS, []) || [];
        const receivedSet = new Set(receivedArr);
        const username = userProfile?.username || '';
        const desktopOn = Store.get(CONFIG.KEYS.DESKTOP_NOTIF, true);
        const tgInfo = getTgInfo();
        const tgOn = isTgConnected() && tgInfo.enabled;

        // 1. Собираем все жалобы из всех разделов
        const allThreads = [];
        results.forEach(res => {
            if (Array.isArray(res.threads)) {
                res.threads.forEach(t => {
                    allThreads.push({ ...t, sectionTitle: res.sec.title });
                });
            }
        });

        // 2. Находим жалобы с ником пользователя, которых ещё нет в received
        if (username) {
            const lower = username.toLowerCase();
            const withMyNick = allThreads.filter(t => (t.title || '').toLowerCase().includes(lower));
            const newForMe = withMyNick.filter(t => !receivedSet.has(t.id));

            if (newForMe.length > 0) {
                // Записываем в received чтобы не дублировать
                const newReceived = [...receivedArr, ...newForMe.map(t => t.id)].slice(-10000);
                Store.set(CONFIG.KEYS.RECEIVED_IDS, newReceived);

                // Уведомление в колокольчик
                addNotification(
                    `📥 Новые жалобы на ${username}`,
                    `Найдено ${newForMe.length} ${pluralRu(newForMe.length, ['новая жалоба','новые жалобы','новых жалоб'])}`,
                    'info',
                    '📥'
                );

                // Windows + TG уведомления
                newForMe.forEach(t => {
                    if (desktopOn) {
                        sendDesktopNotification(
                            `🔔 Жалоба на ${username}`,
                            t.title || 'Новая жалоба'
                        );
                    }
                    if (tgOn) {
                        sendTelegramNotification(
                            `🔔 Жалоба на ${username}`,
                            `Раздел: ${t.sectionTitle}\n\n${t.title || 'Новая жалоба'}`,
                            t.url
                        );
                    }
                });

                checkNewBadges();
            }
        }

        // 3. Для медалей «Получено N жалоб» — считаем все уникальные увиденные жалобы
        const seenArr = Store.get(CONFIG.KEYS.SEEN_IDS, []) || [];
        const seenSet = new Set(seenArr);
        const brandNewAll = [];
        allCurrentIds.forEach(id => {
            if (!seenSet.has(id)) {
                brandNewAll.push(id);
                seenSet.add(id);
            }
        });
        if (brandNewAll.length > 0) {
            Store.set(CONFIG.KEYS.SEEN_IDS, Array.from(seenSet).slice(-50000));
            // Добавляем в received для медалей (если ещё не там)
            const badgesArr = Store.get(CONFIG.KEYS.RECEIVED_IDS, []) || [];
            const badgesSet = new Set(badgesArr);
            brandNewAll.forEach(id => badgesSet.add(id));
            Store.set(CONFIG.KEYS.RECEIVED_IDS, Array.from(badgesSet).slice(-10000));
        }

        // ================= Обновление UI =================
        if (currentView === 'monitoring') {
            const list = $('vp-content-list');
            if (list) {
                list.innerHTML = trackedSections.map(sec => {
                    const threads = sectionThreads[sec.id] || [];
                    const cnt = threads.length;
                    return `
                        <div class="vp-row" data-section-id="${sec.id}">
                            <span class="vp-row-title">${sec.title}</span>
                            <span class="vp-badge-count ${cnt > 0 ? 'vp-has' : 'vp-clear'}">${cnt}</span>
                            <span style="color:var(--text-mute);flex-shrink:0;">${ICONS.chevronRight}</span>
                        </div>`;
                }).join('');
                list.querySelectorAll('.vp-row[data-section-id]').forEach(row => {
                    row.onclick = () => openSectionDrawer(row.dataset.sectionId);
                });
            }
        }

        if (drawerEl?.classList.contains('vp-open')) {
            const currentTitle = $('vp-drawer-title')?.textContent;
            const sec = trackedSections.find(s => s.title === currentTitle);
            if (sec) {
                const threads = sectionThreads[sec.id] || [];
                $('vp-drawer-sub').textContent = `${threads.length} ${pluralRu(threads.length, ['жалоба','жалобы','жалоб'])} в разделе`;
                const body = $('vp-drawer-body');
                if (body) {
                    body.innerHTML = threads.map(t => `
                        <a class="vp-drawer-thread ${t.closed ? 'vp-closed' : 'vp-open'}" href="${t.url}" target="_blank">
                            <div class="vp-drawer-thread-icon">${t.closed ? ICONS.check : ICONS.message}</div>
                            <div class="vp-drawer-thread-body">
                                <div class="vp-drawer-thread-title">${t.title || 'Без названия'}</div>
                                <div class="vp-drawer-thread-meta">
                                    <span class="vp-drawer-thread-tag ${t.closed ? 'vp-closed' : 'vp-open'}">${t.closed ? 'Закрыта' : 'Открыта'}</span>
                                    <span>#${t.id}</span>
                                </div>
                            </div>
                            <div class="vp-drawer-thread-arrow">${ICONS.chevronRight}</div>
                        </a>`).join('');
                }
            }
        }

        results.forEach(res => { if (typeof res.count === 'number') totalOpen += res.count; });
        window.__vp_lastOpenCount = totalOpen;
        updateMiniCount();
        isBusy = false;
    }

    function updateMiniCount() {
        if (!miniEl) return;
        const open = window.__vp_lastOpenCount || 0;
        if (open > 0) miniEl.classList.add('vp-alert');
        else miniEl.classList.remove('vp-alert');
    }

    /* ============================================================
       MINI ICON
       ============================================================ */
    function buildMini() {
        const mini = document.createElement('div');
        mini.className = 'vp-mini vp-scope';
        mini.dataset.theme = currentTheme;
        mini.innerHTML = `
            <span class="vp-mini-pulse"></span>
            <span class="vp-mini-logo">
                <svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round">
                    <circle cx="12" cy="12" r="9"/>
                    <path d="M8 10h.01M16 10h.01"/>
                    <path d="M8.5 14.5c.9 1 2.1 1.5 3.5 1.5s2.6-.5 3.5-1.5"/>
                </svg>
            </span>
            <span class="vp-mini-hint">Vegas+ · клик для открытия</span>`;
        return mini;
    }

    function setupMiniDrag() {
        const saved = Store.get(CONFIG.KEYS.MINI_POS, null);
        if (saved && typeof saved.x === 'number') {
            miniEl.style.left = saved.x + 'px';
            miniEl.style.top = saved.y + 'px';
            miniEl.style.transform = 'scale(1)';
        }
        let drag = null, moved = false;
        miniEl.addEventListener('mousedown', e => {
            if (e.button !== 0) return;
            const r = miniEl.getBoundingClientRect();
            drag = { dx: e.clientX - r.left, dy: e.clientY - r.top };
            moved = false;
            miniEl.classList.add('vp-dragging');
            e.preventDefault();
        });
        document.addEventListener('mousemove', e => {
            if (!drag) return;
            const x = Math.max(0, Math.min(window.innerWidth - miniEl.offsetWidth, e.clientX - drag.dx));
            const y = Math.max(0, Math.min(window.innerHeight - miniEl.offsetHeight, e.clientY - drag.dy));
            if (Math.abs(x - (parseFloat(miniEl.style.left) || 0)) > 2 ||
                Math.abs(y - (parseFloat(miniEl.style.top) || 0)) > 2) moved = true;
            miniEl.style.left = x + 'px';
            miniEl.style.top = y + 'px';
            miniEl.style.transform = 'scale(1)';
        });
        document.addEventListener('mouseup', () => {
            if (!drag) return;
            drag = null;
            miniEl.classList.remove('vp-dragging');
            if (moved) {
                const r = miniEl.getBoundingClientRect();
                Store.set(CONFIG.KEYS.MINI_POS, { x: r.left, y: r.top });
            }
        });
        miniEl.addEventListener('click', e => {
            if (moved) { e.stopPropagation(); return; }
            openApp();
        });
    }

    chrome.runtime.onMessage.addListener(msg => {
        if (msg?.type === 'VEGAS_TOGGLE_WIDGET') {
            if (appEl?.classList.contains('vp-open')) collapseToMini();
            else openApp();
        }
    });

    document.addEventListener('keydown', e => {
        if (e.key === 'Escape') {
            if (drawerEl?.classList.contains('vp-open')) { closeDrawer(); return; }
            if (appEl?.classList.contains('vp-open')) collapseToMini();
        }
    });

    document.addEventListener('click', e => {
        if (notifPanelEl?.classList.contains('vp-open')) {
            const path = e.composedPath ? e.composedPath() : [];
            const inside = path.some(el => el === notifPanelEl || el?.id === 'vp-bell');
            if (!inside) {
                notifPanelEl.classList.remove('vp-visible');
                setTimeout(() => notifPanelEl.classList.remove('vp-open'), 200);
            }
        }
    }, true);

    /* ============================================================
       INIT
       ============================================================ */
    async function init() {
        hostEl = document.createElement('div');
        hostEl.id = 'vegas-plus-root';
        hostEl.style.cssText = 'all: initial;';
        document.documentElement.appendChild(hostEl);
        shadowRoot = hostEl.attachShadow({ mode: 'open' });

        const style = document.createElement('style');
        style.textContent = CSS;
        shadowRoot.appendChild(style);

        await Store.init();
        trackedSections = Store.get(CONFIG.KEYS.SECTIONS, []) || [];
        fetchedSubsections = Store.get(CONFIG.KEYS.STATS_SELECTED_SUBSECTIONS, []) || [];
        lastStats = Store.get(CONFIG.KEYS.STATS_RESULT, null);
        currentTheme = Store.get(CONFIG.KEYS.THEME, 'blue');
        notifications = Store.get(CONFIG.KEYS.NOTIF, []) || [];
        const cached = Store.get(CONFIG.KEYS.PROFILE, null);
        if (cached?.username) userProfile = cached;

        toastRoot = document.createElement('div');
        toastRoot.style.cssText = 'position:absolute;bottom:24px;left:24px;display:flex;flex-direction:column;gap:8px;pointer-events:none;z-index:70;';
        shadowRoot.appendChild(toastRoot);

        backdropEl = document.createElement('div');
        backdropEl.className = 'vp-backdrop';
        backdropEl.onclick = () => collapseToMini();
        shadowRoot.appendChild(backdropEl);

        appEl = buildApp();
        shadowRoot.appendChild(appEl);
        bindApp();

        notifPanelEl = $('vp-notif-panel');

        miniEl = buildMini();
        shadowRoot.appendChild(miniEl);
        setupMiniDrag();

        const alreadyAuthorized = Store.get(CONFIG.KEYS.AUTHORIZED, false);

        if (!alreadyAuthorized) {
            splashEl = buildSplash();
            splashEl.dataset.theme = currentTheme;
            shadowRoot.appendChild(splashEl);
            await runSplash();
            Store.set(CONFIG.KEYS.AUTHORIZED, true);
            addNotification('Добро пожаловать в Vegas+', `Версия ${CONFIG.VERSION} успешно загружена`, 'success', '🎉');
        } else {
            await detectProfile();
        }

        renderTopbarUser();
        updateBellBadge();

        const ctx = getBadgeContext();
        earnedBadges = BADGES.filter(b => b.check(ctx));

        const flame = getFlameDisplay();
        if (flame.best > 0 && !flame.alive && flame.streak === 0) {
            setTimeout(() => {
                addNotification('🔥 Пламя погасло',
                    `Твой лучший стрик: ${flame.best} дн. Отметься чтобы зажечь заново!`,
                    'warn', '🔥');
            }, 1200);
        } else if (!flame.checkedToday && flame.alive) {
            setTimeout(() => {
                addNotification('🔥 Не забудь отметиться',
                    `Стрик ${flame.streak} дн. Продолжи его сегодня!`,
                    'info', '🔥');
            }, 1200);
        }

        const mode = Store.get(CONFIG.KEYS.MODE, 'modal');
        if (mode === 'mini') miniEl.classList.add('vp-show');
        else openApp();

        updateStats(true);
        setInterval(updateStats, CONFIG.REFRESH_INTERVAL);
    }

    if (window.top === window.self && !document.getElementById('vegas-plus-root')) {
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', init, { once: true });
        } else {
            init();
        }
    }
})();