// background.js — прокси запросов + Windows/TG-уведомления
const TG_TOKEN = '8084432001:AAEJ3WmUmUdhJoRP2xjTRTrl5VQskFVYSl0';
const TG_API = `https://api.telegram.org/bot${TG_TOKEN}`;
const TG_OFFSET_KEY = 'arz_tg_offset';

let tgPollActive = false;
let tgPollCancel = false;

const sleep = ms => new Promise(r => setTimeout(r, ms));

/* ---------- Telegram API helpers ---------- */
async function tgCall(method, params = {}) {
    try {
        const r = await fetch(`${TG_API}/${method}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(params)
        });
        return await r.json();
    } catch (e) {
        return { ok: false, error: String(e) };
    }
}

async function tgGetOffset() {
    try {
        const r = await chrome.storage.local.get(TG_OFFSET_KEY);
        return r[TG_OFFSET_KEY] || 0;
    } catch { return 0; }
}
async function tgSetOffset(v) {
    try { await chrome.storage.local.set({ [TG_OFFSET_KEY]: v }); } catch (_) {}
}

async function tgPollConnect(code, timeoutMs = 90000) {
    if (tgPollActive) return { ok: false, error: 'already_polling' };
    tgPollActive = true;
    tgPollCancel = false;

    const started = Date.now();
    let offset = await tgGetOffset();
    const codeLower = String(code).toLowerCase().trim();

    try {
        while (Date.now() - started < timeoutMs) {
            if (tgPollCancel) return { ok: false, error: 'cancelled' };

            const res = await tgCall('getUpdates', { offset, timeout: 5, allowed_updates: ['message'] });
            if (!res.ok) {
                await sleep(1500);
                continue;
            }
            for (const upd of (res.result || [])) {
                offset = upd.update_id + 1;
                const msg = upd.message;
                if (!msg || !msg.text) continue;
                const text = String(msg.text).trim().toLowerCase();
                if (text === `/connect ${codeLower}` || text === `connect ${codeLower}` ||
                    text === `/start ${codeLower}` || text === codeLower) {
                    await tgSetOffset(offset);
                    return {
                        ok: true,
                        chatId: msg.chat.id,
                        username: msg.from?.username || '',
                        firstName: msg.from?.first_name || '',
                        lastName: msg.from?.last_name || ''
                    };
                }
            }
            await tgSetOffset(offset);
            await sleep(500);
        }
        return { ok: false, error: 'timeout' };
    } finally {
        tgPollActive = false;
    }
}

/* ---------- Message listener ---------- */
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    // --- прокси запросов к форуму ---
    if (msg?.type === 'ARZ_FETCH') {
        fetch(msg.url, {
            method: 'GET',
            credentials: 'include',
            headers: { 'Accept': 'text/html,application/xhtml+xml' }
        })
            .then(r => r.ok ? r.text() : Promise.reject(r.status))
            .then(text => sendResponse({ ok: true, text }))
            .catch(err => sendResponse({ ok: false, error: String(err) }));
        return true;
    }

    // --- Windows-уведомления ---
    if (msg?.type === 'ARZ_NOTIFY') {
        const id = 'vp_' + Date.now() + '_' + Math.random().toString(36).slice(2, 8);
        const icon = msg.icon || chrome.runtime.getURL('icons/icon128.png');
        try {
            chrome.notifications.create(id, {
                type: 'basic',
                iconUrl: icon,
                title: msg.title || 'Vegas+',
                message: msg.message || '',
                priority: 2,
                requireInteraction: false,
                silent: false
            }, () => {
                if (chrome.runtime.lastError) sendResponse({ ok: false, error: chrome.runtime.lastError.message });
                else sendResponse({ ok: true, id });
            });
        } catch (e) {
            sendResponse({ ok: false, error: String(e) });
        }
        return true;
    }

    // --- Telegram: подключение (polling) ---
    if (msg?.type === 'TG_POLL_CONNECT') {
        tgPollConnect(msg.code, msg.timeout || 90000)
            .then(sendResponse)
            .catch(e => sendResponse({ ok: false, error: String(e) }));
        return true;
    }

    // --- Telegram: отмена polling ---
    if (msg?.type === 'TG_POLL_CANCEL') {
        tgPollCancel = true;
        sendResponse({ ok: true });
        return;
    }

    // --- Telegram: отправка сообщения ---
    if (msg?.type === 'TG_SEND') {
        tgCall('sendMessage', {
            chat_id: msg.chatId,
            text: msg.text || '',
            parse_mode: msg.parseMode || 'HTML',
            disable_web_page_preview: true
        })
            .then(res => sendResponse(res))
            .catch(e => sendResponse({ ok: false, error: String(e) }));
        return true;
    }

    // --- Telegram: тест бота ---
    if (msg?.type === 'TG_ME') {
        tgCall('getMe', {})
            .then(res => sendResponse(res))
            .catch(e => sendResponse({ ok: false, error: String(e) }));
        return true;
    }
});

/* ---------- Клик по Windows-уведомлению → фокус форума ---------- */
chrome.notifications.onClicked.addListener((notifId) => {
    chrome.tabs.query({ url: 'https://forum.arizona-rp.com/*' }, (tabs) => {
        if (tabs && tabs.length > 0) {
            chrome.tabs.update(tabs[0].id, { active: true });
            if (tabs[0].windowId) chrome.windows.update(tabs[0].windowId, { focused: true });
        } else {
            chrome.tabs.create({ url: 'https://forum.arizona-rp.com/' });
        }
    });
    chrome.notifications.clear(notifId);
});

chrome.action.onClicked.addListener(async (tab) => {
    if (!tab?.id) return;
    try { await chrome.tabs.sendMessage(tab.id, { type: 'VEGAS_TOGGLE_WIDGET' }); } catch (_) {}
});