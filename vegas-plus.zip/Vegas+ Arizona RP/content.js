(function () {
    'use strict';


    const CONFIG = {
        REFRESH_INTERVAL: 60 * 1000,
        BATCH_SIZE: 10,
        FORUM_ORIGIN: 'https://forum.arizona-rp.com',
        VERSION: 'v1.5',
        LINKS: { DISCORD: 'https://discord.gg/thmQmVSkT' },

        ROLES: {
            'helper':       { name: 'Хелпер',              icon: '🎯', color: '#3b82f6' },
            'ml-adm':       { name: 'Мл. Администратор',   icon: '⚡', color: '#f59e0b' },
            'curator':      { name: 'Куратор',             icon: '🎓', color: '#eab308' },
            'adm':          { name: 'Администратор',       icon: '⚡', color: '#ef4444' },
            'chief-admin':  { name: 'Гл. Администратор',   icon: '👑', color: '#dc2626' },
            'user':         { name: 'Arizona RP',          icon: '🛡', color: '#8b5cf6' }
        },

        KEYS: {
            SECTIONS: 'arz_tracked_sections',
            NICK: 'arz_user_nick',
            PROFILE: 'arz_user_profile',
            AUTHORIZED: 'arz_authorized_once',
            INSTALL_DATE: 'arz_install_date',
            MINI_POS: 'arz_mini_pos',
            MODE: 'arz_ui_mode',
            THEME: 'arz_theme',
            NOTIF: 'arz_notifications',
            VISITS: 'arz_visits',
            SEEN_IDS: 'arz_seen_thread_ids',
            RECEIVED_IDS: 'arz_received_thread_ids',
            BASELINE_DONE: 'arz_baseline_done',
            FLAME_STREAK: 'arz_flame_streak',
            FLAME_BEST: 'arz_flame_best',
            FLAME_LAST: 'arz_flame_last',
            FLAME_TOTAL: 'arz_flame_total',
            FLAME_HISTORY: 'arz_flame_history',
            DESKTOP_NOTIF: 'arz_desktop_notif',
            TG_CHAT_ID: 'arz_tg_chat_id',
            TG_USERNAME: 'arz_tg_username',
            TG_ENABLED: 'arz_tg_enabled',
            BANNER: 'arz_profile_banner',
            PROFILE_STATUS: 'arz_profile_status',
            PROFILE_FRAME: 'arz_profile_frame',
            PROFILE_NICK_COLOR: 'arz_profile_nick_color',
            PROFILE_CHIPS: 'arz_profile_chips',
            PROFILE_LAYOUT: 'arz_profile_layout'
        },
        PREFIX_CLOSED: new Set(['17', '18', '29', '30']),
        PREFIX_PENDING: new Set(['3'])
    };

    const THEMES = {
        blue:      { name: 'Синяя',        accent: '#3b82f6', accent2: '#60a5fa', glow: 'rgba(59,130,246,.5)' },
        purple:    { name: 'Фиолетовая',   accent: '#8b5cf6', accent2: '#a78bfa', glow: 'rgba(139,92,246,.5)' },
        emerald:   { name: 'Изумруд',      accent: '#10b981', accent2: '#34d399', glow: 'rgba(16,185,129,.5)' },
        rose:      { name: 'Роза',         accent: '#f43f5e', accent2: '#fb7185', glow: 'rgba(244,63,94,.5)' },
        amber:     { name: 'Янтарь',       accent: '#f59e0b', accent2: '#fbbf24', glow: 'rgba(245,158,11,.5)' },
        neon:      { name: '⚡ Neon',       accent: '#e879f9', accent2: '#22d3ee', glow: 'rgba(232,121,249,.7)' },
        aurora:    { name: '🌌 Aurora',     accent: '#14b8a6', accent2: '#a78bfa', glow: 'rgba(20,184,166,.6)' },
        sunset:    { name: '🌅 Sunset',     accent: '#fb7185', accent2: '#fbbf24', glow: 'rgba(251,113,133,.6)' },
        matrix:    { name: '🟢 Matrix',     accent: '#22c55e', accent2: '#4ade80', glow: 'rgba(34,197,94,.6)' },
        ice:       { name: '❄️ Ice',        accent: '#38bdf8', accent2: '#a5f3fc', glow: 'rgba(56,189,248,.6)' },
        sakura:    { name: '🌸 Sakura',     accent: '#ec4899', accent2: '#f9a8d4', glow: 'rgba(236,72,153,.6)' },
        cosmic:    { name: '🌠 Cosmic',     accent: '#8b5cf6', accent2: '#c4b5fd', glow: 'rgba(139,92,246,.7)' },
        toxic:     { name: '☢️ Toxic',      accent: '#84cc16', accent2: '#bef264', glow: 'rgba(132,204,22,.6)' }
    };

    const BANNER_PRESETS = [
        { id: 'sunset',    name: 'Sunset',     css: 'linear-gradient(135deg, #fb7185 0%, #fbbf24 100%)' },
        { id: 'ocean',     name: 'Ocean',      css: 'linear-gradient(135deg, #0ea5e9 0%, #6366f1 100%)' },
        { id: 'forest',    name: 'Forest',     css: 'linear-gradient(135deg, #10b981 0%, #065f46 100%)' },
        { id: 'fire',      name: 'Fire',       css: 'linear-gradient(135deg, #f97316 0%, #dc2626 60%, #7f1d1d 100%)' },
        { id: 'royal',     name: 'Royal',      css: 'linear-gradient(135deg, #8b5cf6 0%, #ec4899 100%)' },
        { id: 'galaxy',    name: 'Galaxy',     css: 'radial-gradient(circle at 30% 20%, #4c1d95 0%, #0f172a 70%)' },
        { id: 'mint',      name: 'Mint',       css: 'linear-gradient(135deg, #6ee7b7 0%, #3b82f6 100%)' },
        { id: 'peach',     name: 'Peach',      css: 'linear-gradient(135deg, #fed7aa 0%, #fb7185 100%)' },
        { id: 'midnight',  name: 'Midnight',   css: 'linear-gradient(135deg, #0f172a 0%, #1e293b 50%, #334155 100%)' },
        { id: 'neon',      name: 'Neon',       css: 'linear-gradient(135deg, #e879f9 0%, #22d3ee 100%)' },
        { id: 'gold',      name: 'Gold',       css: 'linear-gradient(135deg, #fbbf24 0%, #b45309 100%)' },
        { id: 'cherry',    name: 'Cherry',     css: 'linear-gradient(135deg, #dc2626 0%, #7f1d1d 100%)' }
    ];

    const FRAMES = {
        none:      { name: 'Без рамки',    css: '' },
        glow:      { name: 'Свечение',     css: 'box-shadow: 0 0 0 3px var(--accent), 0 0 30px var(--accent-glow);' },
        gradient:  { name: 'Градиент',     css: 'border-color: transparent; background: linear-gradient(135deg, var(--accent), var(--accent-2)) padding-box, linear-gradient(135deg, var(--accent-2), var(--accent)) border-box;' },
        ring:      { name: 'Кольцо',       css: 'border-color: var(--accent); box-shadow: 0 0 0 4px color-mix(in srgb, var(--accent) 25%, transparent), 0 0 24px var(--accent-glow);' },
        dashed:    { name: 'Пунктир',      css: 'border-style: dashed; border-color: var(--accent); border-width: 3px;' },
        royal:     { name: 'Royal',        css: 'border-color: #fbbf24; box-shadow: 0 0 0 3px #fbbf24, 0 0 24px rgba(251,191,36,.6);' }
    };


    // ★ Единая ссылка на логотип из папки icons (заменяет старый SVG-смайлик)
    const LOGO_URL = (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.getURL)
        ? chrome.runtime.getURL('icons/logo.png')
        : '';
    const LOGO_IMG = `<img class="vp-logo-img" src="${LOGO_URL}" alt="Vegas+" draggable="false">`;


    const Store = {
        _cache: {},
        async init() {
            const keys = Object.values(CONFIG.KEYS);
            this._cache = (await chrome.storage.local.get(keys)) || {};
            if (!this._cache[CONFIG.KEYS.INSTALL_DATE]) {
                this._cache[CONFIG.KEYS.INSTALL_DATE] = Date.now();
                chrome.storage.local.set({ [CONFIG.KEYS.INSTALL_DATE]: Date.now() });
            }
        },
        get(k, f) { return this._cache[k] !== undefined ? this._cache[k] : f; },
        set(k, v) { this._cache[k] = v; chrome.storage.local.set({ [k]: v }); },
        remove(k) { delete this._cache[k]; chrome.storage.local.remove(k); }
    };

    const delay = ms => new Promise(r => setTimeout(r, ms));


    function dateKey(d) {
        const y = d.getFullYear();
        const m = String(d.getMonth() + 1).padStart(2, '0');
        const day = String(d.getDate()).padStart(2, '0');
        return `${y}-${m}-${day}`;
    }
    function pluralRu(n, forms) {
        const m10 = n % 10, m100 = n % 100;
        if (m10 === 1 && m100 !== 11) return forms[0];
        if (m10 >= 2 && m10 <= 4 && (m100 < 10 || m100 >= 20)) return forms[1];
        return forms[2];
    }
    function escapeHtml(s) {
        return String(s || '').replace(/[&<>"']/g, c => ({
            '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
        })[c]);
    }
    function hexToRgba(hex, alpha = 1) {
        if (!hex) return `rgba(59,130,246,${alpha})`;
        if (hex.startsWith('rgba')) return hex;
        if (hex.startsWith('rgb')) return hex.replace('rgb(', 'rgba(').replace(')', `,${alpha})`);
        let h = hex.replace('#', '');
        if (h.length === 3) h = h.split('').map(c => c + c).join('');
        const r = parseInt(h.substring(0, 2), 16);
        const g = parseInt(h.substring(2, 4), 16);
        const b = parseInt(h.substring(4, 6), 16);
        return `rgba(${r},${g},${b},${alpha})`;
    }
    function isPresetBanner(v) {
        if (!v || typeof v !== 'string') return false;
        return v.startsWith('linear-gradient') || v.startsWith('radial-gradient');
    }

    const onlineCounter = {
        value: 0,
        max: 100,
        init() { this.value = 3 + Math.floor(Math.random() * 95); }
    };


    function extractRole(bannerClasses) {
        if (!bannerClasses) return { key: 'user', ...CONFIG.ROLES.user };
        const tokens = String(bannerClasses).match(/userBanner--([a-z0-9_-]+)/gi) || [];
        for (const t of tokens) {
            const key = t.replace(/^userBanner--/i, '').toLowerCase();
            if (key === 'img' || key === 'user') continue;
            if (CONFIG.ROLES[key]) return { key, ...CONFIG.ROLES[key] };
        }
        return { key: 'user', ...CONFIG.ROLES.user };
    }

    function readBannerClasses() {
        const selectors = [
            '.p-account-username .userBanner',
            '.p-navgroup--member .userBanner',
            '.p-navgroup-link--user .userBanner',
            '.memberHeader-banners .userBanner',
            '.message-userDetails .userBanner'
        ];
        for (const sel of selectors) {
            const el = document.querySelector(sel);
            if (el) return String(el.className || '');
        }
        return '';
    }


    let _notifIconUrl = null;
    function getNotifIcon() {
        if (_notifIconUrl) return _notifIconUrl;
        try {
            const c = document.createElement('canvas');
            c.width = 128; c.height = 128;
            const ctx = c.getContext('2d');
            const g = ctx.createLinearGradient(0, 0, 128, 128);
            g.addColorStop(0, '#f97316'); g.addColorStop(1, '#dc2626');
            ctx.fillStyle = g;
            ctx.beginPath();
            if (ctx.roundRect) ctx.roundRect(0, 0, 128, 128, 28); else ctx.rect(0, 0, 128, 128);
            ctx.fill();
            ctx.fillStyle = '#fff';
            ctx.beginPath(); ctx.arc(64, 64, 38, 0, Math.PI * 2); ctx.fill();
            ctx.fillStyle = '#1a1a1a';
            ctx.beginPath(); ctx.arc(50, 54, 5.5, 0, Math.PI * 2); ctx.fill();
            ctx.beginPath(); ctx.arc(78, 54, 5.5, 0, Math.PI * 2); ctx.fill();
            ctx.strokeStyle = '#1a1a1a'; ctx.lineWidth = 6; ctx.lineCap = 'round';
            ctx.beginPath(); ctx.arc(64, 72, 22, 0.15 * Math.PI, 0.85 * Math.PI); ctx.stroke();
            _notifIconUrl = c.toDataURL('image/png');
            return _notifIconUrl;
        } catch { return ''; }
    }
    function sendDesktopNotification(title, message) {
        try {
            chrome.runtime.sendMessage({ type: 'ARZ_NOTIFY', title, message, icon: getNotifIcon() },
                () => { void chrome.runtime.lastError; });
        } catch (_) {}
    }


    const FLAME_LEVELS = [
        { lvl: 0, name: 'Погас',   icon: '💀', min: 0   },
        { lvl: 1, name: 'Искра',   icon: '✨', min: 1   },
        { lvl: 2, name: 'Уголёк',  icon: '🔥', min: 3   },
        { lvl: 3, name: 'Огонёк',  icon: '🔥', min: 7   },
        { lvl: 4, name: 'Пламя',   icon: '🔥', min: 14  },
        { lvl: 5, name: 'Костёр',  icon: '🔥', min: 30  },
        { lvl: 6, name: 'Пожар',   icon: '🔥', min: 60  },
        { lvl: 7, name: 'Инферно', icon: '🌋', min: 100 }
    ];
    function getFlameLevel(streak) {
        if (streak === 0)  return 0;
        if (streak < 3)    return 1;
        if (streak < 7)    return 2;
        if (streak < 14)   return 3;
        if (streak < 30)   return 4;
        if (streak < 60)   return 5;
        if (streak < 100)  return 6;
        return 7;
    }
    function getFlameThresholds() { return [0, 1, 3, 7, 14, 30, 60, 100]; }
    function getFlameState() {
        return {
            streak: Store.get(CONFIG.KEYS.FLAME_STREAK, 0) || 0,
            best: Store.get(CONFIG.KEYS.FLAME_BEST, 0) || 0,
            last: Store.get(CONFIG.KEYS.FLAME_LAST, '') || '',
            total: Store.get(CONFIG.KEYS.FLAME_TOTAL, 0) || 0,
            history: Store.get(CONFIG.KEYS.FLAME_HISTORY, []) || []
        };
    }
    function getFlameDisplay() {
        const s = getFlameState();
        const today = dateKey(new Date());
        const yesterday = dateKey(new Date(Date.now() - 86400000));
        const checkedToday = s.last === today;
        const alive = s.last === today || s.last === yesterday;
        return { streak: alive ? s.streak : 0, best: s.best, total: s.total, checkedToday, alive, history: s.history };
    }
    function checkInFlame() {
        const s = getFlameState();
        const today = dateKey(new Date());
        const yesterday = dateKey(new Date(Date.now() - 86400000));
        if (s.last === today) {
            addNotification('🔥 Уже отмечено', 'Приходи завтра!', 'warn', '🔥');
            return;
        }
        const prevStreak = s.streak;
        const newStreak = s.last === yesterday ? s.streak + 1 : 1;
        const newBest = Math.max(s.best, newStreak);
        const newTotal = s.total + 1;
        const history = Array.isArray(s.history) ? s.history.slice() : [];
        if (!history.includes(today)) history.push(today);
        const trimmed = history.slice(-120);

        Store.set(CONFIG.KEYS.FLAME_STREAK, newStreak);
        Store.set(CONFIG.KEYS.FLAME_BEST, newBest);
        Store.set(CONFIG.KEYS.FLAME_LAST, today);
        Store.set(CONFIG.KEYS.FLAME_TOTAL, newTotal);
        Store.set(CONFIG.KEYS.FLAME_HISTORY, trimmed);

        const prevLevel = getFlameLevel(prevStreak);
        const newLevel = getFlameLevel(newStreak);
        const lvlInfo = FLAME_LEVELS[newLevel];
        if (newLevel > prevLevel) {
            addNotification(`${lvlInfo.icon} Огонёк вырос до уровня ${newLevel}!`,
                `«${lvlInfo.name}» · Стрик: ${newStreak} ${pluralRu(newStreak, ['день','дня','дней'])}`,
                'badge', lvlInfo.icon);
        } else if (newStreak === 1 && prevStreak > 1) {
            addNotification('🔥 Огонёк зажжён заново', `Прошлый стрик был ${prevStreak} дн.`, 'warn', '🔥');
        } else {
            addNotification('🔥 Отмечено!', `Стрик: ${newStreak} ${pluralRu(newStreak, ['день','дня','дней'])}`, 'success', '🔥');
        }
        renderView();
    }
    function getFlameAchievements(best) {
        return FLAME_LEVELS.map((lv, i) => {
            if (i === 0) return null;
            return { level: lv.lvl, icon: lv.icon, name: lv.name, required: lv.min, unlocked: best >= lv.min };
        }).filter(Boolean);
    }
    function getWeekdayStats(history) {
        const names = ['Вс', 'Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб'];
        const counts = [0, 0, 0, 0, 0, 0, 0];
        (history || []).forEach(dk => {
            const d = new Date(dk + 'T00:00:00');
            if (!isNaN(d.getTime())) counts[d.getDay()]++;
        });
        const max = Math.max(1, ...counts);
        return { names, counts, max };
    }
    function getFlameForecast(streak) {
        const level = getFlameLevel(streak);
        const thresholds = getFlameThresholds();
        if (level >= 7) return { done: true, level: 7, name: FLAME_LEVELS[7].name };
        const nextThreshold = thresholds[level + 1];
        const need = Math.max(0, nextThreshold - streak);
        const nextName = FLAME_LEVELS[level + 1].name;
        const eta = new Date(Date.now() + need * 86400000);
        return { done: false, need, nextLevel: level + 1, name: nextName, eta };
    }


    const TG_BOT = 'vegas_notification_bot';
    const TG_URL = `https://t.me/${TG_BOT}`;
    function isTgConnected() { return !!Store.get(CONFIG.KEYS.TG_CHAT_ID, null); }
    function getTgInfo() {
        return {
            chatId: Store.get(CONFIG.KEYS.TG_CHAT_ID, null),
            username: Store.get(CONFIG.KEYS.TG_USERNAME, ''),
            enabled: Store.get(CONFIG.KEYS.TG_ENABLED, true)
        };
    }
    function genConnectCode() { return String(Math.floor(100000 + Math.random() * 900000)); }

    async function connectTelegram() {
        const code = genConnectCode();
        showTgModal(code);
        try {
            const res = await new Promise(resolve => {
                chrome.runtime.sendMessage({
                    type: 'TG_POLL_CONNECT', code,
                    username: userProfile?.username || '', timeout: 90000
                }, r => {
                    if (chrome.runtime.lastError) return resolve({ ok: false, error: chrome.runtime.lastError.message });
                    resolve(r || { ok: false });
                });
            });
            if (res.ok) {
                Store.set(CONFIG.KEYS.TG_CHAT_ID, res.chatId);
                Store.set(CONFIG.KEYS.TG_USERNAME, res.username || res.firstName || '');
                Store.set(CONFIG.KEYS.TG_ENABLED, true);
                showTgModalSuccess(res);
                setTimeout(() => { hideTgModal(); if (currentView === 'settings') renderView(); }, 2200);
                addNotification('✈️ Telegram подключён',
                    res.username ? `Уведомления будут приходить на @${res.username}` : 'Уведомления включены',
                    'success', '✈️');
            } else if (res.error === 'timeout') {
                showTgModalTimeout();
                addNotification('✈️ Telegram', 'Таймаут подключения', 'warn', '✈️');
            } else if (res.error === 'cancelled') {
                hideTgModal();
            } else {
                showTgModalError(res.error || 'Ошибка');
                addNotification('✈️ Telegram', 'Не удалось подключить', 'error', '✈️');
            }
        } catch (e) { showTgModalError(String(e)); }
    }
    function disconnectTelegram() {
        Store.set(CONFIG.KEYS.TG_CHAT_ID, null);
        Store.set(CONFIG.KEYS.TG_USERNAME, '');
        Store.set(CONFIG.KEYS.TG_ENABLED, false);
        addNotification('✈️ Telegram отключён', 'Уведомления больше не приходят', 'info', '✈️');
        renderView();
    }
    function toggleTg() {
        if (!isTgConnected()) return;
        const cur = Store.get(CONFIG.KEYS.TG_ENABLED, true);
        Store.set(CONFIG.KEYS.TG_ENABLED, !cur);
        renderView();
    }
    function sendTelegramNotification(title, text, url) {
        const info = getTgInfo();
        if (!info.chatId || !info.enabled) return;
        const html = `<b>${escapeHtml(title)}</b>\n\n${escapeHtml(text)}${url ? `\n\n<a href="${url}">Открыть жалобу</a>` : ''}`;
        try {
            chrome.runtime.sendMessage({ type: 'TG_SEND', chatId: info.chatId, text: html },
                () => { void chrome.runtime.lastError; });
        } catch (_) {}
    }

    let tgModalEl = null;
    function ensureTgModal() {
        if (tgModalEl) return tgModalEl;
        const wrap = document.createElement('div');
        wrap.className = 'vp-tg-modal';
        wrap.innerHTML = `<div class="vp-tg-modal-card">
            <button class="vp-tg-modal-close" id="vp-tg-close">${ICONS.x}</button>
            <div id="vp-tg-modal-content"></div>
        </div>`;
        appEl.appendChild(wrap);
        wrap.querySelector('#vp-tg-close').onclick = () => {
            try { chrome.runtime.sendMessage({ type: 'TG_POLL_CANCEL' }, () => { void chrome.runtime.lastError; }); } catch (_) {}
            hideTgModal();
        };
        tgModalEl = wrap;
        return wrap;
    }
    function showTgModal(code) {
        ensureTgModal();
        const content = tgModalEl.querySelector('#vp-tg-modal-content');
        content.innerHTML = `
            <div class="vp-tg-head">
                <div class="vp-tg-icon">
                    <svg viewBox="0 0 24 24" fill="currentColor"><path d="M9.78 18.65l.28-4.23 7.68-6.92c.34-.31-.07-.46-.52-.19L7.74 13.3 3.64 12c-.88-.25-.89-.86.2-1.3l15.97-6.16c.73-.33 1.43.18 1.15 1.3l-2.72 12.81c-.19.91-.74 1.13-1.5.71L12.6 16.3l-1.99 1.93c-.23.23-.42.42-.83.42z"/></svg>
                </div>
                <div class="vp-tg-title">Подключение Telegram</div>
                <div class="vp-tg-sub">Уведомления о новых жалобах на твой ник прямо в Telegram</div>
            </div>
            <div class="vp-tg-steps">
                <div class="vp-tg-step"><div class="vp-tg-step-num">1</div><div class="vp-tg-step-text">Открой бота <b>@${TG_BOT}</b> и нажми <b>Start</b></div></div>
                <div class="vp-tg-step"><div class="vp-tg-step-num">2</div><div class="vp-tg-step-text">Отправь боту команду:</div></div>
            </div>
            <div class="vp-tg-code">
                <code id="vp-tg-code-text">/connect ${code}</code>
                <button class="vp-tg-copy" id="vp-tg-copy">Копировать</button>
            </div>
            <div class="vp-tg-actions">
                <a class="vp-btn vp-tg-btn-primary" href="${TG_URL}" target="_blank">Открыть @${TG_BOT}</a>
            </div>
            <div class="vp-tg-waiting">
                <div class="vp-tg-waiting-dots"><span></span><span></span><span></span></div>
                <div class="vp-tg-waiting-text">Ожидание подключения…</div>
            </div>`;
        content.querySelector('#vp-tg-copy').onclick = () => {
            const txt = content.querySelector('#vp-tg-code-text').textContent;
            navigator.clipboard.writeText(txt).then(() => {
                content.querySelector('#vp-tg-copy').textContent = '✓ Скопировано';
                setTimeout(() => {
                    const btn = content.querySelector('#vp-tg-copy');
                    if (btn) btn.textContent = 'Копировать';
                }, 1500);
            }).catch(() => {});
        };
        tgModalEl.classList.add('vp-open');
        requestAnimationFrame(() => tgModalEl.classList.add('vp-visible'));
    }
    function showTgModalSuccess(res) {
        if (!tgModalEl) return;
        tgModalEl.querySelector('#vp-tg-modal-content').innerHTML = `
            <div class="vp-tg-head">
                <div class="vp-tg-icon vp-tg-icon-success">
                    <svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
                </div>
                <div class="vp-tg-title">Telegram подключён!</div>
                <div class="vp-tg-sub">${res.username ? 'Аккаунт: <b>@' + escapeHtml(res.username) + '</b>' : 'Уведомления активированы'}</div>
            </div>`;
    }
    function showTgModalTimeout() {
        if (!tgModalEl) return;
        const content = tgModalEl.querySelector('#vp-tg-modal-content');
        content.innerHTML = `
            <div class="vp-tg-head">
                <div class="vp-tg-icon vp-tg-icon-warn">⏱</div>
                <div class="vp-tg-title">Время вышло</div>
                <div class="vp-tg-sub">Сообщение от бота не пришло. Попробуй ещё раз.</div>
            </div>
            <div class="vp-tg-actions"><button class="vp-btn vp-tg-btn-primary" id="vp-tg-retry">Попробовать снова</button></div>`;
        content.querySelector('#vp-tg-retry').onclick = () => { hideTgModal(); setTimeout(() => connectTelegram(), 250); };
    }
    function showTgModalError(err) {
        if (!tgModalEl) return;
        const content = tgModalEl.querySelector('#vp-tg-modal-content');
        content.innerHTML = `
            <div class="vp-tg-head">
                <div class="vp-tg-icon vp-tg-icon-error">✕</div>
                <div class="vp-tg-title">Ошибка подключения</div>
                <div class="vp-tg-sub">${escapeHtml(err)}</div>
            </div>
            <div class="vp-tg-actions"><button class="vp-btn vp-tg-btn-primary" id="vp-tg-retry">Попробовать снова</button></div>`;
        content.querySelector('#vp-tg-retry').onclick = () => { hideTgModal(); setTimeout(() => connectTelegram(), 250); };
    }
    function hideTgModal() {
        if (!tgModalEl) return;
        tgModalEl.classList.remove('vp-visible');
        setTimeout(() => tgModalEl?.classList.remove('vp-open'), 250);
    }


    const CSS = `
    :host { all: initial; }
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

    .vp-scope {
        --accent: #3b82f6;
        --accent-2: #60a5fa;
        --accent-glow: rgba(59,130,246,.5);
        --bg-app: #0a0e1a;
        --bg-side: #070a13;
        --bg-card: #0f1424;
        --bg-card-2: #161c2e;
        --border: #1e2740;
        --border-2: #2a3352;
        --text: #e8ecf5;
        --text-dim: #8b93a8;
        --text-mute: #4d5570;
        --success: #34d399;
        --danger: #f87171;
        --warn: #f59e0b;
    }
    .vp-scope[data-theme="purple"]  { --accent:#8b5cf6; --accent-2:#a78bfa; --accent-glow:rgba(139,92,246,.5); }
    .vp-scope[data-theme="emerald"] { --accent:#10b981; --accent-2:#34d399; --accent-glow:rgba(16,185,129,.5); }
    .vp-scope[data-theme="rose"]    { --accent:#f43f5e; --accent-2:#fb7185; --accent-glow:rgba(244,63,94,.5); }
    .vp-scope[data-theme="amber"]   { --accent:#f59e0b; --accent-2:#fbbf24; --accent-glow:rgba(245,158,11,.5); }
    .vp-scope[data-theme="neon"]    { --accent:#e879f9; --accent-2:#22d3ee; --accent-glow:rgba(232,121,249,.8); }
    .vp-scope[data-theme="aurora"]  { --accent:#14b8a6; --accent-2:#a78bfa; --accent-glow:rgba(20,184,166,.7); }
    .vp-scope[data-theme="sunset"]  { --accent:#fb7185; --accent-2:#fbbf24; --accent-glow:rgba(251,113,133,.7); }
    .vp-scope[data-theme="matrix"]  { --accent:#22c55e; --accent-2:#4ade80; --accent-glow:rgba(34,197,94,.7); }
    .vp-scope[data-theme="ice"]     { --accent:#38bdf8; --accent-2:#a5f3fc; --accent-glow:rgba(56,189,248,.7); }
    .vp-scope[data-theme="sakura"]  { --accent:#ec4899; --accent-2:#f9a8d4; --accent-glow:rgba(236,72,153,.6); }
    .vp-scope[data-theme="cosmic"]  { --accent:#8b5cf6; --accent-2:#c4b5fd; --accent-glow:rgba(139,92,246,.7); }
    .vp-scope[data-theme="toxic"]   { --accent:#84cc16; --accent-2:#bef264; --accent-glow:rgba(132,204,22,.6); }

    /* ★ Универсальный стиль логотипа-картинки */
    .vp-logo-img { display: block; width: 100%; height: 100%; object-fit: contain; pointer-events: none; user-select: none; -webkit-user-drag: none; }

    .vp-backdrop { position: fixed; inset: 0; z-index: 2147483644; background: rgba(4, 6, 12, 0.72); backdrop-filter: blur(8px); -webkit-backdrop-filter: blur(8px); opacity: 0; pointer-events: none; transition: opacity .3s; }
    .vp-backdrop.vp-show { opacity: 1; pointer-events: auto; }

    /* SPLASH */
    .vp-splash { position: fixed; inset: 0; z-index: 2147483647; display: flex; align-items: center; justify-content: center;
        background: radial-gradient(ellipse 80% 60% at 50% 0%, rgba(59,130,246,.16), transparent 60%),
                    radial-gradient(ellipse 70% 50% at 50% 100%, rgba(139,92,246,.14), transparent 60%),
                    rgba(4, 6, 12, 0.88);
        backdrop-filter: blur(22px) saturate(150%); -webkit-backdrop-filter: blur(22px) saturate(150%);
        opacity: 0; transition: opacity .45s ease;
        font-family: -apple-system, BlinkMacSystemFont, "SF Pro Text", "Segoe UI", Roboto, sans-serif;
        color: #e6e8ee; overflow: hidden; }
    .vp-splash.vp-show { opacity: 1; }
    .vp-splash.vp-hide { opacity: 0; pointer-events: none; }
    .vp-splash-particles { position: absolute; inset: 0; pointer-events: none; overflow: hidden; }
    .vp-splash-particle { position: absolute; bottom: -20px; border-radius: 50%; background: var(--accent-2);
        box-shadow: 0 0 10px var(--accent-2), 0 0 20px var(--accent-glow); opacity: 0;
        animation: vp-particle-rise 6s linear infinite; }
    @keyframes vp-particle-rise { 0% { transform: translateY(0) scale(.4); opacity: 0; } 15% { opacity: 1; } 85% { opacity: .9; } 100% { transform: translateY(-110vh) scale(1.1); opacity: 0; } }
    .vp-splash-card { position: relative; width: 400px; padding: 34px 30px 26px; border-radius: 24px;
        background: linear-gradient(180deg, rgba(28,30,40,.96), rgba(16,18,24,.96)); border: 1px solid #2e323e;
        box-shadow: 0 40px 100px -20px rgba(0,0,0,.9), 0 0 0 1px rgba(255,255,255,.03), inset 0 1px 0 rgba(255,255,255,.06), 0 0 60px -10px var(--accent-glow);
        display: flex; flex-direction: column; align-items: center; gap: 16px;
        transform: translateY(16px) scale(.96); transition: transform .55s cubic-bezier(.34, 1.56, .64, 1); }
    .vp-splash.vp-show .vp-splash-card { transform: none; }
    .vp-splash-logo-wrap { position: relative; width: 96px; height: 96px; display: flex; align-items: center; justify-content: center; }
    .vp-splash-ring { position: absolute; inset: 0; border-radius: 26px; border: 2px solid var(--accent-2);
        pointer-events: none; opacity: 0; animation: vp-ring-out 2.6s ease-out infinite; }
    .vp-splash-ring:nth-child(2) { animation-delay: .85s; }
    .vp-splash-ring:nth-child(3) { animation-delay: 1.7s; }
    @keyframes vp-ring-out { 0% { transform: scale(1); opacity: .7; } 100% { transform: scale(2.3); opacity: 0; } }
    .vp-splash-logo { width: 82px; height: 82px; border-radius: 24px;
        display: flex; align-items: center; justify-content: center; overflow: hidden;
        box-shadow: 0 18px 40px -10px var(--accent-glow), 0 0 40px -8px var(--accent-glow), inset 0 2px 0 rgba(255,255,255,.15);
        position: relative; animation: vp-float 2.6s ease-in-out infinite; z-index: 2; }
    .vp-splash-logo .vp-logo-img { width: 100%; height: 100%; object-fit: cover; border-radius: 24px; }
    @keyframes vp-float { 0%,100% { transform: translateY(0); } 50% { transform: translateY(-5px); } }
    .vp-splash-logo svg { width: 46px; height: 46px; }
    .vp-splash-title { font-size: 24px; font-weight: 700; letter-spacing: -.02em;
        background: linear-gradient(135deg, #fff 30%, #c7b8ff);
        -webkit-background-clip: text; background-clip: text; -webkit-text-fill-color: transparent; text-align: center; }
    .vp-splash-tagline { font-size: 10.5px; color: var(--text-mute); letter-spacing: .14em; font-weight: 700; text-transform: uppercase; margin-top: -10px; }
    .vp-splash-sub { font-size: 12.5px; color: #8b90a0; text-align: center; line-height: 1.5; min-height: 36px; padding: 0 8px; }
    .vp-splash-sub b { color: var(--accent-2); font-weight: 600; }
    .vp-splash-bar { width: 100%; height: 5px; border-radius: 5px; background: #1b1e26; overflow: hidden; position: relative; }
    .vp-splash-bar-fill { position: absolute; top: 0; left: 0; height: 100%; width: 0%; border-radius: 5px;
        background: linear-gradient(90deg, var(--accent), var(--accent-2)); box-shadow: 0 0 14px var(--accent-glow);
        transition: width .5s cubic-bezier(.4,0,.2,1); overflow: hidden; }
    .vp-splash-bar-fill::after { content: ''; position: absolute; inset: 0;
        background: linear-gradient(90deg, transparent, rgba(255,255,255,.55), transparent); animation: vp-shimmer 1.4s linear infinite; }
    @keyframes vp-shimmer { 0% { transform: translateX(-100%); } 100% { transform: translateX(100%); } }
    .vp-splash-steps { display: flex; flex-direction: column; gap: 7px; width: 100%; margin-top: 4px; }
    .vp-step { display: flex; align-items: center; gap: 9px; font-size: 11px; color: #5c6172; transition: color .3s; }
    .vp-step-dot { width: 7px; height: 7px; border-radius: 50%; background: #2e323e; flex-shrink: 0; transition: all .3s; }
    .vp-step.vp-active { color: #e6e8ee; }
    .vp-step.vp-active .vp-step-dot { background: var(--accent-2); box-shadow: 0 0 10px var(--accent-2), 0 0 20px var(--accent-glow); animation: vp-dot-pulse 1.2s ease-in-out infinite; }
    @keyframes vp-dot-pulse { 0%,100% { transform: scale(1); opacity: 1; } 50% { transform: scale(1.35); opacity: .55; } }
    .vp-step.vp-done { color: #8b90a0; }
    .vp-step.vp-done .vp-step-dot { background: #34d399; box-shadow: 0 0 8px rgba(52,211,153,.7); }
    .vp-splash-footer { margin-top: 6px; font-size: 10px; color: #4a4f5e; letter-spacing: .1em; text-transform: uppercase; font-weight: 700; display: flex; align-items: center; gap: 6px; }
    .vp-splash-footer-dot { width: 5px; height: 5px; border-radius: 50%; background: var(--accent-2); box-shadow: 0 0 8px var(--accent-2); animation: vp-dot-pulse 1.5s ease-in-out infinite; }

    /* APP */
    .vp-app { position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%) scale(.96);
        width: min(1020px, calc(100vw - 60px)); height: min(780px, calc(100vh - 60px));
        z-index: 2147483645; background: var(--bg-app); border: 1px solid var(--border); border-radius: 20px;
        box-shadow: 0 40px 100px -20px rgba(0,0,0,.9), 0 0 0 1px rgba(255,255,255,.02);
        display: none; grid-template-columns: 220px 1fr; overflow: hidden; color: var(--text);
        font: 13px/1.5 -apple-system, BlinkMacSystemFont, "SF Pro Text", "Segoe UI", Roboto, sans-serif;
        opacity: 0; transition: opacity .3s, transform .3s cubic-bezier(.4,0,.2,1); -webkit-font-smoothing: antialiased; }
    .vp-app.vp-open { display: grid; }
    .vp-app.vp-visible { opacity: 1; transform: translate(-50%, -50%) scale(1); }
    .vp-app > * { position: relative; z-index: 3; }

    ::-webkit-scrollbar { width: 8px; height: 8px; }
    ::-webkit-scrollbar-track { background: transparent; }
    ::-webkit-scrollbar-thumb { background: #1e2740; border-radius: 8px; }
    ::-webkit-scrollbar-thumb:hover { background: #2a3352; }

    /* SIDEBAR */
    .vp-side { background: var(--bg-side); border-right: 1px solid var(--border); display: flex; flex-direction: column; padding: 20px 0 14px; min-height: 0; overflow-y: auto; }
    .vp-side-logo { padding: 0 18px 20px; display: flex; align-items: center; gap: 11px; }
    .vp-side-logo-icon { width: 42px; height: 42px; border-radius: 12px; flex-shrink: 0; display: flex; align-items: center; justify-content: center; background: linear-gradient(135deg, #f97316, #dc2626); box-shadow: 0 6px 18px -4px rgba(249,115,22,.5), inset 0 1px 0 rgba(255,255,255,.25); overflow: hidden; }
    .vp-side-logo-icon .vp-logo-img { width: 100%; height: 100%; object-fit: cover; }
    .vp-side-logo-icon svg { width: 100%; height: 100%; display: block; }
    .vp-side-logo-text { min-width: 0; }
    .vp-side-logo-title { font-size: 14px; font-weight: 700; color: #fff; letter-spacing: -.01em; line-height: 1.1; }
    .vp-side-logo-version { display: inline-block; font-size: 9px; font-weight: 700; color: var(--text-dim); background: var(--bg-card); padding: 2px 6px; border-radius: 5px; margin-top: 4px; letter-spacing: .05em; border: 1px solid var(--border); }
    .vp-side-section { padding: 4px 20px 8px; font-size: 10px; color: var(--text-mute); letter-spacing: .12em; font-weight: 700; text-transform: uppercase; }
    .vp-side-nav { padding: 0 10px; display: flex; flex-direction: column; gap: 2px; }
    .vp-nav-item { display: flex; align-items: center; gap: 10px; padding: 9px 11px; border-radius: 9px; background: transparent; border: 1px solid transparent; color: var(--text-dim); cursor: pointer; font: inherit; font-size: 12px; font-weight: 500; text-align: left; width: 100%; transition: all .15s; font-family: inherit; position: relative; }
    .vp-nav-item:hover { background: var(--bg-card); color: var(--text); }
    .vp-nav-item.vp-active { background: color-mix(in srgb, var(--accent) 14%, transparent); color: var(--accent-2); box-shadow: inset 0 0 0 1px var(--accent); }
    .vp-nav-item svg { width: 15px; height: 15px; flex-shrink: 0; }
    .vp-nav-item .vp-dev-chip { margin-left: auto; font-size: 8.5px; font-weight: 800; padding: 2px 5px; border-radius: 4px; background: rgba(245,158,11,.15); color: #fbbf24; border: 1px solid rgba(245,158,11,.3); letter-spacing: .04em; }
    .vp-side-bottom { margin-top: auto; padding: 12px 10px 0; display: flex; flex-direction: column; gap: 6px; }
    .vp-side-link { display: flex; align-items: center; gap: 10px; padding: 10px 12px; border-radius: 10px; background: linear-gradient(135deg, rgba(88,101,242,.12), rgba(88,101,242,.04)); border: 1px solid rgba(88,101,242,.3); color: #a5b4fc; font-size: 11.5px; font-weight: 600; cursor: pointer; text-decoration: none; transition: all .15s; }
    .vp-side-link svg { width: 16px; height: 16px; flex-shrink: 0; }
    .vp-side-link:hover { background: rgba(88,101,242,.18); border-color: rgba(88,101,242,.55); color: #c7d2fe; }
    .vp-side-collapse { display: flex; align-items: center; justify-content: center; gap: 10px; padding: 14px 16px; border-radius: 12px;
        background: linear-gradient(135deg, color-mix(in srgb, var(--accent) 22%, transparent), color-mix(in srgb, var(--accent-2) 12%, transparent));
        border: 1px solid color-mix(in srgb, var(--accent) 50%, transparent);
        color: var(--accent-2); cursor: pointer; font: inherit; font-size: 12px; font-weight: 700;
        transition: all .25s; font-family: inherit; position: relative; overflow: hidden;
        box-shadow: 0 6px 16px -8px var(--accent-glow), inset 0 1px 0 rgba(255,255,255,.1); }
    .vp-side-collapse:hover { transform: translateY(-2px); border-color: var(--accent); color: #fff; }
    .vp-side-collapse svg { width: 16px; height: 16px; flex-shrink: 0; }

    /* MAIN */
    .vp-main { display: flex; flex-direction: column; overflow: hidden; min-height: 0; position: relative; }
    .vp-topbar { display: flex; align-items: center; justify-content: space-between; padding: 12px 20px; border-bottom: 1px solid var(--border); flex-shrink: 0; position: relative; }
    .vp-topbar-left { display: flex; align-items: center; gap: 8px; }
    .vp-topbar-btn { width: 38px; height: 38px; border-radius: 10px; background: var(--bg-card); border: 1px solid var(--border); color: var(--text-dim); cursor: pointer; display: flex; align-items: center; justify-content: center; transition: all .15s; position: relative; }
    .vp-topbar-btn:hover { background: var(--bg-card-2); color: var(--text); border-color: var(--border-2); }
    .vp-topbar-btn svg { width: 17px; height: 17px; }
    .vp-topbar-right { display: flex; align-items: center; gap: 10px; }
    .vp-bell-badge { position: absolute; top: -3px; right: -3px; min-width: 18px; height: 18px; padding: 0 5px; border-radius: 9px; background: #ef4444; color: #fff; font-size: 10px; font-weight: 700; display: none; align-items: center; justify-content: center; border: 2px solid var(--bg-app); box-shadow: 0 2px 8px rgba(239,68,68,.5); }
    .vp-bell-badge.vp-show { display: flex; }
    .vp-notif-panel { position: absolute; top: 62px; right: 20px; width: 360px; max-height: 420px; background: var(--bg-card); border: 1px solid var(--border-2); border-radius: 14px; box-shadow: 0 24px 60px -12px rgba(0,0,0,.85); z-index: 100; display: none; flex-direction: column; overflow: hidden; opacity: 0; transform: translateY(-8px); transition: opacity .2s, transform .2s; }
    .vp-notif-panel.vp-open { display: flex; }
    .vp-notif-panel.vp-visible { opacity: 1; transform: none; }
    .vp-notif-head { display: flex; align-items: center; justify-content: space-between; padding: 12px 14px; border-bottom: 1px solid var(--border); font-size: 12px; font-weight: 600; color: var(--text); }
    .vp-notif-clear { background: transparent; border: none; color: var(--text-mute); font-size: 11px; cursor: pointer; padding: 4px 8px; border-radius: 6px; transition: all .15s; font-family: inherit; }
    .vp-notif-clear:hover { background: var(--bg-card-2); color: var(--text); }
    .vp-notif-list { overflow-y: auto; flex: 1; display: flex; flex-direction: column; padding: 6px; }
    .vp-notif-item { display: flex; gap: 10px; padding: 10px; border-radius: 9px; transition: background .15s; position: relative; }
    .vp-notif-item:hover { background: var(--bg-card-2); }
    .vp-notif-item.vp-unread::before { content: ''; position: absolute; left: 3px; top: 50%; transform: translateY(-50%); width: 3px; height: 60%; background: var(--accent); border-radius: 2px; }
    .vp-notif-icon { width: 30px; height: 30px; border-radius: 8px; flex-shrink: 0; display: flex; align-items: center; justify-content: center; background: var(--bg-app); color: var(--accent-2); font-size: 15px; }
    .vp-notif-icon.vp-success { color: #34d399; }
    .vp-notif-icon.vp-error   { color: #f87171; }
    .vp-notif-icon.vp-warn    { color: #f59e0b; }
    .vp-notif-icon.vp-badge   { color: #eab308; }
    .vp-notif-body { flex: 1; min-width: 0; }
    .vp-notif-title { font-size: 12px; font-weight: 600; color: var(--text); line-height: 1.3; }
    .vp-notif-text { font-size: 11.5px; color: var(--text-dim); margin-top: 2px; line-height: 1.4; }
    .vp-notif-time { font-size: 10px; color: var(--text-mute); margin-top: 4px; }
    .vp-notif-empty { padding: 40px 20px; text-align: center; color: var(--text-mute); font-size: 12px; }
    .vp-user-chip { display: flex; align-items: center; gap: 10px; padding: 4px 4px 4px 14px; background: var(--bg-card); border: 1px solid var(--border); border-radius: 26px; cursor: pointer; transition: all .15s; max-width: 240px; }
    .vp-user-chip:hover { background: var(--bg-card-2); border-color: var(--border-2); }
    .vp-user-chip-name { font-size: 12.5px; font-weight: 600; color: var(--text); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .vp-user-chip-avatar { width: 30px; height: 30px; border-radius: 50%; overflow: hidden; flex-shrink: 0; background: var(--accent); color: #fff; display: flex; align-items: center; justify-content: center; font-weight: 700; font-size: 12px; border: 2px solid var(--accent); }
    .vp-user-chip-avatar img { width: 100%; height: 100%; object-fit: cover; }
    .vp-content { flex: 1; overflow-y: auto; padding: 20px; display: flex; flex-direction: column; gap: 14px; min-height: 0; }

    .vp-page-title { font-size: 20px; font-weight: 700; color: #fff; letter-spacing: -.02em; margin-bottom: 2px; display: flex; align-items: center; justify-content: space-between; gap: 12px; flex-wrap: wrap; }
    .vp-page-sub { font-size: 12px; color: var(--text-dim); margin-bottom: 6px; }

    .vp-card { background: var(--bg-card); border: 1px solid var(--border); border-radius: 14px; padding: 16px; display: flex; flex-direction: column; gap: 10px; }
    .vp-label { font-size: 10px; font-weight: 700; color: var(--text-mute); text-transform: uppercase; letter-spacing: .08em; }
    .vp-input { background: var(--bg-app); border: 1px solid var(--border-2); border-radius: 9px; padding: 9px 12px; color: var(--text); font-size: 12.5px; font-family: inherit; outline: none; transition: all .15s; width: 100%; }
    .vp-input:focus { border-color: var(--accent); box-shadow: 0 0 0 3px color-mix(in srgb, var(--accent) 20%, transparent); }
    .vp-input::placeholder { color: var(--text-mute); }
    .vp-btn { background: var(--bg-card-2); border: 1px solid var(--border-2); color: var(--text); border-radius: 9px; padding: 10px 16px; font-size: 12.5px; font-weight: 500; font-family: inherit; cursor: pointer; transition: all .15s; display: inline-flex; align-items: center; justify-content: center; gap: 7px; }
    .vp-btn:hover { background: #1c2438; border-color: #354063; }
    .vp-btn:active { transform: scale(.98); }
    .vp-btn:disabled { opacity: .5; cursor: not-allowed; }
    .vp-btn.vp-primary { background: linear-gradient(180deg, var(--accent), var(--accent)); border-color: var(--accent); color: #fff; box-shadow: 0 6px 16px -4px var(--accent-glow), inset 0 1px 0 rgba(255,255,255,.15); }
    .vp-btn.vp-primary:hover { filter: brightness(1.1); }
    .vp-btn svg { width: 14px; height: 14px; }
    .vp-btn-sm { padding: 6px 12px; font-size: 11.5px; border-radius: 8px; }

    .vp-row { display: flex; align-items: center; gap: 12px; padding: 12px 14px; border-radius: 11px; background: var(--bg-card); border: 1px solid var(--border); transition: all .15s; }
    .vp-row[data-url], .vp-row[data-section-id] { cursor: pointer; }
    .vp-row[data-url]:hover, .vp-row[data-section-id]:hover { background: var(--bg-card-2); border-color: var(--border-2); }
    .vp-row-title { flex: 1; min-width: 0; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; color: var(--text); font-size: 13px; font-weight: 500; }
    .vp-badge-count { flex-shrink: 0; min-width: 30px; height: 28px; padding: 0 10px; border-radius: 8px; font-weight: 700; font-size: 13px; display: inline-flex; align-items: center; justify-content: center; font-variant-numeric: tabular-nums; }
    .vp-badge-count.vp-has { background: rgba(248,113,113,.14); color: #f87171; }
    .vp-badge-count.vp-clear { background: rgba(52,211,153,.14); color: #34d399; }
    .vp-empty { display: flex; flex-direction: column; align-items: center; gap: 10px; padding: 40px 20px; color: var(--text-mute); text-align: center; }
    .vp-empty svg { width: 36px; height: 36px; opacity: .35; }
    .vp-empty-text { font-size: 12.5px; }
    .vp-del { color: var(--text-mute); cursor: pointer; width: 28px; height: 28px; border-radius: 8px; display: inline-flex; align-items: center; justify-content: center; transition: all .12s; }
    .vp-del:hover { background: rgba(248,113,113,.14); color: #f87171; }
    .vp-del svg { width: 13px; height: 13px; }

    /* HOME */
    .vp-online-card { position: relative; padding: 22px 24px; border-radius: 18px;
        background: radial-gradient(circle at 0% 50%, color-mix(in srgb, var(--accent) 18%, transparent), transparent 55%), var(--bg-card);
        border: 1px solid color-mix(in srgb, var(--accent) 40%, transparent);
        display: flex; align-items: center; gap: 22px; overflow: hidden;
        box-shadow: 0 20px 50px -22px var(--accent-glow); }
    .vp-online-card::before { content: ''; position: absolute; top: 0; left: 0; right: 0; height: 1px; background: linear-gradient(90deg, transparent, var(--accent-2), transparent); }
    .vp-online-icon { width: 60px; height: 60px; border-radius: 16px; background: linear-gradient(135deg, var(--accent), var(--accent-2)); display: flex; align-items: center; justify-content: center; font-size: 28px; box-shadow: 0 14px 32px -8px var(--accent-glow), inset 0 2px 0 rgba(255,255,255,.2); flex-shrink: 0; }
    .vp-online-info { flex: 1; min-width: 0; }
    .vp-online-label { font-size: 11px; font-weight: 700; color: var(--text-mute); letter-spacing: .08em; text-transform: uppercase; margin-bottom: 4px; }
    .vp-online-value { font-size: 40px; font-weight: 800; line-height: 1; letter-spacing: -.03em;
        background: linear-gradient(180deg, #fff 30%, var(--accent-2));
        -webkit-background-clip: text; background-clip: text; -webkit-text-fill-color: transparent;
        font-variant-numeric: tabular-nums; margin-bottom: 4px; }
    .vp-online-value small { font-size: 18px; color: var(--text-mute); -webkit-text-fill-color: var(--text-mute); }
    .vp-online-hint { font-size: 11px; color: var(--text-mute); }
    .vp-online-status { display: inline-flex; align-items: center; gap: 8px; padding: 8px 14px; border-radius: 22px;
        background: rgba(52,211,153,.12); border: 1px solid rgba(52,211,153,.4); color: var(--success);
        font-size: 11px; font-weight: 800; letter-spacing: .06em;
        box-shadow: 0 0 22px -6px rgba(52,211,153,.5); flex-shrink: 0; }
    .vp-online-status::before { content: ''; width: 8px; height: 8px; border-radius: 50%; background: var(--success);
        box-shadow: 0 0 8px var(--success); animation: vp-pulse 1.6s ease-in-out infinite; }
    @keyframes vp-pulse { 0%,100% { opacity: 1; } 50% { opacity: .4; } }

    .vp-obt-news { position: relative; padding: 22px 26px 22px 30px; border-radius: 16px;
        background: linear-gradient(135deg, color-mix(in srgb, var(--accent) 15%, transparent), transparent 60%), var(--bg-card);
        border: 1px solid color-mix(in srgb, var(--accent) 45%, transparent); }
    .vp-obt-news::before { content: ''; position: absolute; left: 0; top: 16px; bottom: 16px; width: 4px;
        border-radius: 0 4px 4px 0; background: linear-gradient(180deg, var(--accent), var(--accent-2));
        box-shadow: 0 0 18px var(--accent-glow); }
    .vp-obt-head { display: flex; align-items: center; gap: 14px; margin-bottom: 14px; }
    .vp-obt-icon { width: 44px; height: 44px; border-radius: 12px; background: linear-gradient(135deg, var(--accent), var(--accent-2));
        display: flex; align-items: center; justify-content: center; font-size: 22px; box-shadow: 0 10px 22px -6px var(--accent-glow); flex-shrink: 0; }
    .vp-obt-head-text { flex: 1; min-width: 0; }
    .vp-obt-title { font-size: 17px; font-weight: 800; color: #fff; letter-spacing: -.01em; line-height: 1.2; }
    .vp-obt-badge { display: inline-flex; align-items: center; gap: 5px; padding: 3px 9px; border-radius: 20px;
        background: rgba(245,158,11,.18); border: 1px solid rgba(245,158,11,.4); color: #fbbf24;
        font-size: 9.5px; font-weight: 800; letter-spacing: .08em; text-transform: uppercase; vertical-align: middle; margin-left: 6px;
        animation: vp-obt-pulse 2s ease-in-out infinite; }
    @keyframes vp-obt-pulse { 0%,100% { box-shadow: 0 0 0 0 rgba(245,158,11,.5); } 50% { box-shadow: 0 0 0 8px rgba(245,158,11,0); } }
    .vp-obt-text { font-size: 13px; color: var(--text-dim); line-height: 1.7; margin-bottom: 6px; }
    .vp-obt-text b { color: var(--text); font-weight: 700; }
    .vp-obt-text .vp-obt-hl { color: var(--accent-2); font-weight: 700; }
    .vp-obt-actions { display: flex; gap: 10px; margin-top: 16px; flex-wrap: wrap; }

    /* PROFILE — HERO всегда с фоном */
    .vp-hero {
        display: flex; gap: 20px;
        padding: 22px;
        background:
            radial-gradient(circle at 0% 0%, color-mix(in srgb, var(--accent) 35%, transparent), transparent 55%),
            radial-gradient(circle at 100% 100%, color-mix(in srgb, var(--accent-2) 22%, transparent), transparent 60%),
            linear-gradient(180deg, var(--bg-card-2), var(--bg-card));
        border: 1px solid var(--border);
        border-radius: 16px;
        align-items: center;
        position: relative;
        overflow: hidden;
        isolation: isolate;
        min-height: 160px;
    }
    .vp-hero.with-banner { min-height: 180px; padding: 24px; }
    .vp-hero-banner-bg {
        position: absolute; inset: 0;
        background-size: cover;
        background-position: center;
        background-repeat: no-repeat;
        z-index: 0;
        pointer-events: none;
    }
    .vp-hero-banner-bg::after {
        content: ''; position: absolute; inset: 0;
        background: linear-gradient(180deg, rgba(10,14,26,.3) 0%, rgba(10,14,26,.7) 60%, rgba(10,14,26,.9) 100%);
    }
    .vp-hero > *:not(.vp-hero-banner-bg) { position: relative; z-index: 1; }

    .vp-hero-avatar { width: 100px; height: 100px; border-radius: 16px; flex-shrink: 0; overflow: hidden; border: 2px solid var(--accent); background: var(--bg-card-2);
        box-shadow: 0 0 0 4px color-mix(in srgb, var(--accent) 12%, transparent), 0 12px 30px -8px var(--accent-glow);
        display: flex; align-items: center; justify-content: center; color: #fff; font-size: 40px; font-weight: 800; }
    .vp-hero-avatar img { width: 100%; height: 100%; object-fit: cover; display: block; }
    .vp-hero-body { flex: 1; display: flex; flex-direction: column; gap: 10px; min-width: 0; }
    .vp-hero-name-row { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; }
    .vp-hero-name { font-size: 22px; font-weight: 700; color: #fff; letter-spacing: -.025em; line-height: 1.1; text-shadow: 0 2px 12px rgba(0,0,0,.6); }
    .vp-hero-role { display: inline-flex; align-items: center; gap: 6px; padding: 6px 12px; border-radius: 8px; font-size: 11.5px; font-weight: 800; letter-spacing: .04em; backdrop-filter: blur(6px); -webkit-backdrop-filter: blur(6px); }
    .vp-hero-role .vp-role-icon { font-size: 14px; }
    .vp-hero-status { font-size: 12px; color: var(--text-dim); line-height: 1.5; max-width: 100%; white-space: pre-wrap; word-wrap: break-word; text-shadow: 0 1px 4px rgba(0,0,0,.5); }
    .vp-hero-chips { display: flex; gap: 8px; flex-wrap: wrap; }
    .vp-chip { display: inline-flex; align-items: center; gap: 6px; padding: 6px 11px; border-radius: 8px;
        background: rgba(10,14,26,.55); border: 1px solid var(--border); color: var(--text-dim); font-size: 11.5px; font-weight: 500;
        backdrop-filter: blur(6px); -webkit-backdrop-filter: blur(6px); }
    .vp-chip b { color: var(--accent-2); font-weight: 700; font-size: 12.5px; }

    .vp-hero-banner-btn { position: absolute; top: 14px; right: 14px; z-index: 2; padding: 6px 12px; border-radius: 10px;
        background: rgba(10,14,26,.72); border: 1px solid var(--border-2); color: var(--text); font: inherit; font-size: 11px; font-weight: 600;
        cursor: pointer; display: inline-flex; align-items: center; gap: 6px;
        backdrop-filter: blur(8px); -webkit-backdrop-filter: blur(8px); transition: all .15s; }
    .vp-hero-banner-btn:hover { background: rgba(10,14,26,.92); border-color: var(--accent); }
    .vp-hero-banner-btn svg { width: 12px; height: 12px; }

    .vp-profile-stats { display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; }
    .vp-profile-stat { padding: 14px; border-radius: 12px; background: var(--bg-card); border: 1px solid var(--border); display: flex; flex-direction: column; gap: 4px; }
    .vp-profile-stat-val { font-size: 20px; font-weight: 800; color: #fff; font-variant-numeric: tabular-nums; }
    .vp-profile-stat-lbl { font-size: 10px; color: var(--text-mute); text-transform: uppercase; letter-spacing: .06em; font-weight: 700; }

    /* PROFILE CUSTOMIZE MODAL */
    .vp-pc-modal { position: absolute; inset: 0; z-index: 210; background: rgba(4, 6, 12, 0.75); backdrop-filter: blur(10px); -webkit-backdrop-filter: blur(10px); display: none; align-items: center; justify-content: center; opacity: 0; transition: opacity .25s; padding: 20px; }
    .vp-pc-modal.vp-open { display: flex; }
    .vp-pc-modal.vp-visible { opacity: 1; }
    .vp-pc-card { position: relative; width: 560px; max-width: 100%; max-height: calc(100% - 20px); border-radius: 20px; background: var(--bg-card); border: 1px solid var(--border-2);
        box-shadow: 0 30px 80px -20px rgba(0,0,0,.9); display: flex; flex-direction: column; overflow: hidden;
        transform: translateY(12px) scale(.97); transition: transform .35s cubic-bezier(.34,1.56,.64,1); }
    .vp-pc-modal.vp-visible .vp-pc-card { transform: none; }
    .vp-pc-head { padding: 16px 20px; border-bottom: 1px solid var(--border); display: flex; align-items: center; gap: 12px; flex-shrink: 0; }
    .vp-pc-title { font-size: 15px; font-weight: 800; color: #fff; letter-spacing: -.01em; flex: 1; }
    .vp-pc-close { width: 30px; height: 30px; border-radius: 8px; background: transparent; border: 1px solid transparent; color: var(--text-mute); cursor: pointer; display: flex; align-items: center; justify-content: center; transition: all .15s; }
    .vp-pc-close:hover { background: rgba(248,113,113,.14); color: #f87171; }
    .vp-pc-close svg { width: 14px; height: 14px; }
    .vp-pc-body { overflow-y: auto; padding: 18px 20px; display: flex; flex-direction: column; gap: 18px; }
    .vp-pc-section { display: flex; flex-direction: column; gap: 10px; }
    .vp-pc-section-title { font-size: 11px; font-weight: 800; color: var(--text-mute); text-transform: uppercase; letter-spacing: .08em; display: flex; align-items: center; gap: 8px; }
    .vp-pc-banner-preview { width: 100%; height: 110px; border-radius: 12px; background: var(--bg-app); border: 1px dashed var(--border-2); background-size: cover; background-position: center; display: flex; align-items: center; justify-content: center; overflow: hidden; position: relative; }
    .vp-pc-banner-preview-empty { color: var(--text-mute); font-size: 12px; display: flex; flex-direction: column; align-items: center; gap: 6px; }
    .vp-pc-banner-preview-empty svg { width: 26px; height: 26px; opacity: .5; }
    .vp-pc-presets { display: grid; grid-template-columns: repeat(6, 1fr); gap: 8px; }
    .vp-pc-preset { aspect-ratio: 1.5 / 1; border-radius: 9px; cursor: pointer; border: 2px solid transparent; transition: all .15s; position: relative; }
    .vp-pc-preset:hover { transform: translateY(-2px); border-color: rgba(255,255,255,.5); }
    .vp-pc-preset.vp-active { border-color: #fff; box-shadow: 0 0 0 2px rgba(255,255,255,.15); }
    .vp-pc-preset.vp-active::after { content: '✓'; position: absolute; top: 2px; right: 4px; font-size: 10px; font-weight: 800; color: #fff; text-shadow: 0 0 4px rgba(0,0,0,.8); }
    .vp-pc-frames { display: grid; grid-template-columns: repeat(6, 1fr); gap: 8px; }
    .vp-pc-frame { aspect-ratio: 1/1; border-radius: 12px; cursor: pointer; border: 2px solid transparent; background: var(--bg-app); display: flex; align-items: center; justify-content: center; transition: all .15s; padding: 6px; }
    .vp-pc-frame:hover { background: var(--bg-card-2); }
    .vp-pc-frame.vp-active { border-color: var(--accent); box-shadow: 0 0 0 2px color-mix(in srgb, var(--accent) 25%, transparent); }
    .vp-pc-frame-demo { width: 30px; height: 30px; border-radius: 8px; background: linear-gradient(135deg, var(--accent), var(--accent-2)); }
    .vp-pc-colors { display: flex; gap: 8px; flex-wrap: wrap; }
    .vp-pc-color { width: 30px; height: 30px; border-radius: 50%; cursor: pointer; border: 2px solid transparent; transition: all .15s; }
    .vp-pc-color:hover { transform: scale(1.1); }
    .vp-pc-color.vp-active { border-color: #fff; box-shadow: 0 0 0 2px rgba(255,255,255,.2); }
    .vp-pc-actions { display: flex; gap: 8px; flex-wrap: wrap; }
    .vp-pc-actions .vp-btn { flex: 1; min-width: 130px; }
    .vp-pc-chips-list { display: flex; flex-direction: column; gap: 6px; }
    .vp-pc-chip-row { display: flex; align-items: center; justify-content: space-between; padding: 8px 10px; border-radius: 9px; background: var(--bg-app); border: 1px solid var(--border); font-size: 12px; }
    .vp-pc-chip-row-label { color: var(--text-dim); }

    .vp-toggle { position: relative; width: 38px; height: 22px; flex-shrink: 0; border-radius: 22px; background: var(--bg-app); border: 1px solid var(--border-2); cursor: pointer; transition: all .2s; }
    .vp-toggle::after { content: ''; position: absolute; top: 2px; left: 2px; width: 16px; height: 16px; border-radius: 50%; background: var(--text-mute); transition: all .2s cubic-bezier(.34,1.56,.64,1); }
    .vp-toggle.vp-on { background: var(--accent); border-color: var(--accent); }
    .vp-toggle.vp-on::after { left: 18px; background: #fff; box-shadow: 0 2px 6px rgba(0,0,0,.3); }

    /* ADMINTOOLS */
    .vp-at-dev-card {
        padding: 26px;
        background:
            radial-gradient(circle at 0% 0%, rgba(245,158,11,.14), transparent 60%),
            radial-gradient(circle at 100% 100%, rgba(251,191,36,.06), transparent 60%),
            var(--bg-card);
        border: 1px solid rgba(245,158,11,.35);
        border-left: 4px solid #f59e0b;
        border-radius: 16px;
        display: flex; gap: 18px;
        position: relative;
        overflow: hidden;
    }
    .vp-at-dev-card::before {
        content: '';
        position: absolute; top: -50%; right: -20%;
        width: 320px; height: 320px; border-radius: 50%;
        background: radial-gradient(circle, rgba(245,158,11,.18), transparent 70%);
        animation: vp-at-pulse 6s ease-in-out infinite;
        pointer-events: none;
    }
    @keyframes vp-at-pulse {
        0%,100% { transform: scale(1); opacity: .6; }
        50%     { transform: scale(1.15); opacity: .9; }
    }
    .vp-at-dev-card > * { position: relative; z-index: 1; }
    .vp-at-dev-icon {
        width: 62px; height: 62px; border-radius: 16px;
        background: linear-gradient(135deg, rgba(245,158,11,.25), rgba(251,191,36,.12));
        border: 1px solid rgba(245,158,11,.45);
        color: #fbbf24;
        display: flex; align-items: center; justify-content: center;
        font-size: 30px;
        flex-shrink: 0;
        box-shadow: 0 10px 26px -8px rgba(245,158,11,.5), inset 0 1px 0 rgba(255,255,255,.1);
        animation: vp-rotate-slow 12s linear infinite;
    }
    @keyframes vp-rotate-slow { from { transform: rotate(0); } to { transform: rotate(360deg); } }
    .vp-at-dev-body { flex: 1; min-width: 0; }
    .vp-at-dev-title {
        font-size: 17px; font-weight: 800; color: #fff;
        letter-spacing: -.01em;
        margin-bottom: 12px;
        display: flex; align-items: center; gap: 10px;
        flex-wrap: wrap;
    }
    .vp-at-dev-badge {
        display: inline-flex; align-items: center; gap: 5px;
        padding: 4px 10px; border-radius: 20px;
        background: rgba(245,158,11,.22);
        border: 1px solid rgba(245,158,11,.5);
        color: #fbbf24;
        font-size: 9.5px; font-weight: 800;
        letter-spacing: .08em; text-transform: uppercase;
        animation: vp-obt-pulse 2s ease-in-out infinite;
    }
    .vp-at-dev-text {
        font-size: 13px; color: var(--text-dim); line-height: 1.75;
    }
    .vp-at-dev-text b { color: #fbbf24; font-weight: 700; }
    .vp-at-dev-text .vp-at-hl {
        color: var(--accent-2); font-weight: 700;
        padding: 1px 6px; border-radius: 5px;
        background: color-mix(in srgb, var(--accent) 12%, transparent);
    }

    /* FLAME */
    .vp-flame-page {
        padding: 16px 14px;
        border-radius: 16px;
        background: radial-gradient(circle at 50% 0%, rgba(249,115,22,.18), transparent 60%), var(--bg-card);
        border: 1px solid var(--border);
        display: flex; flex-direction: column; align-items: center; gap: 12px;
        position: relative; overflow: hidden;
        width: 100%;
    }
    .vp-flame-page > * { position: relative; z-index: 1; max-width: 100%; }

    .vp-flame-visual { width: 110px; height: 110px; position: relative; display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
    .vp-flame-halo { position: absolute; inset: -10%; border-radius: 50%; border: 2px dashed rgba(249,115,22,.35); opacity: 0; animation: vp-flame-spin 14s linear infinite; }
    .vp-flame-halo-2 { inset: -22%; border-style: dotted; border-color: rgba(251,146,60,.2); animation-duration: 22s; animation-direction: reverse; }
    .vp-flame-glow { position: absolute; inset: 5%; border-radius: 50%; background: radial-gradient(circle, rgba(249,115,22,.55), transparent 65%); opacity: 0; filter: blur(12px); }
    @keyframes vp-flame-spin { to { transform: rotate(360deg); } }
    .vp-flame-lv1 .vp-flame-glow { opacity: .35; }
    .vp-flame-lv2 .vp-flame-glow { opacity: .55; }
    .vp-flame-lv3 .vp-flame-glow { opacity: .75; }
    .vp-flame-lv4 .vp-flame-glow { opacity: .9; }
    .vp-flame-lv5 .vp-flame-glow { opacity: 1; }
    .vp-flame-lv6 .vp-flame-glow { opacity: 1; inset: 0%; }
    .vp-flame-lv7 .vp-flame-glow { opacity: 1; inset: -5%; background: radial-gradient(circle, rgba(249,115,22,.8), rgba(220,38,38,.4) 45%, transparent 70%); }
    .vp-flame-lv3 .vp-flame-halo { opacity: .5; animation-duration: 12s; }
    .vp-flame-lv4 .vp-flame-halo { opacity: .65; animation-duration: 10s; }
    .vp-flame-lv5 .vp-flame-halo { opacity: .8; animation-duration: 8s; }
    .vp-flame-lv6 .vp-flame-halo { opacity: .9; animation-duration: 6s; }
    .vp-flame-lv7 .vp-flame-halo { opacity: 1; animation-duration: 4s; border-color: rgba(249,115,22,.7); }
    .vp-flame-lv5 .vp-flame-halo-2, .vp-flame-lv6 .vp-flame-halo-2, .vp-flame-lv7 .vp-flame-halo-2 { opacity: .8; }

    .vp-flame-emoji { font-size: 68px; line-height: 1; position: relative; z-index: 2; transition: filter .3s; animation: vp-flame-breathe 2.6s ease-in-out infinite; user-select: none; }
    @keyframes vp-flame-breathe { 0%,100% { transform: scale(1); } 50% { transform: scale(1.06); } }
    .vp-flame-lv0 .vp-flame-emoji { filter: grayscale(1) brightness(.5); opacity: .4; animation: none; }
    .vp-flame-lv1 .vp-flame-emoji { filter: drop-shadow(0 0 12px rgba(249,115,22,.7)); }
    .vp-flame-lv2 .vp-flame-emoji { filter: drop-shadow(0 0 16px rgba(249,115,22,.8)); }
    .vp-flame-lv3 .vp-flame-emoji { filter: drop-shadow(0 0 20px rgba(249,115,22,.9)); animation: vp-flame-breathe 2s ease-in-out infinite, vp-flame-wobble 3s ease-in-out infinite; }
    .vp-flame-lv4 .vp-flame-emoji { filter: drop-shadow(0 0 24px rgba(249,115,22,1)); animation: vp-flame-breathe 1.7s ease-in-out infinite, vp-flame-wobble 2.4s ease-in-out infinite; }
    .vp-flame-lv5 .vp-flame-emoji { filter: drop-shadow(0 0 30px rgba(249,115,22,1)) drop-shadow(0 0 50px rgba(220,38,38,.6));
        animation: vp-flame-breathe 1.4s ease-in-out infinite, vp-flame-wobble 2s ease-in-out infinite, vp-flame-flicker .6s ease-in-out infinite alternate; }
    .vp-flame-lv6 .vp-flame-emoji { filter: drop-shadow(0 0 34px rgba(249,115,22,1)) drop-shadow(0 0 60px rgba(220,38,38,.8));
        animation: vp-flame-breathe 1.1s ease-in-out infinite, vp-flame-wobble 1.6s ease-in-out infinite, vp-flame-flicker .4s ease-in-out infinite alternate; }
    .vp-flame-lv7 .vp-flame-emoji { filter: drop-shadow(0 0 40px rgba(249,115,22,1)) drop-shadow(0 0 70px rgba(220,38,38,1));
        animation: vp-flame-breathe .9s ease-in-out infinite, vp-flame-wobble 1.2s ease-in-out infinite, vp-flame-flicker .3s ease-in-out infinite alternate, vp-flame-rainbow 6s linear infinite; }
    @keyframes vp-flame-wobble { 0%,100% { transform: rotate(-4deg) scale(1); } 50% { transform: rotate(4deg) scale(1.06); } }
    @keyframes vp-flame-flicker { 0% { filter: brightness(1) drop-shadow(0 0 24px rgba(249,115,22,.9)); } 100% { filter: brightness(1.25) drop-shadow(0 0 40px rgba(249,115,22,1)); } }
    @keyframes vp-flame-rainbow { 0%,100% { filter: drop-shadow(0 0 40px rgba(249,115,22,1)) drop-shadow(0 0 70px rgba(220,38,38,1)) hue-rotate(0deg); } 50% { filter: drop-shadow(0 0 40px rgba(249,115,22,1)) drop-shadow(0 0 70px rgba(220,38,38,1)) hue-rotate(25deg); } }

    .vp-flame-spark { position: absolute; width: 4px; height: 4px; border-radius: 50%; background: #fb923c;
        box-shadow: 0 0 8px #fb923c, 0 0 16px #f97316; z-index: 3; pointer-events: none; }
    .vp-flame-spark:nth-child(4) { animation: vp-flame-spark-1 2.6s ease-out infinite; }
    .vp-flame-spark:nth-child(5) { animation: vp-flame-spark-2 3.1s ease-out infinite .4s; }
    .vp-flame-spark:nth-child(6) { animation: vp-flame-spark-3 2.8s ease-out infinite .8s; }
    .vp-flame-spark:nth-child(7) { animation: vp-flame-spark-4 3.4s ease-out infinite 1.2s; }
    .vp-flame-spark:nth-child(8) { animation: vp-flame-spark-5 2.9s ease-out infinite 1.6s; }
    .vp-flame-spark:nth-child(9) { animation: vp-flame-spark-6 3.2s ease-out infinite 2s; }
    .vp-flame-spark:nth-child(10) { animation: vp-flame-spark-1 3.6s ease-out infinite 2.4s; }
    .vp-flame-spark:nth-child(11) { animation: vp-flame-spark-2 2.7s ease-out infinite 2.8s; }
    .vp-flame-spark:nth-child(12) { animation: vp-flame-spark-3 3.3s ease-out infinite 3.2s; }
    @keyframes vp-flame-spark-1 { 0% { transform: translate(0,0) scale(1); opacity: 1; } 100% { transform: translate(-40px,-70px) scale(0); opacity: 0; } }
    @keyframes vp-flame-spark-2 { 0% { transform: translate(0,0) scale(1); opacity: 1; } 100% { transform: translate(35px,-80px) scale(0); opacity: 0; } }
    @keyframes vp-flame-spark-3 { 0% { transform: translate(0,0) scale(1); opacity: 1; } 100% { transform: translate(-25px,-90px) scale(0); opacity: 0; } }
    @keyframes vp-flame-spark-4 { 0% { transform: translate(0,0) scale(1); opacity: 1; } 100% { transform: translate(50px,-60px) scale(0); opacity: 0; } }
    @keyframes vp-flame-spark-5 { 0% { transform: translate(0,0) scale(1); opacity: 1; } 100% { transform: translate(-55px,-50px) scale(0); opacity: 0; } }
    @keyframes vp-flame-spark-6 { 0% { transform: translate(0,0) scale(1); opacity: 1; } 100% { transform: translate(30px,-95px) scale(0); opacity: 0; } }

    .vp-flame-streak-num { font-size: 38px; font-weight: 800; line-height: 1; letter-spacing: -.03em; font-variant-numeric: tabular-nums;
        background: linear-gradient(180deg, #fff 20%, #fb923c 100%);
        -webkit-background-clip: text; background-clip: text; -webkit-text-fill-color: transparent; text-align: center; }
    .vp-flame-streak-label { font-size: 11px; color: var(--text-dim); font-weight: 600; text-align: center; }
    .vp-flame-streak-label b { color: #fb923c; }

    .vp-flame-mini-stats { display: flex; gap: 6px; flex-wrap: wrap; justify-content: center; }
    .vp-flame-mini-stat { padding: 6px 10px; background: var(--bg-app); border: 1px solid var(--border); border-radius: 8px; display: flex; flex-direction: column; align-items: center; gap: 1px; min-width: 58px; }
    .vp-flame-mini-stat b { font-size: 13px; font-weight: 800; color: var(--text); }
    .vp-flame-mini-stat span { font-size: 9px; color: var(--text-mute); text-transform: uppercase; letter-spacing: .05em; font-weight: 600; }

    .vp-flame-progress { width: 100%; max-width: 340px; display: flex; flex-direction: column; gap: 6px; }
    .vp-flame-progress-head { display: flex; justify-content: space-between; align-items: center; font-size: 10.5px; color: var(--text-dim); gap: 8px; }
    .vp-flame-progress-head b { color: #fb923c; }
    .vp-flame-progress-bar { height: 6px; border-radius: 6px; background: var(--bg-app); overflow: hidden; border: 1px solid var(--border); position: relative; }
    .vp-flame-progress-fill { height: 100%; border-radius: 6px; background: linear-gradient(90deg, #f97316, #fb923c); box-shadow: 0 0 12px rgba(249,115,22,.6); transition: width 1s cubic-bezier(.4,0,.2,1); position: relative; }
    .vp-flame-progress-fill::after { content: ''; position: absolute; inset: 0; background: linear-gradient(90deg, transparent, rgba(255,255,255,.35), transparent); animation: vp-shimmer 2s linear infinite; }

    .vp-flame-btn { padding: 7px 16px; border-radius: 9px; font: inherit; font-size: 11.5px; font-weight: 700; cursor: pointer;
        transition: all .2s; border: 1px solid transparent; display: inline-flex; align-items: center; gap: 5px; }
    .vp-flame-btn:not(:disabled) { background: linear-gradient(180deg, #f97316, #ea580c); border-color: #fb923c; color: #fff;
        box-shadow: 0 6px 16px -8px rgba(249,115,22,.7), inset 0 1px 0 rgba(255,255,255,.2); }
    .vp-flame-btn:not(:disabled):hover { transform: translateY(-1px); }
    .vp-flame-btn:disabled { background: var(--bg-card-2); border-color: var(--border-2); color: var(--text-mute); cursor: not-allowed; }

    .vp-flame-calendar { width: 100%; max-width: 340px; display: grid; grid-template-columns: repeat(7, 1fr); gap: 4px; }
    .vp-flame-day { padding: 5px 2px; border-radius: 8px; background: var(--bg-app); border: 1px solid var(--border);
        display: flex; flex-direction: column; align-items: center; gap: 2px; transition: all .25s; min-width: 0; }
    .vp-flame-day.vp-on { background: linear-gradient(180deg, rgba(249,115,22,.18), rgba(249,115,22,.05));
        border-color: rgba(249,115,22,.55); box-shadow: 0 0 10px -4px rgba(249,115,22,.6); }
    .vp-flame-day.vp-today { border-color: #fb923c; box-shadow: 0 0 0 1.5px rgba(251,146,60,.35); }
    .vp-flame-day-name { font-size: 8.5px; color: var(--text-mute); text-transform: uppercase; letter-spacing: .04em; font-weight: 700; }
    .vp-flame-day.vp-on .vp-flame-day-name { color: #fb923c; }
    .vp-flame-day-icon { font-size: 13px; line-height: 1; filter: grayscale(1) brightness(.5); transition: filter .25s; }
    .vp-flame-day.vp-on .vp-flame-day-icon { filter: none; }
    .vp-flame-day-date { font-size: 8px; color: var(--text-mute); font-variant-numeric: tabular-nums; }

    .vp-flame-levels { display: grid; grid-template-columns: repeat(7, 1fr); gap: 5px; width: 100%; }
    @media (max-width: 760px) { .vp-flame-levels { grid-template-columns: repeat(4, 1fr); } }
    .vp-flame-level-card { padding: 6px 3px; background: var(--bg-app); border: 1px solid var(--border); border-radius: 8px;
        display: flex; flex-direction: column; align-items: center; gap: 2px; text-align: center; transition: all .25s; min-width: 0; }
    .vp-flame-level-card.vp-reached { background: linear-gradient(180deg, rgba(249,115,22,.09), transparent); border-color: rgba(249,115,22,.35); }
    .vp-flame-level-card.vp-active { border-color: #f97316; box-shadow: 0 0 14px -6px rgba(249,115,22,.7); background: linear-gradient(180deg, rgba(249,115,22,.18), transparent); }
    .vp-flame-level-icon { font-size: 16px; line-height: 1; filter: grayscale(.5); }
    .vp-flame-level-card.vp-reached .vp-flame-level-icon { filter: none; }
    .vp-flame-level-name { font-size: 9px; font-weight: 800; color: var(--text-dim); line-height: 1.2; }
    .vp-flame-level-card.vp-active .vp-flame-level-name { color: #fb923c; }
    .vp-flame-level-req { font-size: 8px; color: var(--text-mute); }

    .vp-flame-achievements { display: grid; grid-template-columns: repeat(7, 1fr); gap: 5px; width: 100%; }
    @media (max-width: 760px) { .vp-flame-achievements { grid-template-columns: repeat(4, 1fr); } }
    .vp-flame-ach { padding: 6px 3px; border-radius: 8px; background: var(--bg-app); border: 1px solid var(--border);
        display: flex; flex-direction: column; align-items: center; gap: 2px; text-align: center; transition: all .25s; position: relative; min-width: 0; }
    .vp-flame-ach.vp-unlocked { background: linear-gradient(180deg, rgba(249,115,22,.14), transparent); border-color: rgba(249,115,22,.5); box-shadow: 0 0 10px -4px rgba(249,115,22,.6); }
    .vp-flame-ach.vp-unlocked::after { content: '✓'; position: absolute; top: 2px; right: 3px; font-size: 8px; font-weight: 800; color: #34d399; }
    .vp-flame-ach-icon { font-size: 14px; line-height: 1; filter: grayscale(1) brightness(.55); }
    .vp-flame-ach.vp-unlocked .vp-flame-ach-icon { filter: none; }
    .vp-flame-ach-name { font-size: 8px; font-weight: 700; color: var(--text-mute); line-height: 1.2; }
    .vp-flame-ach.vp-unlocked .vp-flame-ach-name { color: var(--text); }
    .vp-flame-ach-req { font-size: 7.5px; color: var(--text-mute); }

    .vp-flame-week { width: 100%; max-width: 340px; padding: 10px 12px; background: var(--bg-app); border: 1px solid var(--border); border-radius: 10px; display: flex; flex-direction: column; gap: 8px; }
    .vp-flame-week-head { display: flex; justify-content: space-between; align-items: center; font-size: 10.5px; color: var(--text-dim); font-weight: 600; }
    .vp-flame-week-head b { color: var(--text); }
    .vp-flame-week-bars { display: grid; grid-template-columns: repeat(7, 1fr); gap: 4px; align-items: end; height: 45px; }
    .vp-flame-week-col { display: flex; flex-direction: column; align-items: center; gap: 2px; height: 100%; justify-content: flex-end; min-width: 0; }
    .vp-flame-week-bar { width: 100%; border-radius: 4px 4px 2px 2px; background: linear-gradient(180deg, #fb923c, #ea580c); box-shadow: 0 0 8px -3px rgba(249,115,22,.7); min-height: 3px; transition: height .4s; }
    .vp-flame-week-name { font-size: 8px; color: var(--text-mute); font-weight: 700; }
    .vp-flame-week-val { font-size: 8px; color: var(--text-dim); font-variant-numeric: tabular-nums; }

    .vp-flame-forecast { width: 100%; max-width: 340px; padding: 9px 12px; background: linear-gradient(135deg, rgba(249,115,22,.1), transparent);
        border: 1px solid rgba(249,115,22,.35); border-radius: 10px; display: flex; align-items: center; gap: 10px; }
    .vp-flame-forecast-icon { width: 32px; height: 32px; border-radius: 9px; background: rgba(249,115,22,.18); border: 1px solid rgba(249,115,22,.4);
        color: #fb923c; display: flex; align-items: center; justify-content: center; font-size: 15px; flex-shrink: 0; }
    .vp-flame-forecast-body { flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 2px; }
    .vp-flame-forecast-title { font-size: 11px; font-weight: 700; color: var(--text); }
    .vp-flame-forecast-desc { font-size: 10px; color: var(--text-dim); line-height: 1.4; }
    .vp-flame-forecast-desc b { color: #fb923c; }

    /* THREAD VIEWER */
    .vp-tv { position: absolute; inset: 0; z-index: 150; background: var(--bg-app); display: none; flex-direction: column; opacity: 0; transition: opacity .25s; }
    .vp-tv.vp-open { display: flex; }
    .vp-tv.vp-visible { opacity: 1; }
    .vp-tv-head { display: flex; align-items: center; gap: 14px; padding: 14px 20px; border-bottom: 1px solid var(--border); background: var(--bg-card); flex-shrink: 0; }
    .vp-tv-back { width: 34px; height: 34px; border-radius: 9px; background: var(--bg-app); border: 1px solid var(--border); color: var(--text-dim); cursor: pointer; display: flex; align-items: center; justify-content: center; transition: all .15s; }
    .vp-tv-back:hover { background: var(--bg-card-2); color: var(--text); border-color: var(--accent); }
    .vp-tv-back svg { width: 16px; height: 16px; }
    .vp-tv-title { flex: 1; min-width: 0; font-size: 14px; font-weight: 700; color: var(--text); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .vp-tv-title small { display: block; font-size: 11px; color: var(--text-mute); font-weight: 500; margin-top: 2px; }
    .vp-tv-ext { padding: 8px 14px; border-radius: 8px; background: var(--bg-card-2); border: 1px solid var(--border-2); color: var(--text-dim); text-decoration: none; font-size: 11.5px; font-weight: 600; display: inline-flex; align-items: center; gap: 6px; transition: all .15s; flex-shrink: 0; }
    .vp-tv-ext:hover { background: #1c2438; border-color: var(--accent); color: var(--text); }
    .vp-tv-ext svg { width: 13px; height: 13px; }
    .vp-tv-body { flex: 1; overflow-y: auto; padding: 16px 20px; display: flex; flex-direction: column; gap: 12px; min-height: 0; }
    .vp-tv-post { padding: 14px 16px; background: var(--bg-card); border: 1px solid var(--border); border-radius: 12px; }
    .vp-tv-post-head { display: flex; align-items: center; gap: 10px; padding-bottom: 10px; margin-bottom: 10px; border-bottom: 1px solid var(--border); }
    .vp-tv-post-avatar { width: 34px; height: 34px; border-radius: 50%; background: var(--bg-card-2); overflow: hidden; display: flex; align-items: center; justify-content: center; color: var(--text-dim); font-weight: 700; font-size: 13px; flex-shrink: 0; }
    .vp-tv-post-avatar img { width: 100%; height: 100%; object-fit: cover; }
    .vp-tv-post-author { font-size: 12.5px; font-weight: 700; color: var(--text); }
    .vp-tv-post-time { font-size: 10.5px; color: var(--text-mute); margin-left: auto; }
    .vp-tv-post-body { font-size: 12.5px; color: var(--text-dim); line-height: 1.6; word-wrap: break-word; overflow-wrap: break-word; }
    .vp-tv-post-body img { max-width: 100%; height: auto; border-radius: 8px; margin: 6px 0; }
    .vp-tv-post-body a { color: var(--accent-2); text-decoration: none; }
    .vp-tv-post-body a:hover { text-decoration: underline; }
    .vp-tv-post-body blockquote { border-left: 3px solid var(--border-2); padding: 6px 10px; margin: 6px 0; background: var(--bg-app); border-radius: 0 8px 8px 0; color: var(--text-mute); font-size: 11.5px; }
    .vp-tv-post-body .bbCodeBlock { padding: 8px 12px; margin: 6px 0; background: var(--bg-app); border: 1px solid var(--border); border-radius: 8px; font-size: 11.5px; }
    .vp-tv-loading { display: flex; flex-direction: column; align-items: center; gap: 12px; padding: 60px 20px; color: var(--text-mute); font-size: 12.5px; }
    .vp-tv-spinner { width: 28px; height: 28px; border: 3px solid var(--border-2); border-top-color: var(--accent); border-radius: 50%; animation: vp-spin .8s linear infinite; }

    .vp-tv-reply { padding: 14px 20px; border-top: 1px solid var(--border); background: var(--bg-card); flex-shrink: 0; display: flex; flex-direction: column; gap: 10px; }
    .vp-tv-reply-label { font-size: 10px; font-weight: 700; color: var(--text-mute); letter-spacing: .08em; text-transform: uppercase; display: flex; align-items: center; gap: 8px; }
    .vp-tv-reply-label .vp-tv-reply-badge { padding: 2px 7px; border-radius: 4px; background: color-mix(in srgb, var(--accent) 15%, transparent); color: var(--accent-2); font-size: 9.5px; }
    .vp-tv-reply-textarea { width: 100%; min-height: 70px; max-height: 160px; padding: 10px 12px; background: var(--bg-app); border: 1px solid var(--border-2); border-radius: 9px; color: var(--text); font-size: 12.5px; font-family: inherit; outline: none; resize: vertical; transition: border-color .15s, box-shadow .15s; }
    .vp-tv-reply-textarea:focus { border-color: var(--accent); box-shadow: 0 0 0 3px color-mix(in srgb, var(--accent) 20%, transparent); }
    .vp-tv-reply-textarea::placeholder { color: var(--text-mute); }
    .vp-tv-reply-actions { display: flex; justify-content: space-between; align-items: center; gap: 10px; }
    .vp-tv-reply-hint { font-size: 10.5px; color: var(--text-mute); }
    .vp-tv-reply-btns { display: flex; gap: 8px; }

    /* DRAWER */
    .vp-drawer-backdrop { position: absolute; inset: 0; background: rgba(4, 6, 12, 0.55); backdrop-filter: blur(3px); -webkit-backdrop-filter: blur(3px); opacity: 0; pointer-events: none; transition: opacity .25s; z-index: 50; }
    .vp-drawer-backdrop.vp-show { opacity: 1; pointer-events: auto; }
    .vp-drawer { position: absolute; top: 0; right: 0; bottom: 0; width: 480px; max-width: calc(100% - 80px); background: var(--bg-card); border-left: 1px solid var(--border-2); box-shadow: -24px 0 60px -12px rgba(0,0,0,.7); z-index: 60; display: none; flex-direction: column; transform: translateX(100%); transition: transform .3s cubic-bezier(.4,0,.2,1); }
    .vp-drawer.vp-open { display: flex; }
    .vp-drawer.vp-visible { transform: translateX(0); }
    .vp-drawer-head { padding: 16px 18px; border-bottom: 1px solid var(--border); display: flex; align-items: flex-start; gap: 12px; flex-shrink: 0; }
    .vp-drawer-head-info { flex: 1; min-width: 0; }
    .vp-drawer-head-title { font-size: 15px; font-weight: 700; color: #fff; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; letter-spacing: -.01em; }
    .vp-drawer-head-sub { font-size: 11.5px; color: var(--text-dim); margin-top: 3px; }
    .vp-drawer-close { width: 30px; height: 30px; border-radius: 8px; background: var(--bg-app); border: 1px solid var(--border); color: var(--text-dim); cursor: pointer; display: flex; align-items: center; justify-content: center; transition: all .15s; flex-shrink: 0; }
    .vp-drawer-close:hover { background: rgba(248,113,113,.14); color: #f87171; border-color: rgba(248,113,113,.3); }
    .vp-drawer-close svg { width: 14px; height: 14px; }
    .vp-drawer-actions { padding: 10px 14px; border-bottom: 1px solid var(--border); display: flex; gap: 8px; flex-shrink: 0; }
    .vp-drawer-actions .vp-btn { flex: 1; font-size: 11.5px; padding: 8px 12px; }
    .vp-drawer-body { flex: 1; overflow-y: auto; padding: 10px; display: flex; flex-direction: column; gap: 6px; min-height: 0; }
    .vp-drawer-thread { display: flex; align-items: flex-start; gap: 10px; padding: 11px 12px; border-radius: 10px; background: var(--bg-app); border: 1px solid var(--border); cursor: pointer; transition: all .15s; color: inherit; }
    .vp-drawer-thread:hover { background: var(--bg-card-2); border-color: var(--accent); }
    .vp-drawer-thread-icon { width: 28px; height: 28px; border-radius: 7px; background: var(--bg-card-2); border: 1px solid var(--border); display: flex; align-items: center; justify-content: center; color: var(--text-mute); flex-shrink: 0; font-size: 14px; }
    .vp-drawer-thread.vp-closed .vp-drawer-thread-icon { color: #34d399; background: rgba(52,211,153,.1); border-color: rgba(52,211,153,.25); }
    .vp-drawer-thread.vp-open .vp-drawer-thread-icon { color: #f87171; background: rgba(248,113,113,.1); border-color: rgba(248,113,113,.25); }
    .vp-drawer-thread-body { flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 3px; }
    .vp-drawer-thread-title { font-size: 12.5px; color: var(--text); font-weight: 500; line-height: 1.35; overflow: hidden; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; }
    .vp-drawer-thread-meta { font-size: 10.5px; color: var(--text-mute); display: flex; align-items: center; gap: 6px; }
    .vp-drawer-thread-tag { display: inline-block; padding: 1px 6px; border-radius: 4px; font-size: 9.5px; font-weight: 700; letter-spacing: .04em; text-transform: uppercase; }
    .vp-drawer-thread-tag.vp-open { background: rgba(248,113,113,.14); color: #f87171; }
    .vp-drawer-thread-tag.vp-closed { background: rgba(52,211,153,.14); color: #34d399; }
    .vp-drawer-thread-arrow { color: var(--text-mute); flex-shrink: 0; margin-top: 2px; display: flex; gap: 4px; }
    .vp-drawer-thread-btn { width: 26px; height: 26px; border-radius: 6px; background: var(--bg-card-2); border: 1px solid var(--border-2); color: var(--text-dim); cursor: pointer; display: inline-flex; align-items: center; justify-content: center; transition: all .15s; flex-shrink: 0; }
    .vp-drawer-thread-btn:hover { background: var(--accent); border-color: var(--accent); color: #fff; }
    .vp-drawer-thread-btn svg { width: 12px; height: 12px; }
    .vp-drawer-empty { padding: 40px 20px; text-align: center; color: var(--text-mute); font-size: 12.5px; }

    /* THEMES */
    .vp-theme-grid { display: grid; grid-template-columns: repeat(7, 1fr); gap: 10px; }
    .vp-theme-swatch { aspect-ratio: 1.5 / 1; border-radius: 12px; cursor: pointer; border: 2px solid transparent; position: relative; transition: all .2s; display: flex; align-items: center; justify-content: center; font-size: 10.5px; font-weight: 700; color: #fff; text-shadow: 0 1px 4px rgba(0,0,0,.6); overflow: hidden; text-align: center; padding: 4px; }
    .vp-theme-swatch:hover { transform: translateY(-3px) scale(1.03); }
    .vp-theme-swatch.vp-active { border-color: #fff; box-shadow: 0 0 0 3px rgba(255,255,255,.1), 0 8px 20px rgba(0,0,0,.4); }
    .vp-theme-swatch.vp-active::after { content: '✓'; position: absolute; top: 4px; right: 6px; font-size: 12px; font-weight: 800; }

    .vp-user-card { display: flex; align-items: center; gap: 12px; padding: 12px; border-radius: 12px; background: var(--bg-app); border: 1px solid var(--border); }
    .vp-user-avatar { width: 46px; height: 46px; border-radius: 12px; flex-shrink: 0; overflow: hidden; background: var(--bg-card-2); display: flex; align-items: center; justify-content: center; color: var(--text-dim); font-weight: 700; font-size: 17px; border: 1px solid var(--border-2); }
    .vp-user-avatar img { width: 100%; height: 100%; object-fit: cover; display: block; }
    .vp-user-info { flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 3px; }
    .vp-user-name { font-size: 13.5px; font-weight: 600; color: var(--text); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .vp-user-status { font-size: 11px; color: var(--text-mute); display: flex; align-items: center; gap: 5px; }
    .vp-user-status::before { content: ''; width: 6px; height: 6px; border-radius: 50%; background: var(--text-mute); flex-shrink: 0; }
    .vp-user-status.vp-online::before { background: #34d399; box-shadow: 0 0 6px #34d399; }

    .vp-toggle-row { display: flex; align-items: center; justify-content: space-between; gap: 12px; }
    .vp-toggle-row-info { flex: 1; min-width: 0; }
    .vp-toggle-row-title { font-size: 12.5px; color: var(--text); font-weight: 500; }
    .vp-toggle-row-desc { font-size: 11px; color: var(--text-mute); margin-top: 2px; }

    /* MINI */
    .vp-mini { position: fixed; left: 22px; top: 50%; transform: translateY(-50%) scale(.8); width: 44px; height: 44px; border-radius: 50%; z-index: 2147483645; cursor: pointer; display: none; align-items: center; justify-content: center; background: linear-gradient(135deg, var(--accent-2), var(--accent)); box-shadow: 0 8px 22px -6px var(--accent-glow), inset 0 1px 0 rgba(255,255,255,.2); color: #fff; transition: transform .3s cubic-bezier(.4,0,.2,1), box-shadow .3s; font-family: -apple-system, BlinkMacSystemFont, "SF Pro Text", "Segoe UI", sans-serif; user-select: none; overflow: hidden; }
    .vp-mini.vp-show { display: flex; transform: translateY(-50%) scale(1); }
    .vp-mini.vp-dragging { cursor: grabbing; transition: none; }
    .vp-mini:not(.vp-dragging).vp-show:hover { transform: translateY(-50%) scale(1.08); }
    .vp-mini-logo { position: relative; z-index: 1; display: flex; align-items: center; justify-content: center; pointer-events: none; width: 100%; height: 100%; }
    .vp-mini-logo .vp-logo-img { width: 100%; height: 100%; object-fit: cover; border-radius: 50%; }
    .vp-mini-logo svg { width: 22px; height: 22px; }
    .vp-mini-pulse { position: absolute; inset: -2px; border-radius: 50%; border: 2px solid var(--accent-2); opacity: 0; pointer-events: none; animation: vp-mini-ring 2.2s ease-out infinite; z-index: 2; }
    @keyframes vp-mini-ring { 0% { transform: scale(.9); opacity: .7; } 100% { transform: scale(1.7); opacity: 0; } }
    .vp-mini.vp-alert .vp-mini-pulse { border-color: #f43f5e; animation-duration: 1.3s; }
    .vp-mini.vp-alert { box-shadow: 0 8px 22px -6px rgba(244,63,94,.6); }
    .vp-mini-hint { position: absolute; left: calc(100% + 10px); top: 50%; transform: translateY(-50%) translateX(-6px); background: #050810; border: 1px solid var(--border-2); color: var(--text); padding: 6px 10px; border-radius: 8px; font-size: 11px; white-space: nowrap; opacity: 0; pointer-events: none; transition: all .2s; z-index: 3; }
    .vp-mini:hover .vp-mini-hint { opacity: 1; transform: translateY(-50%) translateX(0); }

    /* TG MODAL */
    .vp-tg-block { margin-top: 4px; padding: 14px; border-radius: 12px; background: linear-gradient(135deg, rgba(41,182,246,.06), rgba(41,182,246,.02)); border: 1px solid rgba(41,182,246,.2); }
    .vp-tg-block-head { display: flex; align-items: center; gap: 12px; margin-bottom: 12px; }
    .vp-tg-block-icon { width: 40px; height: 40px; border-radius: 10px; background: linear-gradient(135deg, #29b6f6, #0288d1); color: #fff; display: flex; align-items: center; justify-content: center; flex-shrink: 0; box-shadow: 0 6px 16px -4px rgba(41,182,246,.5); }
    .vp-tg-block-icon svg { width: 22px; height: 22px; }
    .vp-tg-block-info { flex: 1; min-width: 0; }
    .vp-tg-block-title { font-size: 13px; font-weight: 600; color: var(--text); }
    .vp-tg-block-desc { font-size: 11px; color: var(--text-mute); margin-top: 2px; }
    .vp-tg-status { display: flex; align-items: center; gap: 10px; padding: 10px 12px; border-radius: 10px; background: var(--bg-app); border: 1px solid var(--border); }
    .vp-tg-status.vp-connected { background: rgba(41,182,246,.08); border-color: rgba(41,182,246,.3); }
    .vp-tg-status-dot { width: 8px; height: 8px; border-radius: 50%; background: var(--text-mute); flex-shrink: 0; }
    .vp-tg-status.vp-connected .vp-tg-status-dot { background: #29b6f6; box-shadow: 0 0 8px #29b6f6; animation: vp-dot-pulse 2s ease-in-out infinite; }
    .vp-tg-status-info { flex: 1; min-width: 0; }
    .vp-tg-status-title { font-size: 12px; font-weight: 600; color: var(--text); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .vp-tg-status-desc { font-size: 10.5px; color: var(--text-mute); margin-top: 1px; }
    .vp-tg-status-btn { padding: 6px 12px; border-radius: 8px; background: var(--bg-card-2); border: 1px solid var(--border-2); color: var(--text); font-size: 11px; font-weight: 600; cursor: pointer; font-family: inherit; transition: all .15s; flex-shrink: 0; }
    .vp-tg-status-btn:hover { background: #1c2438; border-color: #354063; }
    .vp-tg-status-btn.vp-primary { background: linear-gradient(135deg, #29b6f6, #0288d1); border-color: #29b6f6; color: #fff; box-shadow: 0 4px 12px -3px rgba(41,182,246,.5); }
    .vp-tg-status-btn.vp-primary:hover { filter: brightness(1.1); }

    .vp-tg-modal { position: absolute; inset: 0; z-index: 200; background: rgba(4, 6, 12, 0.7); backdrop-filter: blur(8px); -webkit-backdrop-filter: blur(8px); display: none; align-items: center; justify-content: center; opacity: 0; transition: opacity .25s; }
    .vp-tg-modal.vp-open { display: flex; }
    .vp-tg-modal.vp-visible { opacity: 1; }
    .vp-tg-modal-card { position: relative; width: 400px; max-width: calc(100% - 40px); padding: 24px; border-radius: 18px; background: var(--bg-card); border: 1px solid var(--border-2); box-shadow: 0 30px 80px -20px rgba(0,0,0,.9); transform: translateY(12px) scale(.97); transition: transform .35s cubic-bezier(.34,1.56,.64,1); }
    .vp-tg-modal.vp-visible .vp-tg-modal-card { transform: none; }
    .vp-tg-modal-close { position: absolute; top: 12px; right: 12px; width: 28px; height: 28px; border-radius: 8px; background: transparent; border: 1px solid transparent; color: var(--text-mute); cursor: pointer; display: flex; align-items: center; justify-content: center; transition: all .15s; }
    .vp-tg-modal-close:hover { background: rgba(248,113,113,.14); color: #f87171; }
    .vp-tg-modal-close svg { width: 14px; height: 14px; }
    .vp-tg-head { display: flex; flex-direction: column; align-items: center; gap: 10px; text-align: center; padding: 4px 0 16px; }
    .vp-tg-icon { width: 64px; height: 64px; border-radius: 18px; background: linear-gradient(135deg, #29b6f6, #0288d1); color: #fff; display: flex; align-items: center; justify-content: center; box-shadow: 0 14px 32px -8px rgba(41,182,246,.6); }
    .vp-tg-icon svg { width: 32px; height: 32px; }
    .vp-tg-icon.vp-tg-icon-success { background: linear-gradient(135deg, #10b981, #059669); box-shadow: 0 14px 32px -8px rgba(16,185,129,.6); }
    .vp-tg-icon.vp-tg-icon-warn { background: linear-gradient(135deg, #f59e0b, #d97706); box-shadow: 0 14px 32px -8px rgba(245,158,11,.6); font-size: 30px; }
    .vp-tg-icon.vp-tg-icon-error { background: linear-gradient(135deg, #ef4444, #dc2626); box-shadow: 0 14px 32px -8px rgba(239,68,68,.6); font-size: 30px; }
    .vp-tg-title { font-size: 18px; font-weight: 700; color: #fff; letter-spacing: -.01em; }
    .vp-tg-sub { font-size: 12.5px; color: var(--text-dim); line-height: 1.5; max-width: 300px; }
    .vp-tg-sub b { color: var(--accent-2); }
    .vp-tg-steps { display: flex; flex-direction: column; gap: 10px; margin: 4px 0 12px; }
    .vp-tg-step { display: flex; gap: 10px; align-items: flex-start; }
    .vp-tg-step-num { width: 22px; height: 22px; border-radius: 50%; background: var(--bg-app); border: 1px solid var(--border-2); color: var(--text-dim); font-size: 11px; font-weight: 700; display: flex; align-items: center; justify-content: center; flex-shrink: 0; margin-top: 1px; }
    .vp-tg-step-text { font-size: 12.5px; color: var(--text); line-height: 1.5; }
    .vp-tg-step-text b { color: var(--accent-2); font-weight: 600; }
    .vp-tg-code { display: flex; align-items: center; gap: 8px; padding: 10px 12px; background: var(--bg-app); border: 1px dashed var(--border-2); border-radius: 10px; margin-bottom: 14px; }
    .vp-tg-code code { flex: 1; font-family: 'JetBrains Mono', 'SF Mono', Consolas, monospace; font-size: 14px; color: #29b6f6; font-weight: 700; letter-spacing: .04em; user-select: all; cursor: pointer; }
    .vp-tg-copy { padding: 5px 10px; border-radius: 7px; background: rgba(41,182,246,.12); border: 1px solid rgba(41,182,246,.3); color: #29b6f6; font-size: 10.5px; font-weight: 700; cursor: pointer; font-family: inherit; transition: all .15s; white-space: nowrap; }
    .vp-tg-copy:hover { background: rgba(41,182,246,.2); }
    .vp-tg-actions { display: flex; gap: 8px; }
    .vp-tg-actions .vp-btn { flex: 1; }
    .vp-tg-btn-primary { background: linear-gradient(135deg, #29b6f6, #0288d1) !important; border-color: #29b6f6 !important; color: #fff !important; box-shadow: 0 6px 16px -4px rgba(41,182,246,.5) !important; text-decoration: none; }
    .vp-tg-btn-primary:hover { filter: brightness(1.1); }
    .vp-tg-waiting { display: flex; align-items: center; justify-content: center; gap: 10px; padding: 14px 0 4px; color: var(--text-dim); font-size: 12px; }
    .vp-tg-waiting-dots { display: flex; gap: 4px; }
    .vp-tg-waiting-dots span { width: 6px; height: 6px; border-radius: 50%; background: #29b6f6; animation: vp-tg-dots 1.2s ease-in-out infinite; }
    .vp-tg-waiting-dots span:nth-child(2) { animation-delay: .2s; }
    .vp-tg-waiting-dots span:nth-child(3) { animation-delay: .4s; }
    @keyframes vp-tg-dots { 0%,100% { opacity: .3; transform: translateY(0); } 50% { opacity: 1; transform: translateY(-3px); } }

    /* TOAST */
    .vp-toast { position: fixed; bottom: 24px; left: 24px; background: #0d0e12; border: 1px solid #2e323e; color: #e6e8ee; border-radius: 10px; padding: 12px 16px; font: 12.5px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; box-shadow: 0 12px 30px rgba(0,0,0,.5); display: flex; align-items: center; gap: 10px; transform: translateY(20px); opacity: 0; transition: transform .3s cubic-bezier(.4,0,.2,1), opacity .3s; z-index: 2147483646; max-width: 340px; }
    .vp-toast.vp-show { transform: none; opacity: 1; }
    `;


    let trackedSections = [];
    let isBusy = false, userProfile = null;
    let shadowRoot = null, hostEl = null;
    let splashEl = null, appEl = null, miniEl = null, backdropEl = null, notifPanelEl = null;
    let drawerEl = null, drawerBackdropEl = null;
    let tvEl = null;
    let tvReplyState = { threadId: null, threadUrl: null, csrf: '' };
    let toastRoot = null;
    let currentTheme = 'blue';
    let currentView = 'home';
    let notifications = [];
    let sectionThreads = {};
    let pcModalEl = null;

    const $ = id => shadowRoot ? shadowRoot.getElementById(id) : null;


    function fetchHtml(url) {
        return new Promise(resolve => {
            chrome.runtime.sendMessage({ type: 'ARZ_FETCH', url }, res => {
                if (chrome.runtime.lastError) return resolve(null);
                if (!res || !res.ok) return resolve(null);
                resolve(res.text);
            });
        });
    }
    function getCsrfToken() {
        try { return document.documentElement?.getAttribute('data-csrf') || ''; } catch { return ''; }
    }
    async function postReply(threadId, message) {
        const csrf = getCsrfToken();
        if (!csrf) return { ok: false, error: 'no_csrf' };
        const url = `${CONFIG.FORUM_ORIGIN}/threads/${threadId}/add-reply`;
        const body = new URLSearchParams();
        body.append('message', message);
        body.append('_xfToken', csrf);
        body.append('_xfResponseType', 'json');
        try {
            const res = await fetch(url, {
                method: 'POST', credentials: 'include',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8', 'X-Requested-With': 'XMLHttpRequest' },
                body: body.toString()
            });
            if (!res.ok) return { ok: false, error: 'HTTP ' + res.status };
            const data = await res.json().catch(() => ({}));
            return { ok: true, data };
        } catch (e) { return { ok: false, error: String(e) }; }
    }


    function showToast(text, type = 'success') {
        if (!toastRoot) return;
        const el = document.createElement('div');
        el.className = 'vp-toast';
        el.innerHTML = `
            <span style="width:6px;height:6px;border-radius:50%;background:${type === 'error' ? '#f87171' : (type === 'warn' ? '#f59e0b' : '#34d399')};flex-shrink:0;box-shadow:0 0 8px currentColor;"></span>
            <span>${escapeHtml(text)}</span>`;
        toastRoot.appendChild(el);
        requestAnimationFrame(() => el.classList.add('vp-show'));
        setTimeout(() => { el.classList.remove('vp-show'); setTimeout(() => el.remove(), 350); }, 2800);
    }


    let notifSeq = 0;
    function addNotification(title, text, type = 'info', icon = '🔔') {
        const n = { id: ++notifSeq, title, text, type, icon, ts: Date.now(), read: false };
        notifications.unshift(n);
        if (notifications.length > 60) notifications = notifications.slice(0, 60);
        Store.set(CONFIG.KEYS.NOTIF, notifications);
        updateBellBadge();
        if (notifPanelEl?.classList.contains('vp-open')) renderNotifList();
        return n;
    }
    function updateBellBadge() {
        const el = $('vp-bell-badge');
        if (!el) return;
        const unread = notifications.filter(n => !n.read).length;
        if (unread > 0) { el.textContent = unread > 99 ? '99+' : String(unread); el.classList.add('vp-show'); }
        else el.classList.remove('vp-show');
    }
    function renderNotifList() {
        const listEl = $('vp-notif-list');
        if (!listEl) return;
        if (!notifications.length) {
            listEl.innerHTML = `<div class="vp-notif-empty">Пока нет уведомлений<br><span style="opacity:.6;font-size:11px;">Здесь появятся все события Vegas+</span></div>`;
            return;
        }
        listEl.innerHTML = notifications.map(n => {
            const t = new Date(n.ts);
            const time = `${String(t.getHours()).padStart(2,'0')}:${String(t.getMinutes()).padStart(2,'0')} · ${t.getDate()}.${String(t.getMonth()+1).padStart(2,'0')}`;
            return `
                <div class="vp-notif-item ${n.read ? '' : 'vp-unread'}">
                    <div class="vp-notif-icon vp-${n.type}">${n.icon}</div>
                    <div class="vp-notif-body">
                        <div class="vp-notif-title">${escapeHtml(n.title)}</div>
                        <div class="vp-notif-text">${escapeHtml(n.text)}</div>
                        <div class="vp-notif-time">${time}</div>
                    </div>
                </div>`;
        }).join('');
        setTimeout(() => {
            notifications.forEach(n => n.read = true);
            Store.set(CONFIG.KEYS.NOTIF, notifications);
            updateBellBadge();
        }, 800);
    }
    function toggleNotifPanel() {
        if (!notifPanelEl) return;
        const open = notifPanelEl.classList.toggle('vp-open');
        if (open) { requestAnimationFrame(() => notifPanelEl.classList.add('vp-visible')); renderNotifList(); }
        else notifPanelEl.classList.remove('vp-visible');
    }


    function extractUserId(href) {
        if (!href) return '';
        const m = href.match(/\/members\/(?:[^/]*?\.)?(\d+)\/?/);
        return m ? m[1] : '';
    }
    function readProfileFromPage() {
        const userLink = document.querySelector('.p-navgroup-link--user, .p-account-username');
        const avatarImg = document.querySelector('.p-navgroup-link--user .avatar img, .p-account-username .avatar img, .avatar--xxs img');
        const usernameEl = document.querySelector('.p-navgroup-link--user .p-navgroup-linkText, .p-account-username');
        let username = usernameEl?.textContent.trim() || avatarImg?.getAttribute('alt')?.trim() || '';
        let avatar = avatarImg?.getAttribute('src') || '';
        if (avatar && avatar.startsWith('/')) avatar = CONFIG.FORUM_ORIGIN + avatar;
        let userId = userLink ? extractUserId(userLink.getAttribute('href')) : '';
        if (!userId && avatar) {
            const m = avatar.match(/\/(\d+)\.(?:jpg|png|jpeg|gif|webp)/);
            if (m) userId = m[1];
        }
        const bannerCls = readBannerClasses();
        const role = extractRole(bannerCls);
        if (!username && !userId) return null;
        return { username, avatar, userId, role };
    }
    async function fetchProfileFromAccount() {
        const html = await fetchHtml(CONFIG.FORUM_ORIGIN + '/account/');
        if (!html) return null;
        const doc = new DOMParser().parseFromString(html, 'text/html');
        const titleText = doc.querySelector('.p-title-value')?.textContent || '';
        if (doc.querySelector('form[action*="/login"]') || titleText.includes('Вход')) return null;
        const usernameEl = doc.querySelector('.p-account-username, .p-navgroup-link--user .p-navgroup-linkText');
        const avatarImg = doc.querySelector('.p-account-username .avatar img, .avatar--xxs img, .p-navgroup-link--user .avatar img');
        const userLink = doc.querySelector('.p-navgroup-link--user, .p-account-username');
        const username = usernameEl?.textContent.trim() || avatarImg?.getAttribute('alt')?.trim() || '';
        let avatar = avatarImg?.getAttribute('src') || '';
        if (avatar && avatar.startsWith('/')) avatar = CONFIG.FORUM_ORIGIN + avatar;
        let userId = userLink ? extractUserId(userLink.getAttribute('href')) : '';
        if (!userId && avatar) {
            const m = avatar.match(/\/(\d+)\.(?:jpg|png|jpeg|gif|webp)/);
            if (m) userId = m[1];
        }
        if (!username) return null;
        const bannerEl = doc.querySelector('.p-account-username .userBanner, .p-navgroup--member .userBanner, .memberHeader-banners .userBanner');
        const role = extractRole(bannerEl ? String(bannerEl.className || '') : '');
        return { username, avatar, userId, role };
    }
    async function detectProfile() {
        let profile = readProfileFromPage() || await fetchProfileFromAccount();
        if (profile) { userProfile = profile; Store.set(CONFIG.KEYS.PROFILE, profile); }
        else userProfile = null;
        renderTopbarUser();
        return profile;
    }


    const SPLASH_STEPS = [
        { id: 'init', label: 'Инициализация Vegas+' },
        { id: 'auth', label: 'Проходит авторизация в скрипте…' },
        { id: 'prof', label: 'Загрузка профиля пользователя' },
        { id: 'sync', label: 'Синхронизация данных' }
    ];

    function buildParticles(count = 28) {
        let html = '';
        for (let i = 0; i < count; i++) {
            const left = Math.random() * 100;
            const delay = Math.random() * 8;
            const duration = 5 + Math.random() * 5;
            const size = 2 + Math.random() * 3;
            html += `<span class="vp-splash-particle" style="left:${left}%;animation-delay:-${delay}s;animation-duration:${duration}s;width:${size}px;height:${size}px;"></span>`;
        }
        return html;
    }
    function buildSplash() {
        const s = document.createElement('div');
        s.className = 'vp-splash vp-scope';
        s.dataset.theme = currentTheme;
        s.innerHTML = `
            <div class="vp-splash-particles">${buildParticles()}</div>
            <div class="vp-splash-card">
                <div class="vp-splash-logo-wrap">
                    <span class="vp-splash-ring"></span>
                    <span class="vp-splash-ring"></span>
                    <span class="vp-splash-ring"></span>
                    <div class="vp-splash-logo">${LOGO_IMG}</div>
                </div>
                <div class="vp-splash-title">Vegas+</div>
                <div class="vp-splash-tagline">Arizona RP · Admin Tools</div>
                <div class="vp-splash-sub" id="vp-splash-sub">Подготовка к запуску…</div>
                <div class="vp-splash-bar"><div class="vp-splash-bar-fill" id="vp-splash-bar"></div></div>
                <div class="vp-splash-steps" id="vp-splash-steps">
                    ${SPLASH_STEPS.map(s => `
                        <div class="vp-step" data-step="${s.id}">
                            <span class="vp-step-dot"></span><span>${s.label}</span>
                        </div>
                    `).join('')}
                </div>
                <div class="vp-splash-footer"><span class="vp-splash-footer-dot"></span>Vegas+ ${CONFIG.VERSION}</div>
            </div>`;
        return s;
    }
    function setStep(id, state = 'active', subText = null) {
        if (!splashEl) return;
        const el = splashEl.querySelector(`.vp-step[data-step="${id}"]`);
        if (el) {
            el.classList.remove('vp-active', 'vp-done');
            el.classList.add(state === 'done' ? 'vp-done' : 'vp-active');
        }
        if (subText) {
            const sub = splashEl.querySelector('#vp-splash-sub');
            if (sub) sub.innerHTML = subText;
        }
        const idx = SPLASH_STEPS.findIndex(s => s.id === id);
        const bar = splashEl.querySelector('#vp-splash-bar');
        if (bar && idx >= 0) bar.style.width = ((idx + 1) / SPLASH_STEPS.length * 100) + '%';
    }
    async function runSplash() {
        return new Promise(async (resolve) => {
            splashEl.classList.add('vp-show');
            setStep('init', 'active', 'Инициализация <b>Vegas+</b>…');
            await delay(420); setStep('init', 'done');
            setStep('auth', 'active', 'Проходит <b>авторизация в скрипте</b>…');
            await delay(560); setStep('auth', 'done');
            setStep('prof', 'active', 'Чтение <b>профиля пользователя</b>…');
            const prof = await detectProfile();
            await delay(340); setStep('prof', 'done', prof ? `Добро пожаловать, <b>${prof.username}</b>` : 'Вы не авторизованы');
            setStep('sync', 'active', 'Синхронизация <b>данных</b>…');
            await delay(420); setStep('sync', 'done', 'Готово ✓');
            await delay(500);
            splashEl.classList.remove('vp-show');
            splashEl.classList.add('vp-hide');
            setTimeout(() => { splashEl?.remove(); splashEl = null; resolve(); }, 500);
        });
    }


    const ICONS = {
        home: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>`,
        user: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>`,
        flame: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M8.5 14.5A2.5 2.5 0 0 0 11 12c0-1.38-.5-2-1-3-1.072-2.143-.224-4.054 2-6 .5 2.5 2 4.9 4 6.5 2 1.6 3 3.5 3 5.5a7 7 0 1 1-14 0c0-1.153.433-2.294 1-3a2.5 2.5 0 0 0 2.5 2.5z"/></svg>`,
        eye: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7z"/><circle cx="12" cy="12" r="3"/></svg>`,
        cog: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>`,
        chevronRight: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="m9 18 6-6-6-6"/></svg>`,
        chevronDown: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="m6 9 6 6 6-6"/></svg>`,
        refresh: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a9 9 0 1 1-3-6.7L21 8"/><path d="M21 3v5h-5"/></svg>`,
        bell: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/></svg>`,
        discord: `<svg viewBox="0 0 24 24" fill="currentColor"><path d="M20.317 4.369a19.79 19.79 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057 19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028c.462-.63.874-1.295 1.226-1.994a.076.076 0 0 0-.041-.106 13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.062 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.892.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.03zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.956-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.956 2.418-2.157 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.946 2.418-2.157 2.418z"/></svg>`,
        plus: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg>`,
        x: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg>`,
        check: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>`,
        sparkles: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m12 3-1.9 5.8L4 10.6l5.9 1.9L12 18.3l1.9-5.8 5.9-1.9-5.9-1.9z"/><path d="M5 3v4"/><path d="M19 17v4"/><path d="M3 5h4"/><path d="M17 19h4"/></svg>`,
        external: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><path d="M15 3h6v6"/><path d="M10 14 21 3"/></svg>`,
        message: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>`,
        arrowLeft: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>`,
        send: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m22 2-7 20-4-9-9-4Z"/><path d="M22 2 11 13"/></svg>`,
        image: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="18" height="18" x="3" y="3" rx="2" ry="2"/><circle cx="9" cy="9" r="2"/><path d="m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21"/></svg>`,
        paint: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="13.5" cy="6.5" r=".5"/><circle cx="17.5" cy="10.5" r=".5"/><circle cx="8.5" cy="7.5" r=".5"/><circle cx="6.5" cy="12.5" r=".5"/><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.926 0 1.648-.746 1.648-1.688 0-.437-.18-.835-.437-1.125-.29-.289-.438-.652-.438-1.125a1.64 1.64 0 0 1 1.668-1.668h1.996c3.051 0 5.555-2.503 5.555-5.554C21.965 6.012 17.461 2 12 2z"/></svg>`,
        trash: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>`,
        upload: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>`
    };


    function buildApp() {
        const app = document.createElement('div');
        app.className = 'vp-app vp-scope';
        app.dataset.theme = currentTheme;
        app.innerHTML = `
            <aside class="vp-side">
                <div class="vp-side-logo">
                    <div class="vp-side-logo-icon">${LOGO_IMG}</div>
                    <div class="vp-side-logo-text">
                        <div class="vp-side-logo-title">Vegas+</div>
                        <div class="vp-side-logo-version">${CONFIG.VERSION.toUpperCase()}</div>
                    </div>
                </div>
                <div class="vp-side-section">Основное</div>
                <nav class="vp-side-nav">
                    <button class="vp-nav-item vp-active" data-view="home">${ICONS.home} Главная</button>
                    <button class="vp-nav-item" data-view="profile">${ICONS.user} Профиль</button>
                    <button class="vp-nav-item" data-view="monitoring">${ICONS.eye} Мониторинг</button>
                    <button class="vp-nav-item" data-view="flame">${ICONS.flame} Огонёк</button>
                    <button class="vp-nav-item" data-view="admintools">${ICONS.sparkles} Vegas+ AdminTools <span class="vp-dev-chip">DEV</span></button>
                    <button class="vp-nav-item" data-view="settings">${ICONS.cog} Настройки</button>
                </nav>
                <div class="vp-side-bottom">
                    <a class="vp-side-link" href="${CONFIG.LINKS.DISCORD}" target="_blank">${ICONS.discord} Наш Discord</a>
                    <button class="vp-side-collapse" id="vp-collapse">${ICONS.chevronDown} Свернуть панель</button>
                </div>
            </aside>

            <main class="vp-main">
                <header class="vp-topbar">
                    <div class="vp-topbar-left">
                        <button class="vp-topbar-btn" id="vp-refresh" title="Обновить">${ICONS.refresh}</button>
                    </div>
                    <div class="vp-topbar-right">
                        <button class="vp-topbar-btn" id="vp-bell" title="Уведомления">
                            ${ICONS.bell}
                            <span class="vp-bell-badge" id="vp-bell-badge">0</span>
                        </button>
                        <div class="vp-user-chip" id="vp-user-chip">
                            <span class="vp-user-chip-name" id="vp-user-chip-name">Гость</span>
                            <div class="vp-user-chip-avatar" id="vp-user-chip-avatar">?</div>
                        </div>
                    </div>
                </header>
                <div class="vp-content" id="vp-content"></div>
                <div class="vp-notif-panel" id="vp-notif-panel">
                    <div class="vp-notif-head">
                        <span>Уведомления</span>
                        <button class="vp-notif-clear" id="vp-notif-clear">Очистить</button>
                    </div>
                    <div class="vp-notif-list" id="vp-notif-list"></div>
                </div>

                <div class="vp-drawer-backdrop" id="vp-drawer-backdrop"></div>
                <div class="vp-drawer" id="vp-drawer">
                    <div class="vp-drawer-head">
                        <div class="vp-drawer-head-info">
                            <div class="vp-drawer-head-title" id="vp-drawer-title">—</div>
                            <div class="vp-drawer-head-sub" id="vp-drawer-sub">—</div>
                        </div>
                        <button class="vp-drawer-close" id="vp-drawer-close">${ICONS.x}</button>
                    </div>
                    <div class="vp-drawer-actions" id="vp-drawer-actions"></div>
                    <div class="vp-drawer-body" id="vp-drawer-body"></div>
                </div>

                <div class="vp-tv" id="vp-tv">
                    <div class="vp-tv-head">
                        <button class="vp-tv-back" id="vp-tv-back">${ICONS.arrowLeft}</button>
                        <div class="vp-tv-title" id="vp-tv-title">Тема форума</div>
                        <a class="vp-tv-ext" id="vp-tv-ext" href="#" target="_blank">${ICONS.external} На форуме</a>
                    </div>
                    <div class="vp-tv-body" id="vp-tv-body"></div>
                    <div class="vp-tv-reply" id="vp-tv-reply" style="display:none;">
                        <div class="vp-tv-reply-label">Быстрый ответ<span class="vp-tv-reply-badge">BB-code</span></div>
                        <textarea class="vp-tv-reply-textarea" id="vp-tv-reply-text" placeholder="Напиши ответ на тему… (поддерживается BB-code)"></textarea>
                        <div class="vp-tv-reply-actions">
                            <span class="vp-tv-reply-hint">Отправится от твоего аккаунта на форуме</span>
                            <div class="vp-tv-reply-btns">
                                <button class="vp-btn" id="vp-tv-reply-clear">Очистить</button>
                                <button class="vp-btn vp-primary" id="vp-tv-reply-send">${ICONS.send} Отправить</button>
                            </div>
                        </div>
                    </div>
                </div>
            </main>`;
        return app;
    }

    function bindApp() {
        appEl.querySelectorAll('.vp-nav-item[data-view]').forEach(btn => {
            btn.onclick = () => {
                closeDrawer();
                closeThreadViewer();
                appEl.querySelectorAll('.vp-nav-item[data-view]').forEach(b => b.classList.remove('vp-active'));
                btn.classList.add('vp-active');
                currentView = btn.dataset.view;
                renderView();
            };
        });
        $('vp-collapse').onclick = () => collapseToMini();
        $('vp-refresh').onclick = () => { detectProfile(); updateStats(true); };
        $('vp-bell').onclick = () => toggleNotifPanel();
        $('vp-notif-clear').onclick = () => {
            notifications = [];
            Store.set(CONFIG.KEYS.NOTIF, []);
            renderNotifList();
            updateBellBadge();
        };
        drawerBackdropEl = $('vp-drawer-backdrop');
        drawerEl = $('vp-drawer');
        drawerBackdropEl.onclick = () => closeDrawer();
        $('vp-drawer-close').onclick = () => closeDrawer();

        tvEl = $('vp-tv');
        $('vp-tv-back').onclick = () => closeThreadViewer();

        $('vp-tv-reply-clear').onclick = () => {
            const ta = $('vp-tv-reply-text');
            if (ta) ta.value = '';
        };
        $('vp-tv-reply-send').onclick = async () => {
            const ta = $('vp-tv-reply-text');
            const text = ta?.value.trim();
            if (!text) return showToast('Введите текст ответа', 'warn');
            if (!tvReplyState.threadId) return showToast('Не удалось определить тему', 'error');
            const btn = $('vp-tv-reply-send');
            btn.disabled = true;
            btn.innerHTML = 'Отправляю…';
            const res = await postReply(tvReplyState.threadId, text);
            btn.disabled = false;
            btn.innerHTML = `${ICONS.send} Отправить`;
            if (res.ok) {
                showToast('Ответ отправлен!', 'success');
                ta.value = '';
                setTimeout(() => openThreadInside(tvReplyState.threadUrl, true), 800);
            } else {
                const errMap = { 'no_csrf': 'Не удалось получить CSRF-токен. Обнови страницу форума.' };
                showToast('Ошибка: ' + (errMap[res.error] || res.error), 'error');
            }
        };
    }


    function openSectionDrawer(sectionId) {
        const sec = trackedSections.find(s => s.id === sectionId);
        if (!sec) return;
        const threads = sectionThreads[sectionId] || [];
        const openThreads = threads.filter(t => !t.closed);

        $('vp-drawer-title').textContent = sec.title;
        $('vp-drawer-sub').textContent = `${threads.length} ${pluralRu(threads.length, ['жалоба','жалобы','жалоб'])} · открытых: ${openThreads.length}`;
        $('vp-drawer-actions').innerHTML = `
            <button class="vp-btn" id="vp-drawer-refresh">${ICONS.refresh} Обновить</button>
            <a class="vp-btn" href="${sec.url}" target="_blank" style="text-decoration:none;">${ICONS.external} Открыть раздел</a>`;
        $('vp-drawer-refresh').onclick = () => {
            refreshSectionThreads(sectionId).then(() => openSectionDrawer(sectionId));
        };

        const body = $('vp-drawer-body');
        if (!threads.length) {
            body.innerHTML = `<div class="vp-drawer-empty">Нет жалоб в этом разделе<br><span style="opacity:.6;font-size:11px;">Обнови мониторинг</span></div>`;
        } else {
            body.innerHTML = threads.map(t => `
                <div class="vp-drawer-thread ${t.closed ? 'vp-closed' : 'vp-open'}" data-thread-url="${escapeHtml(t.url)}" data-thread-id="${t.id}">
                    <div class="vp-drawer-thread-icon">${t.closed ? ICONS.check : ICONS.message}</div>
                    <div class="vp-drawer-thread-body">
                        <div class="vp-drawer-thread-title">${escapeHtml(t.title || 'Без названия')}</div>
                        <div class="vp-drawer-thread-meta">
                            <span class="vp-drawer-thread-tag ${t.closed ? 'vp-closed' : 'vp-open'}">${t.closed ? 'Закрыта' : 'Открыта'}</span>
                            <span>#${t.id}</span>
                        </div>
                    </div>
                    <div class="vp-drawer-thread-arrow">
                        <button class="vp-drawer-thread-btn" data-open-inside="${escapeHtml(t.url)}" title="Открыть здесь">${ICONS.eye}</button>
                        <a class="vp-drawer-thread-btn" href="${escapeHtml(t.url)}" target="_blank" title="На форуме" style="text-decoration:none;">${ICONS.external}</a>
                    </div>
                </div>`).join('');
            body.querySelectorAll('[data-thread-url]').forEach(row => {
                row.onclick = (e) => {
                    if (e.target.closest('button') || e.target.closest('a')) return;
                    openThreadInside(row.dataset.threadUrl);
                };
            });
            body.querySelectorAll('[data-open-inside]').forEach(btn => {
                btn.onclick = (e) => { e.stopPropagation(); openThreadInside(btn.dataset.openInside); };
            });
        }

        drawerEl.classList.add('vp-open');
        drawerBackdropEl.classList.add('vp-show');
        requestAnimationFrame(() => drawerEl.classList.add('vp-visible'));
    }
    function closeDrawer() {
        if (!drawerEl) return;
        drawerEl.classList.remove('vp-visible');
        drawerBackdropEl.classList.remove('vp-show');
        setTimeout(() => drawerEl.classList.remove('vp-open'), 300);
    }


    function closeThreadViewer() {
        if (!tvEl) return;
        tvEl.classList.remove('vp-visible');
        const reply = $('vp-tv-reply');
        if (reply) reply.style.display = 'none';
        setTimeout(() => {
            tvEl.classList.remove('vp-open');
            const body = $('vp-tv-body');
            if (body) body.innerHTML = '';
        }, 250);
    }
    async function openThreadInside(threadUrl, keepReply = false) {
        if (!tvEl) return;
        const body = $('vp-tv-body');
        const titleEl = $('vp-tv-title');
        const extEl = $('vp-tv-ext');
        const replyEl = $('vp-tv-reply');

        let threadId = '';
        const m = String(threadUrl).match(/\/threads\/(?:[^/]*?\.)?(\d+)\/?/);
        if (m) threadId = m[1];
        tvReplyState.threadId = threadId;
        tvReplyState.threadUrl = threadUrl;
        tvReplyState.csrf = getCsrfToken();

        tvEl.classList.add('vp-open');
        requestAnimationFrame(() => tvEl.classList.add('vp-visible'));
        titleEl.innerHTML = `Загрузка темы…<small>${escapeHtml(threadUrl)}</small>`;
        extEl.href = threadUrl;
        body.innerHTML = `<div class="vp-tv-loading"><div class="vp-tv-spinner"></div>Загружаю тему с форума…</div>`;

        const html = await fetchHtml(threadUrl);
        if (!html) {
            body.innerHTML = `<div class="vp-empty"><div class="vp-empty-text">Не удалось загрузить тему.</div></div>`;
            return;
        }
        const doc = new DOMParser().parseFromString(html, 'text/html');
        const pageTitle = doc.querySelector('.p-title-value')?.textContent.trim() || 'Тема форума';
        const cleanTitle = pageTitle.replace(/^\s*Жалоба\s*/i, '');
        titleEl.innerHTML = `${escapeHtml(cleanTitle)}<small>Встроенный просмотр · ${escapeHtml(threadUrl)}</small>`;

        const posts = doc.querySelectorAll('.message--post');
        if (!posts.length) {
            body.innerHTML = `<div class="vp-empty"><div class="vp-empty-text">Посты не найдены.</div></div>`;
            return;
        }
        const postsHtml = Array.from(posts).map(post => {
            const authorEl = post.querySelector('.message-name a.username, .message-name');
            const author = authorEl?.textContent.trim() || 'Аноним';
            const avatarImg = post.querySelector('.message-avatar img');
            let avatar = avatarImg?.getAttribute('src') || '';
            if (avatar && avatar.startsWith('/')) avatar = CONFIG.FORUM_ORIGIN + avatar;
            const timeEl = post.querySelector('.message-attribution time.u-dt, time.u-dt');
            const time = timeEl?.textContent.trim() || timeEl?.getAttribute('title') || '';
            const bodyEl = post.querySelector('.message-body .bbWrapper, .message-body .bbCodeBlock, .message-body');
            let content = bodyEl?.innerHTML || '';
            content = content
                .replace(/<script[^>]*>[\s\S]*?<\/script>/gi, '')
                .replace(/<iframe[^>]*>[\s\S]*?<\/iframe>/gi, '')
                .replace(/<object[^>]*>[\s\S]*?<\/object>/gi, '')
                .replace(/<embed[^>]*>/gi, '')
                .replace(/\son\w+="[^"]*"/gi, '')
                .replace(/\son\w+='[^']*'/gi, '')
                .replace(/javascript:/gi, '');
            const avatarHtml = avatar ? `<img src="${escapeHtml(avatar)}" alt="">` : escapeHtml(author[0] || '?').toUpperCase();
            return `
                <div class="vp-tv-post">
                    <div class="vp-tv-post-head">
                        <div class="vp-tv-post-avatar">${avatarHtml}</div>
                        <div class="vp-tv-post-author">${escapeHtml(author)}</div>
                        <div class="vp-tv-post-time">${escapeHtml(time)}</div>
                    </div>
                    <div class="vp-tv-post-body">${content}</div>
                </div>`;
        }).join('');
        body.innerHTML = postsHtml;
        if (replyEl) replyEl.style.display = (tvReplyState.csrf && threadId) ? 'flex' : 'none';
        if (keepReply) body.scrollTop = body.scrollHeight;
    }


    async function compressImage(file, maxWidth = 1400, quality = 0.82) {
        return new Promise((resolve) => {
            const reader = new FileReader();
            reader.onload = e => {
                const img = new Image();
                img.onload = () => {
                    const canvas = document.createElement('canvas');
                    let w = img.width, h = img.height;
                    if (w > maxWidth) { h = Math.round(h * maxWidth / w); w = maxWidth; }
                    canvas.width = w; canvas.height = h;
                    const ctx = canvas.getContext('2d');
                    ctx.drawImage(img, 0, 0, w, h);
                    try { resolve(canvas.toDataURL('image/jpeg', quality)); } catch (err) { resolve(null); }
                };
                img.onerror = () => resolve(null);
                img.src = e.target.result;
            };
            reader.onerror = () => resolve(null);
            reader.readAsDataURL(file);
        });
    }
    async function setBannerFromFile(file) {
        if (!file) return;
        if (!file.type.startsWith('image/')) { showToast('Выберите изображение (JPG/PNG)', 'error'); return; }
        if (file.size > 5 * 1024 * 1024) { showToast('Файл слишком большой (максимум 5MB)', 'error'); return; }
        showToast('Обрабатываю изображение…', 'info');
        const dataUrl = await compressImage(file);
        if (!dataUrl) { showToast('Не удалось обработать изображение', 'error'); return; }
        if (dataUrl.length > 4 * 1024 * 1024) { showToast('Изображение слишком большое после сжатия', 'error'); return; }
        try {
            Store.set(CONFIG.KEYS.BANNER, dataUrl);
            showToast('Баннер установлен!', 'success');
            renderView();
            if (pcModalEl?.classList.contains('vp-open')) openProfileCustomizeModal();
        } catch (e) { showToast('Не удалось сохранить баннер', 'error'); }
    }
    function removeBanner() {
        Store.remove(CONFIG.KEYS.BANNER);
        showToast('Баннер удалён', 'success');
        renderView();
        if (pcModalEl?.classList.contains('vp-open')) openProfileCustomizeModal();
    }


    function renderView() {
        const content = $('vp-content');
        if (!content) return;
        if (currentView === 'home') renderHome(content);
        else if (currentView === 'profile') renderProfileView(content);
        else if (currentView === 'monitoring') renderMonitoring(content);
        else if (currentView === 'flame') renderFlameView(content);
        else if (currentView === 'admintools') renderAdminsToolsView(content);
        else if (currentView === 'settings') renderSettingsView(content);
    }
    function renderTopbarUser() {
        if (!appEl) return;
        const nameEl = $('vp-user-chip-name');
        const avatarEl = $('vp-user-chip-avatar');
        if (!nameEl || !avatarEl) return;
        if (userProfile) {
            nameEl.textContent = userProfile.username || 'Гость';
            if (userProfile.avatar) avatarEl.innerHTML = `<img src="${userProfile.avatar}" alt="">`;
            else avatarEl.textContent = (userProfile.username[0] || '?').toUpperCase();
        } else {
            nameEl.textContent = 'Гость';
            avatarEl.textContent = '?';
        }
    }

    function renderHome(content) {
        content.innerHTML = `
            <div class="vp-obt-news">
                <div class="vp-obt-head">
                    <div class="vp-obt-icon">🎉</div>
                    <div class="vp-obt-head-text">
                        <div class="vp-obt-title">Открытое бета-тестирование <span class="vp-obt-badge">ОБТ · LIVE</span></div>
                    </div>
                </div>
                <div class="vp-obt-text">
                    Друзья! Мы запустили <b>открытое бета-тестирование</b> Vegas+ как для игроков,
                    так и для <span class="vp-obt-hl">администрации серверов</span>. Скрипт активно развивается —
                    мы добавляем новые функции, тестируем стабильность и собираем ваши отзывы.
                    <br><br>
                    🐛 Если вы обнаружили <b>баг, ошибку или нестандартное поведение</b> — обязательно
                    сообщите разработчику. Так мы сделаем Vegas+ ещё лучше для всех.
                </div>
                <div class="vp-obt-actions">
                    <a class="vp-btn vp-primary" href="${CONFIG.LINKS.DISCORD}" target="_blank" style="text-decoration:none;">
                        ${ICONS.discord} Сообщить разработчику
                    </a>
                </div>
            </div>

            <div class="vp-online-card">
                <div class="vp-online-icon">👥</div>
                <div class="vp-online-info">
                    <div class="vp-online-label">Пользователей онлайн в Vegas+</div>
                    <div class="vp-online-value">${onlineCounter.value}</div>
                    <div class="vp-online-hint"></div>
                </div>
                <div class="vp-online-status">ONLINE</div>
            </div>`;
    }

    function switchView(view) {
        appEl.querySelectorAll('.vp-nav-item[data-view]').forEach(b => b.classList.remove('vp-active'));
        appEl.querySelector(`.vp-nav-item[data-view="${view}"]`)?.classList.add('vp-active');
        currentView = view;
        renderView();
    }


    function renderProfileView(content) {
        const username = userProfile?.username || 'Гость';
        const letter = (username[0] || '?').toUpperCase();
        const avatarHtml = userProfile?.avatar ? `<img src="${userProfile.avatar}" alt="">` : letter;
        const role = userProfile?.role || { name: 'Arizona RP', icon: '🛡', color: '#8b5cf6' };
        const banner = Store.get(CONFIG.KEYS.BANNER, null);
        const status = Store.get(CONFIG.KEYS.PROFILE_STATUS, '') || '';
        const frame = Store.get(CONFIG.KEYS.PROFILE_FRAME, 'glow') || 'glow';
        const nickColor = Store.get(CONFIG.KEYS.PROFILE_NICK_COLOR, '') || '';
        const chips = Store.get(CONFIG.KEYS.PROFILE_CHIPS, { id: true, sections: true, streak: true }) || { id: true, sections: true, streak: true };

        const frameStyle = (FRAMES[frame]?.css || '').replace(/var\(--accent\)/g, role.color);
        const nickStyle = nickColor ? `color:${nickColor};` : '';

        let bannerStyle = '';
        let heroHasBanner = false;
        if (banner) {
            if (isPresetBanner(banner)) {
                bannerStyle = `background:${banner};`;
            } else {
                bannerStyle = `background-image:url('${banner}');`;
            }
            heroHasBanner = true;
        }

        const chipsHtml = [];
        if (chips.id !== false) chipsHtml.push(`<span class="vp-chip">🆔 ID: <b>${escapeHtml(userProfile?.userId || '—')}</b></span>`);
        if (chips.sections !== false) chipsHtml.push(`<span class="vp-chip">📡 Разделов: <b>${trackedSections.length}</b></span>`);
        if (chips.streak !== false) chipsHtml.push(`<span class="vp-chip">🔥 Огонек: <b>${getFlameDisplay().streak}</b></span>`);

        const f = getFlameDisplay();

        content.innerHTML = `
            <div class="vp-page-title">
                Профиль
                <button class="vp-btn vp-btn-sm vp-primary" id="vp-profile-customize">${ICONS.paint} Кастомизация</button>
            </div>
            <div class="vp-page-sub">Твои данные и внешний вид в Vegas+</div>

            <div class="vp-hero ${heroHasBanner ? 'with-banner' : ''}">
                ${heroHasBanner ? `<div class="vp-hero-banner-bg" style="${bannerStyle}"></div>` : ''}
                <button class="vp-hero-banner-btn" id="vp-profile-banner-quick" title="Установить баннер">
                    ${ICONS.image} ${banner ? 'Изменить баннер' : 'Установить баннер'}
                </button>
                <div class="vp-hero-avatar" style="${frameStyle}">${avatarHtml}</div>
                <div class="vp-hero-body">
                    <div class="vp-hero-name-row">
                        <div class="vp-hero-name" style="${nickStyle}">${escapeHtml(username)}</div>
                        <div class="vp-hero-role" style="background:${hexToRgba(role.color, .15)};color:${role.color};border:1px solid ${hexToRgba(role.color, .4)};">
                            <span class="vp-role-icon">${role.icon}</span>
                            ${escapeHtml(role.name)}
                        </div>
                    </div>
                    ${status ? `<div class="vp-hero-status">${escapeHtml(status)}</div>` : ''}
                    <div class="vp-hero-chips">${chipsHtml.join('')}</div>
                </div>
            </div>

            <div class="vp-profile-stats">
                <div class="vp-profile-stat">
                    <div class="vp-profile-stat-val">${f.streak}</div>
                    <div class="vp-profile-stat-lbl">🔥 Стрик</div>
                </div>
                <div class="vp-profile-stat">
                    <div class="vp-profile-stat-val">${f.best}</div>
                    <div class="vp-profile-stat-lbl">🏆 Рекорд</div>
                </div>
                <div class="vp-profile-stat">
                    <div class="vp-profile-stat-val">${trackedSections.length}</div>
                    <div class="vp-profile-stat-lbl">📡 Разделов</div>
                </div>
            </div>

            <div class="vp-card" style="flex-direction:row;align-items:center;justify-content:space-between;gap:12px;">
                <div style="display:flex;align-items:center;gap:12px;min-width:0;flex:1;">
                    <div class="vp-user-avatar" style="background: linear-gradient(135deg, ${THEMES[currentTheme].accent2}, ${THEMES[currentTheme].accent});">🎨</div>
                    <div style="display:flex;flex-direction:column;gap:3px;min-width:0;">
                        <div class="vp-user-name" style="font-size:13px;">${escapeHtml(THEMES[currentTheme].name)}</div>
                        <div class="vp-user-status vp-online" style="font-size:11px;">Активная тема · ${isTgConnected() ? 'Telegram ✓' : 'Telegram ✗'}</div>
                    </div>
                </div>
                <button class="vp-btn vp-btn-sm" id="vp-profile-go-settings">${ICONS.cog} Настройки</button>
            </div>`;

        $('vp-profile-customize').onclick = () => openProfileCustomizeModal();
        $('vp-profile-banner-quick').onclick = () => openProfileCustomizeModal('banner');
        $('vp-profile-go-settings').onclick = () => switchView('settings');
    }


    function ensurePcModal() {
        if (pcModalEl) return pcModalEl;
        const wrap = document.createElement('div');
        wrap.className = 'vp-pc-modal';
        wrap.innerHTML = `<div class="vp-pc-card" id="vp-pc-card"></div>`;
        appEl.appendChild(wrap);
        wrap.addEventListener('click', e => { if (e.target === wrap) closePcModal(); });
        pcModalEl = wrap;
        return wrap;
    }
    function closePcModal() {
        if (!pcModalEl) return;
        pcModalEl.classList.remove('vp-visible');
        setTimeout(() => pcModalEl?.classList.remove('vp-open'), 250);
    }
    function openProfileCustomizeModal(initialSection = null) {
        ensurePcModal();
        const banner = Store.get(CONFIG.KEYS.BANNER, null);
        const presetId = isPresetBanner(banner) ? banner : null;
        const status = Store.get(CONFIG.KEYS.PROFILE_STATUS, '') || '';
        const frame = Store.get(CONFIG.KEYS.PROFILE_FRAME, 'glow') || 'glow';
        const nickColor = Store.get(CONFIG.KEYS.PROFILE_NICK_COLOR, '') || '';
        const chips = Store.get(CONFIG.KEYS.PROFILE_CHIPS, { id: true, sections: true, streak: true }) || { id: true, sections: true, streak: true };
        const nickColors = ['', '#ffffff', '#60a5fa', '#a78bfa', '#f472b6', '#fb7185', '#fbbf24', '#34d399', '#22d3ee', '#e879f9', '#f97316'];

        let previewStyle = '';
        if (banner) {
            if (isPresetBanner(banner)) previewStyle = `background:${banner};`;
            else previewStyle = `background-image:url('${banner}');background-size:cover;background-position:center;`;
        }

        const card = pcModalEl.querySelector('#vp-pc-card');
        card.innerHTML = `
            <div class="vp-pc-head">
                <div class="vp-pc-title">🎨 Кастомизация профиля</div>
                <button class="vp-pc-close" id="vp-pc-close">${ICONS.x}</button>
            </div>
            <div class="vp-pc-body">
                <div class="vp-pc-section" data-section="banner">
                    <div class="vp-pc-section-title">🖼 Баннер профиля</div>
                    <div class="vp-pc-banner-preview" id="vp-pc-banner-preview" style="${previewStyle}">
                        ${banner ? '' : `<div class="vp-pc-banner-preview-empty">${ICONS.image}<span>Баннер не установлен</span></div>`}
                    </div>
                    <div class="vp-pc-actions">
                        <button class="vp-btn vp-primary" id="vp-pc-banner-upload">${ICONS.upload} Загрузить</button>
                        ${banner ? `<button class="vp-btn" id="vp-pc-banner-remove">${ICONS.trash} Удалить</button>` : ''}
                    </div>
                    <input type="file" id="vp-pc-banner-input" accept="image/*" style="display:none;">
                    <div class="vp-pc-section-title" style="margin-top:4px;">Или выбери готовый градиент</div>
                    <div class="vp-pc-presets">
                        ${BANNER_PRESETS.map(p => `
                            <div class="vp-pc-preset ${presetId === p.css ? 'vp-active' : ''}" data-preset="${escapeHtml(p.css)}" title="${escapeHtml(p.name)}" style="background:${p.css};"></div>
                        `).join('')}
                    </div>
                </div>

                <div class="vp-pc-section" data-section="status">
                    <div class="vp-pc-section-title">📝 Статус</div>
                    <input type="text" class="vp-input" id="vp-pc-status" maxlength="120" placeholder="Например: Я люблю · Arizona RP" value="${escapeHtml(status)}">
                    <div style="font-size:11px;color:var(--text-mute);">Короткая надпись под ником (до 120 символов)</div>
                </div>

                <div class="vp-pc-section" data-section="frame">
                    <div class="vp-pc-section-title">🖼 Рамка аватара</div>
                    <div class="vp-pc-frames">
                        ${Object.entries(FRAMES).map(([key, fr]) => {
                            const style = fr.css.replace(/var\(--accent\)/g, 'var(--accent)');
                            return `
                                <div class="vp-pc-frame ${frame === key ? 'vp-active' : ''}" data-frame="${key}" title="${escapeHtml(fr.name)}">
                                    <div class="vp-pc-frame-demo" style="${style}"></div>
                                </div>`;
                        }).join('')}
                    </div>
                </div>

                <div class="vp-pc-section" data-section="nickcolor">
                    <div class="vp-pc-section-title">✏️ Цвет ника</div>
                    <div class="vp-pc-colors">
                        ${nickColors.map(c => `
                            <div class="vp-pc-color ${nickColor === c ? 'vp-active' : ''}" data-color="${c}"
                                title="${c || 'По умолчанию'}"
                                style="background:${c || 'linear-gradient(135deg,#fff,#8b93a8)'};${!c ? 'border:2px dashed var(--border-2);' : ''}"></div>
                        `).join('')}
                    </div>
                </div>

                <div class="vp-pc-section" data-section="chips">
                    <div class="vp-pc-section-title">🏷️ Отображение чипов</div>
                    <div class="vp-pc-chips-list">
                        <div class="vp-pc-chip-row">
                            <span class="vp-pc-chip-row-label">🆔 ID пользователя</span>
                            <div class="vp-toggle ${chips.id !== false ? 'vp-on' : ''}" data-chip="id"></div>
                        </div>
                        <div class="vp-pc-chip-row">
                            <span class="vp-pc-chip-row-label">📡 Количество разделов</span>
                            <div class="vp-toggle ${chips.sections !== false ? 'vp-on' : ''}" data-chip="sections"></div>
                        </div>
                        <div class="vp-pc-chip-row">
                            <span class="vp-pc-chip-row-label">🔥 Текущий стрик огонька</span>
                            <div class="vp-toggle ${chips.streak !== false ? 'vp-on' : ''}" data-chip="streak"></div>
                        </div>
                    </div>
                </div>
            </div>`;

        card.querySelector('#vp-pc-close').onclick = () => closePcModal();

        const fileInput = card.querySelector('#vp-pc-banner-input');
        const uploadBtn = card.querySelector('#vp-pc-banner-upload');
        if (uploadBtn) uploadBtn.onclick = () => fileInput.click();
        if (fileInput) {
            fileInput.onchange = e => {
                const file = e.target.files?.[0];
                if (file) setBannerFromFile(file);
                e.target.value = '';
            };
        }
        const removeBtn = card.querySelector('#vp-pc-banner-remove');
        if (removeBtn) removeBtn.onclick = () => {
            if (confirm('Удалить баннер профиля?')) removeBanner();
        };
        card.querySelectorAll('.vp-pc-preset').forEach(el => {
            el.onclick = () => {
                const css = el.dataset.preset;
                Store.set(CONFIG.KEYS.BANNER, css);
                showToast('Баннер обновлён!', 'success');
                renderView();
                openProfileCustomizeModal();
            };
        });
        const statusInput = card.querySelector('#vp-pc-status');
        let statusTimer = null;
        if (statusInput) {
            statusInput.oninput = () => {
                clearTimeout(statusTimer);
                statusTimer = setTimeout(() => {
                    Store.set(CONFIG.KEYS.PROFILE_STATUS, statusInput.value.trim());
                    renderView();
                }, 500);
            };
        }
        card.querySelectorAll('.vp-pc-frame').forEach(el => {
            el.onclick = () => {
                Store.set(CONFIG.KEYS.PROFILE_FRAME, el.dataset.frame);
                showToast('Рамка обновлена!', 'success');
                renderView();
                openProfileCustomizeModal();
            };
        });
        card.querySelectorAll('.vp-pc-color').forEach(el => {
            el.onclick = () => {
                const color = el.dataset.color;
                if (color) Store.set(CONFIG.KEYS.PROFILE_NICK_COLOR, color);
                else Store.remove(CONFIG.KEYS.PROFILE_NICK_COLOR);
                renderView();
                openProfileCustomizeModal();
            };
        });
        card.querySelectorAll('.vp-toggle[data-chip]').forEach(el => {
            el.onclick = () => {
                const key = el.dataset.chip;
                const cur = Store.get(CONFIG.KEYS.PROFILE_CHIPS, { id: true, sections: true, streak: true }) || { id: true, sections: true, streak: true };
                cur[key] = !(cur[key] !== false);
                Store.set(CONFIG.KEYS.PROFILE_CHIPS, cur);
                renderView();
                openProfileCustomizeModal();
            };
        });

        pcModalEl.classList.add('vp-open');
        requestAnimationFrame(() => {
            pcModalEl.classList.add('vp-visible');
            if (initialSection) {
                const sec = card.querySelector(`[data-section="${initialSection}"]`);
                if (sec) sec.scrollIntoView({ block: 'start', behavior: 'smooth' });
            }
        });
    }


    function renderMonitoring(content) {
        if (!trackedSections.length) {
            content.innerHTML = `
                <div class="vp-page-title">Мониторинг</div>
                <div class="vp-page-sub">Отслеживаемые разделы форума</div>
                <div class="vp-card"><div class="vp-empty">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>
                    <div class="vp-empty-text">Добавьте разделы в Настройках</div>
                </div></div>`;
            return;
        }
        content.innerHTML = `
            <div class="vp-page-title">Мониторинг</div>
            <div class="vp-page-sub">${trackedSections.length} ${pluralRu(trackedSections.length, ['раздел','раздела','разделов'])} · клик для просмотра жалоб</div>
            <div id="vp-content-list" style="display:flex;flex-direction:column;gap:8px;"></div>`;
        const list = $('vp-content-list');
        list.innerHTML = trackedSections.map(sec => {
            const threads = sectionThreads[sec.id] || [];
            const cnt = threads.length;
            return `
                <div class="vp-row" data-section-id="${sec.id}">
                    <span class="vp-row-title">${escapeHtml(sec.title)}</span>
                    <span class="vp-badge-count ${cnt > 0 ? 'vp-has' : 'vp-clear'}">${cnt}</span>
                    <span style="color:var(--text-mute);flex-shrink:0;">${ICONS.chevronRight}</span>
                </div>`;
        }).join('');
        list.querySelectorAll('.vp-row[data-section-id]').forEach(row => {
            row.onclick = () => openSectionDrawer(row.dataset.sectionId);
        });
        updateStats(true);
    }


    function renderFlameView(content) {
        const f = getFlameDisplay();
        const level = getFlameLevel(f.streak);
        const levelInfo = FLAME_LEVELS[level];
        const thresholds = getFlameThresholds();
        const nextThreshold = level >= 7 ? thresholds[7] : thresholds[level + 1];
        const prevThreshold = thresholds[level];
        const remaining = level >= 7 ? 0 : Math.max(0, nextThreshold - f.streak);
        const pct = level >= 7 ? 100 : Math.max(0, Math.min(100, Math.round(((f.streak - prevThreshold) / Math.max(1, nextThreshold - prevThreshold)) * 100)));

        let sparks = '';
        if (level >= 3) {
            const count = level >= 7 ? 9 : level >= 5 ? 6 : 3;
            sparks = Array.from({ length: count }).map(() => `<span class="vp-flame-spark"></span>`).join('');
        }

        const dayNames = ['Вс', 'Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб'];
        const today = new Date(); today.setHours(0,0,0,0);
        const historySet = new Set(f.history || []);
        const calendar = [];
        for (let i = 6; i >= 0; i--) {
            const d = new Date(today.getTime() - i * 86400000);
            const dk = dateKey(d);
            const on = historySet.has(dk);
            const isToday = i === 0;
            calendar.push(`
                <div class="vp-flame-day ${on ? 'vp-on' : ''} ${isToday ? 'vp-today' : ''}">
                    <div class="vp-flame-day-name">${dayNames[d.getDay()]}</div>
                    <div class="vp-flame-day-icon">🔥</div>
                    <div class="vp-flame-day-date">${String(d.getDate()).padStart(2,'0')}.${String(d.getMonth()+1).padStart(2,'0')}</div>
                </div>`);
        }

        const levelCards = FLAME_LEVELS.slice(1).map(lv => {
            const reached = level >= lv.lvl;
            const active = level === lv.lvl;
            return `
                <div class="vp-flame-level-card ${reached ? 'vp-reached' : ''} ${active ? 'vp-active' : ''}">
                    <div class="vp-flame-level-icon">${lv.icon}</div>
                    <div class="vp-flame-level-name">${lv.lvl} ${lv.name}</div>
                    <div class="vp-flame-level-req">${lv.min}+</div>
                </div>`;
        }).join('');

        const achievements = getFlameAchievements(f.best).map(a => `
            <div class="vp-flame-ach ${a.unlocked ? 'vp-unlocked' : ''}">
                <div class="vp-flame-ach-icon">${a.icon}</div>
                <div class="vp-flame-ach-name">${a.name}</div>
                <div class="vp-flame-ach-req">${a.required}+</div>
            </div>
        `).join('');

        const week = getWeekdayStats(f.history);
        const weekBars = week.names.map((name, i) => {
            const h = Math.round((week.counts[i] / week.max) * 100);
            return `
                <div class="vp-flame-week-col">
                    <div class="vp-flame-week-val">${week.counts[i]}</div>
                    <div class="vp-flame-week-bar" style="height:${Math.max(6, h)}%;"></div>
                    <div class="vp-flame-week-name">${name}</div>
                </div>`;
        }).join('');

        const forecast = getFlameForecast(f.streak);
        const forecastHtml = forecast.done
            ? `<div class="vp-flame-forecast">
                    <div class="vp-flame-forecast-icon">🌋</div>
                    <div class="vp-flame-forecast-body">
                        <div class="vp-flame-forecast-title">Максимальный уровень!</div>
                        <div class="vp-flame-forecast-desc">Ты — <b>Инферно</b>. Продолжай стрик.</div>
                    </div>
               </div>`
            : `<div class="vp-flame-forecast">
                    <div class="vp-flame-forecast-icon">📈</div>
                    <div class="vp-flame-forecast-body">
                        <div class="vp-flame-forecast-title">До «${forecast.name}»</div>
                        <div class="vp-flame-forecast-desc">Ещё <b>${forecast.need}</b> ${pluralRu(forecast.need, ['день','дня','дней'])} · ~<b>${forecast.eta.getDate()}.${String(forecast.eta.getMonth()+1).padStart(2,'0')}</b></div>
                    </div>
               </div>`;

        const btnDisabled = f.checkedToday;
        const btnText = f.checkedToday ? '✓ Отмечено' : '🔥 Отметиться';

        content.innerHTML = `
            <div class="vp-page-title">Огонёк</div>
            <div class="vp-page-sub">Отмечайся каждый день — огонёк растёт до 7 уровней</div>

            <div class="vp-flame-page">
                <div class="vp-flame-visual vp-flame-lv${level}">
                    <div class="vp-flame-halo"></div>
                    <div class="vp-flame-halo vp-flame-halo-2"></div>
                    <div class="vp-flame-glow"></div>
                    ${sparks}
                    <span class="vp-flame-emoji">${level === 0 ? '💀' : level === 1 ? '✨' : level >= 7 ? '🌋' : '🔥'}</span>
                </div>

                <div style="display:flex;flex-direction:column;align-items:center;gap:1px;">
                    <div class="vp-flame-streak-num">${f.streak}</div>
                    <div class="vp-flame-streak-label">
                        ${pluralRu(f.streak, ['день','дня','дней'])} подряд · <b>LVL ${level}/7 · ${levelInfo.name}</b>
                    </div>
                </div>

                <div class="vp-flame-mini-stats">
                    <div class="vp-flame-mini-stat"><b>${f.best}</b><span>Рекорд</span></div>
                    <div class="vp-flame-mini-stat"><b>${f.total}</b><span>Всего</span></div>
                    <div class="vp-flame-mini-stat"><b style="color:${f.checkedToday ? '#34d399' : 'var(--text-mute)'}">${f.checkedToday ? '✓' : '—'}</b><span>Сегодня</span></div>
                </div>

                <div class="vp-flame-progress">
                    <div class="vp-flame-progress-head">
                        <span>Прогресс до LVL <b>${Math.min(7, level + 1)}</b></span>
                        <span>${level >= 7 ? 'МАКС' : remaining + ' ' + pluralRu(remaining, ['д.','д.','д.'])}</span>
                    </div>
                    <div class="vp-flame-progress-bar">
                        <div class="vp-flame-progress-fill" style="width:${pct}%;"></div>
                    </div>
                </div>

                <button class="vp-flame-btn" id="vp-flame-check" ${btnDisabled ? 'disabled' : ''}>
                    ${btnText}
                </button>

                <div class="vp-flame-calendar">${calendar.join('')}</div>

                ${forecastHtml}

                <div class="vp-flame-levels">${levelCards}</div>

                <div class="vp-flame-week">
                    <div class="vp-flame-week-head">
                        <span>Активность по дням недели</span>
                        <b>${(f.history || []).length} отм.</b>
                    </div>
                    <div class="vp-flame-week-bars">${weekBars}</div>
                </div>

                <div class="vp-page-sub" style="margin:2px 0 0;text-align:center;width:100%;font-size:11px;">Достижения</div>
                <div class="vp-flame-achievements">${achievements}</div>
            </div>`;

        $('vp-flame-check')?.addEventListener('click', checkInFlame);
    }


    function renderAdminsToolsView(content) {
        content.innerHTML = `
            <div class="vp-page-title">Vegas+ AdminTools</div>
            <div class="vp-page-sub">Инструменты для администрации серверов</div>

            <div class="vp-at-dev-card">
                <div class="vp-at-dev-icon">⚙️</div>
                <div class="vp-at-dev-body">
                    <div class="vp-at-dev-title">
                        🛠 Проходит ЗБТ
                        <span class="vp-at-dev-badge">CLOSED BETA</span>
                    </div>
                    <div class="vp-at-dev-text">
                        Модуль Vegas+ AdminTools находится в стадии <b>закрытого бета-тестирования</b> (ЗБТ).
                        Сейчас в тестировании участвуют <span class="vp-at-hl">приглашённые тестеры из состава Arizona Games</span> —
                        они проверяют работу новых систем для команд администрации:
                        <b>розыгрыши</b>, <b>рейтинги</b>, <b>конкурсы</b>,
                        <b>random-активности</b> и <b>аудит действий</b>.
                        <br><br>
                        🚀 Публичный доступ к AdminTools будет открыт после завершения тестов.
                        Следите за новостями в <b>Discord</b> — мы обязательно анонсируем дату запуска.
                    </div>
                </div>
            </div>`;
    }


    function renderSettingsView(content) {
        const desktopOn = Store.get(CONFIG.KEYS.DESKTOP_NOTIF, true);
        const tgInfo = getTgInfo();
        const tgConnected = isTgConnected();

        const tgStatusHtml = tgConnected
            ? `<div class="vp-tg-status vp-connected">
                    <span class="vp-tg-status-dot"></span>
                    <div class="vp-tg-status-info">
                        <div class="vp-tg-status-title">Подключено${tgInfo.username ? ' · @' + escapeHtml(tgInfo.username) : ''}</div>
                        <div class="vp-tg-status-desc">Уведомления ${tgInfo.enabled ? 'включены' : 'выключены'}</div>
                    </div>
                    <button class="vp-tg-status-btn" id="vp-tg-reconnect">Переподключить</button>
               </div>`
            : `<div class="vp-tg-status">
                    <span class="vp-tg-status-dot"></span>
                    <div class="vp-tg-status-info">
                        <div class="vp-tg-status-title">Не подключено</div>
                        <div class="vp-tg-status-desc">Бот @${TG_BOT}</div>
                    </div>
                    <button class="vp-tg-status-btn vp-primary" id="vp-tg-connect">Подключить</button>
               </div>`;

        content.innerHTML = `
            <div class="vp-page-title">Настройки</div>
            <div class="vp-page-sub">Персонализация Vegas+</div>

            <div class="vp-card">
                <div class="vp-label">Уведомления</div>
                <div class="vp-toggle-row">
                    <div class="vp-toggle-row-info">
                        <div class="vp-toggle-row-title">Windows-уведомления</div>
                        <div class="vp-toggle-row-desc">Системные уведомления при новой жалобе с твоим ником</div>
                    </div>
                    <div class="vp-toggle ${desktopOn ? 'vp-on' : ''}" id="vp-desktop-toggle"></div>
                </div>

                <div class="vp-tg-block">
                    <div class="vp-tg-block-head">
                        <div class="vp-tg-block-icon">
                            <svg viewBox="0 0 24 24" fill="currentColor"><path d="M9.78 18.65l.28-4.23 7.68-6.92c.34-.31-.07-.46-.52-.19L7.74 13.3 3.64 12c-.88-.25-.89-.86.2-1.3l15.97-6.16c.73-.33 1.43.18 1.15 1.3l-2.72 12.81c-.19.91-.74 1.13-1.5.71L12.6 16.3l-1.99 1.93c-.23.23-.42.42-.83.42z"/></svg>
                        </div>
                        <div class="vp-tg-block-info">
                            <div class="vp-tg-block-title">Telegram-уведомления</div>
                            <div class="vp-tg-block-desc">Мгновенные уведомления в Telegram через @${TG_BOT}</div>
                        </div>
                        ${tgConnected ? `<div class="vp-toggle ${tgInfo.enabled ? 'vp-on' : ''}" id="vp-tg-toggle"></div>` : ''}
                    </div>
                    ${tgStatusHtml}
                </div>
            </div>

            <div class="vp-card">
                <div class="vp-label">Тема оформления (13)</div>
                <div class="vp-theme-grid" id="vp-theme-grid"></div>
            </div>

            <div class="vp-card">
                <div class="vp-label">Профиль</div>
                <div class="vp-user-card" id="vp-user-card"></div>
                <button class="vp-btn vp-primary" id="vp-settings-open-customize">${ICONS.paint} Открыть кастомизацию</button>
            </div>

            <div class="vp-card">
                <div class="vp-label">Отслеживаемые разделы</div>
                <div id="vp-manage-list" style="max-height:240px;overflow-y:auto;display:flex;flex-direction:column;gap:6px;"></div>
                <div style="display:flex;gap:8px;">
                    <input type="text" class="vp-input" id="vp-new-url" placeholder="https://forum.arizona-rp.com/forums/…">
                    <button class="vp-btn vp-primary" id="vp-add" style="flex-shrink:0;padding:9px 14px;">${ICONS.plus}</button>
                </div>
            </div>`;

        renderThemeGrid();
        renderUserCard();
        renderSettingsList();

        $('vp-add').onclick = handleAddSection;
        $('vp-desktop-toggle').onclick = () => {
            const cur = Store.get(CONFIG.KEYS.DESKTOP_NOTIF, true);
            Store.set(CONFIG.KEYS.DESKTOP_NOTIF, !cur);
            renderSettingsView(content);
        };
        $('vp-settings-open-customize').onclick = () => openProfileCustomizeModal();
        if ($('vp-tg-toggle')) $('vp-tg-toggle').onclick = () => toggleTg();
        if ($('vp-tg-connect')) $('vp-tg-connect').onclick = () => connectTelegram();
        if ($('vp-tg-reconnect')) $('vp-tg-reconnect').onclick = () => {
            if (confirm('Переподключить Telegram? Текущий аккаунт будет отключён.')) disconnectTelegram();
        };
    }

    function renderUserCard() {
        const c = $('vp-user-card');
        if (!c) return;
        if (!userProfile) {
            c.innerHTML = `
                <div class="vp-user-avatar">?</div>
                <div class="vp-user-info">
                    <div class="vp-user-name">Гость</div>
                    <div class="vp-user-status">Не авторизован</div>
                </div>
                <a class="vp-btn" href="${CONFIG.FORUM_ORIGIN}/login/" target="_blank" style="text-decoration:none;">Войти</a>`;
            return;
        }
        const letter = (userProfile.username[0] || '?').toUpperCase();
        const av = userProfile.avatar ? `<img src="${userProfile.avatar}" alt="">` : letter;
        const role = userProfile.role || { name: 'Arizona RP', icon: '🛡', color: '#8b5cf6' };
        c.innerHTML = `
            <div class="vp-user-avatar">${av}</div>
            <div class="vp-user-info">
                <div class="vp-user-name">${escapeHtml(userProfile.username)}</div>
                <div class="vp-user-status" style="color:${role.color};">
                    <span style="width:6px;height:6px;border-radius:50%;background:${role.color};box-shadow:0 0 6px ${role.color};display:inline-block;margin-right:5px;"></span>
                    ${role.icon} ${escapeHtml(role.name)}
                </div>
            </div>`;
    }

    function renderThemeGrid() {
        const g = $('vp-theme-grid');
        if (!g) return;
        g.innerHTML = Object.entries(THEMES).map(([key, t]) => `
            <div class="vp-theme-swatch ${key === currentTheme ? 'vp-active' : ''}"
                data-theme="${key}" title="${t.name}"
                style="background: linear-gradient(135deg, ${t.accent2}, ${t.accent});">
                ${escapeHtml(t.name.replace(/^[^\wа-яА-ЯёЁ]+\s*/, ''))}
            </div>`).join('');
        g.querySelectorAll('.vp-theme-swatch').forEach(sw => {
            sw.onclick = () => applyTheme(sw.dataset.theme);
        });
    }

    function applyTheme(key) {
        if (!THEMES[key]) return;
        currentTheme = key;
        Store.set(CONFIG.KEYS.THEME, key);
        [appEl, miniEl, splashEl].forEach(el => { if (el) el.dataset.theme = key; });
        renderThemeGrid();
    }

    function renderSettingsList() {
        const el = $('vp-manage-list');
        if (!el) return;
        if (!trackedSections.length) {
            el.innerHTML = `<div class="vp-empty" style="padding:20px 8px;"><div class="vp-empty-text">Разделы не добавлены</div></div>`;
            return;
        }
        el.innerHTML = trackedSections.map((sec, i) => `
            <div class="vp-row" style="cursor:default;">
                <span class="vp-row-title">${escapeHtml(sec.title)}</span>
                <span class="vp-del" data-idx="${i}">${ICONS.x}</span>
            </div>`).join('');
        el.querySelectorAll('.vp-del').forEach(btn => {
            btn.onclick = () => {
                const removed = trackedSections.splice(+btn.dataset.idx, 1)[0];
                if (removed) delete sectionThreads[removed.id];
                Store.set(CONFIG.KEYS.SECTIONS, trackedSections);
                renderSettingsList();
                updateStats();
            };
        });
    }

    function openApp() {
        if (!appEl || !backdropEl) return;
        backdropEl.classList.add('vp-show');
        appEl.classList.add('vp-open');
        requestAnimationFrame(() => appEl.classList.add('vp-visible'));
        miniEl.classList.remove('vp-show');
        Store.set(CONFIG.KEYS.MODE, 'modal');
        renderView();
        updateStats(true);
    }
    function collapseToMini() {
        if (!appEl || !miniEl || !backdropEl) return;
        closeDrawer();
        closeThreadViewer();
        closePcModal();
        appEl.classList.remove('vp-visible');
        backdropEl.classList.remove('vp-show');
        if (notifPanelEl) notifPanelEl.classList.remove('vp-open', 'vp-visible');
        setTimeout(() => {
            appEl.classList.remove('vp-open');
            miniEl.classList.add('vp-show');
        }, 300);
        Store.set(CONFIG.KEYS.MODE, 'mini');
    }


    async function fetchForumTitle(url) {
        const forumId = (url.match(/\/forums\/(\d+)/) || [])[1] || '???';
        const html = await fetchHtml(url);
        if (!html) return `Раздел #${forumId}`;
        const m = html.match(/<h1 class="p-title-value"[^>]*>([\s\S]*?)<\/h1>/i);
        return m ? m[1].replace(/<[^>]+>/g, '').trim() : `Раздел #${forumId}`;
    }
    async function handleAddSection() {
        const input = $('vp-new-url');
        const url = input.value.trim();
        const m = url.match(/\/forums\/(\d+)/);
        if (!m) return showToast('Некорректная ссылка на раздел', 'error');
        const id = m[1];
        if (trackedSections.some(s => s.id === id)) return showToast('Раздел уже добавлен', 'warn');
        const btn = $('vp-add'); btn.disabled = true;
        const title = await fetchForumTitle(url);
        trackedSections.push({ id, title, url: `${CONFIG.FORUM_ORIGIN}/forums/${id}/` });
        Store.set(CONFIG.KEYS.SECTIONS, trackedSections);
        input.value = ''; btn.disabled = false;
        renderSettingsList();
        updateStats();
        showToast(`Раздел «${title}» добавлен`, 'success');
    }
    async function refreshSectionThreads(sectionId) {
        const sec = trackedSections.find(s => s.id === sectionId);
        if (!sec) return;
        const html = await fetchHtml(sec.url);
        if (!html) return;
        const doc = new DOMParser().parseFromString(html, 'text/html');
        sectionThreads[sectionId] = parseThreadsFromDoc(doc);
    }


    function parseThreadsFromDoc(doc) {
        const out = [];
        doc.querySelectorAll('.structItem--thread:not(.structItem--sticky)').forEach(t => {
            let id = '';
            const cls = t.className || '';
            let m = cls.match(/js-threadListItem-(\d+)/);
            if (m) id = m[1];
            if (!id) {
                const dc = t.getAttribute('data-content') || '';
                const mm = dc.match(/thread-(\d+)/);
                if (mm) id = mm[1];
            }
            if (!id) {
                const a = t.querySelector('a[href*="/threads/"]');
                if (a) {
                    const m2 = (a.getAttribute('href') || '').match(/\.(\d+)\/?/);
                    if (m2) id = m2[1];
                }
            }
            if (!id) return;
            const titleEl = t.querySelector('.structItem-title a[href*="/threads/"]:not([href*="/unread"]):not([href*="/latest"])');
            const title = titleEl?.textContent.trim() || '';
            const href = titleEl?.getAttribute('href') || '';
            const url = href ? (href.startsWith('http') ? href : CONFIG.FORUM_ORIGIN + href) : `${CONFIG.FORUM_ORIGIN}/threads/${id}/`;
            const prefix = t.querySelector('a.labelLink')?.getAttribute('href') || '';
            const pm = prefix.match(/prefix_id=(\d+)/);
            const isClosedPrefix = pm && CONFIG.PREFIX_CLOSED.has(pm[1]);
            const isClosedClass = t.classList.contains('is-prefix17') || t.classList.contains('is-prefix18');
            const isLocked = !!t.querySelector('.structItem-status--locked');
            const closed = !!(isClosedPrefix || isClosedClass || isLocked);
            out.push({ id, title, url, closed });
        });
        return out;
    }
    function extractThreadIdsFromDoc(doc) {
        const ids = new Set();
        doc.querySelectorAll('.structItem--thread:not(.structItem--sticky)').forEach(t => {
            const cls = t.className || '';
            let m = cls.match(/js-threadListItem-(\d+)/);
            if (m) { ids.add(m[1]); return; }
            const dc = t.getAttribute('data-content') || '';
            m = dc.match(/thread-(\d+)/);
            if (m) { ids.add(m[1]); return; }
            const a = t.querySelector('a[href*="/threads/"]');
            if (a) {
                const m2 = (a.getAttribute('href') || '').match(/\.(\d+)\/?/);
                if (m2) ids.add(m2[1]);
            }
        });
        return ids;
    }


    async function updateStats(manual = false) {
        if (!trackedSections.length) {
            window.__vp_lastOpenCount = 0;
            updateMiniCount();
            return;
        }
        if (isBusy && !manual) return;
        isBusy = true;

        const results = [];
        let totalOpen = 0;
        const allCurrentIds = new Set();

        for (let i = 0; i < trackedSections.length; i += CONFIG.BATCH_SIZE) {
            const batch = trackedSections.slice(i, i + CONFIG.BATCH_SIZE);
            const r = await Promise.all(batch.map(async sec => {
                const html = await fetchHtml(sec.url);
                if (!html) return { sec, count: '!', ids: new Set(), threads: [] };
                const doc = new DOMParser().parseFromString(html, 'text/html');
                const threads = doc.querySelectorAll('.structItem--thread');
                let open = 0;
                threads.forEach(t => {
                    const prefix = t.querySelector('a.labelLink')?.getAttribute('href') || '';
                    const m = prefix.match(/prefix_id=(\d+)/);
                    if (m && CONFIG.PREFIX_PENDING.has(m[1])) return;
                    if (m && CONFIG.PREFIX_CLOSED.has(m[1])) return;
                    if (t.querySelector('.structItem-status--locked') ||
                        t.querySelector('.label--green, .label--red, .label--lightGreen')) return;
                    open++;
                });
                const ids = extractThreadIdsFromDoc(doc);
                ids.forEach(id => allCurrentIds.add(id));
                const parsed = parseThreadsFromDoc(doc);
                sectionThreads[sec.id] = parsed;
                return { sec, count: open, ids, threads: parsed };
            }));
            results.push(...r);
            if (i + CONFIG.BATCH_SIZE < trackedSections.length) await delay(200);
        }

        const receivedArr = Store.get(CONFIG.KEYS.RECEIVED_IDS, []) || [];
        const receivedSet = new Set(receivedArr);
        const username = userProfile?.username || '';
        const desktopOn = Store.get(CONFIG.KEYS.DESKTOP_NOTIF, true);
        const tgInfo = getTgInfo();
        const tgOn = isTgConnected() && tgInfo.enabled;

        const allThreads = [];
        results.forEach(res => {
            if (Array.isArray(res.threads)) {
                res.threads.forEach(t => allThreads.push({ ...t, sectionTitle: res.sec.title }));
            }
        });

        if (username) {
            const lower = username.toLowerCase();
            const withMyNick = allThreads.filter(t => (t.title || '').toLowerCase().includes(lower));
            const newForMe = withMyNick.filter(t => !receivedSet.has(t.id));
            if (newForMe.length > 0) {
                const newReceived = [...receivedArr, ...newForMe.map(t => t.id)].slice(-10000);
                Store.set(CONFIG.KEYS.RECEIVED_IDS, newReceived);
                addNotification(`📥 Новые жалобы на ${username}`,
                    `Найдено ${newForMe.length} ${pluralRu(newForMe.length, ['новая жалоба','новые жалобы','новых жалоб'])}`,
                    'info', '📥');
                newForMe.forEach(t => {
                    if (desktopOn) sendDesktopNotification(`🔔 Жалоба на ${username}`, t.title || 'Новая жалоба');
                    if (tgOn) sendTelegramNotification(`🔔 Жалоба на ${username}`,
                        `Раздел: ${t.sectionTitle}\n\n${t.title || 'Новая жалоба'}`, t.url);
                });
            }
        }

        const seenArr = Store.get(CONFIG.KEYS.SEEN_IDS, []) || [];
        const seenSet = new Set(seenArr);
        const brandNewAll = [];
        allCurrentIds.forEach(id => {
            if (!seenSet.has(id)) { brandNewAll.push(id); seenSet.add(id); }
        });
        if (brandNewAll.length > 0) {
            Store.set(CONFIG.KEYS.SEEN_IDS, Array.from(seenSet).slice(-50000));
        }

        if (currentView === 'monitoring') {
            const list = $('vp-content-list');
            if (list) {
                list.innerHTML = trackedSections.map(sec => {
                    const threads = sectionThreads[sec.id] || [];
                    const cnt = threads.length;
                    return `
                        <div class="vp-row" data-section-id="${sec.id}">
                            <span class="vp-row-title">${escapeHtml(sec.title)}</span>
                            <span class="vp-badge-count ${cnt > 0 ? 'vp-has' : 'vp-clear'}">${cnt}</span>
                            <span style="color:var(--text-mute);flex-shrink:0;">${ICONS.chevronRight}</span>
                        </div>`;
                }).join('');
                list.querySelectorAll('.vp-row[data-section-id]').forEach(row => {
                    row.onclick = () => openSectionDrawer(row.dataset.sectionId);
                });
            }
        }

        results.forEach(res => { if (typeof res.count === 'number') totalOpen += res.count; });
        window.__vp_lastOpenCount = totalOpen;
        updateMiniCount();
        isBusy = false;
    }
    function updateMiniCount() {
        if (!miniEl) return;
        const open = window.__vp_lastOpenCount || 0;
        if (open > 0) miniEl.classList.add('vp-alert');
        else miniEl.classList.remove('vp-alert');
    }


    function buildMini() {
        const mini = document.createElement('div');
        mini.className = 'vp-mini vp-scope';
        mini.dataset.theme = currentTheme;
        mini.innerHTML = `
            <span class="vp-mini-pulse"></span>
            <span class="vp-mini-logo">${LOGO_IMG}</span>
            <span class="vp-mini-hint">Vegas+ · клик для открытия</span>`;
        return mini;
    }
    function setupMiniDrag() {
        const saved = Store.get(CONFIG.KEYS.MINI_POS, null);
        if (saved && typeof saved.x === 'number') {
            miniEl.style.left = saved.x + 'px';
            miniEl.style.top = saved.y + 'px';
            miniEl.style.transform = 'scale(1)';
        }
        let drag = null, moved = false;
        miniEl.addEventListener('mousedown', e => {
            if (e.button !== 0) return;
            const r = miniEl.getBoundingClientRect();
            drag = { dx: e.clientX - r.left, dy: e.clientY - r.top };
            moved = false;
            miniEl.classList.add('vp-dragging');
            e.preventDefault();
        });
        document.addEventListener('mousemove', e => {
            if (!drag) return;
            const x = Math.max(0, Math.min(window.innerWidth - miniEl.offsetWidth, e.clientX - drag.dx));
            const y = Math.max(0, Math.min(window.innerHeight - miniEl.offsetHeight, e.clientY - drag.dy));
            if (Math.abs(x - (parseFloat(miniEl.style.left) || 0)) > 2 ||
                Math.abs(y - (parseFloat(miniEl.style.top) || 0)) > 2) moved = true;
            miniEl.style.left = x + 'px';
            miniEl.style.top = y + 'px';
            miniEl.style.transform = 'scale(1)';
        });
        document.addEventListener('mouseup', () => {
            if (!drag) return;
            drag = null;
            miniEl.classList.remove('vp-dragging');
            if (moved) {
                const r = miniEl.getBoundingClientRect();
                Store.set(CONFIG.KEYS.MINI_POS, { x: r.left, y: r.top });
            }
        });
        miniEl.addEventListener('click', e => {
            if (moved) { e.stopPropagation(); return; }
            openApp();
        });
    }

    chrome.runtime.onMessage.addListener(msg => {
        if (msg?.type === 'VEGAS_TOGGLE_WIDGET') {
            if (appEl?.classList.contains('vp-open')) collapseToMini();
            else openApp();
        }
    });

    document.addEventListener('keydown', e => {
        if (e.key === 'Escape') {
            if (pcModalEl?.classList.contains('vp-open')) { closePcModal(); return; }
            if (tvEl?.classList.contains('vp-open')) { closeThreadViewer(); return; }
            if (drawerEl?.classList.contains('vp-open')) { closeDrawer(); return; }
            if (appEl?.classList.contains('vp-open')) collapseToMini();
        }
    });

    document.addEventListener('click', e => {
        if (notifPanelEl?.classList.contains('vp-open')) {
            const path = e.composedPath ? e.composedPath() : [];
            const inside = path.some(el => el === notifPanelEl || el?.id === 'vp-bell');
            if (!inside) {
                notifPanelEl.classList.remove('vp-visible');
                setTimeout(() => notifPanelEl.classList.remove('vp-open'), 200);
            }
        }
    }, true);


    async function init() {
        onlineCounter.init();

        hostEl = document.createElement('div');
        hostEl.id = 'vegas-plus-root';
        hostEl.style.cssText = 'all: initial;';
        document.documentElement.appendChild(hostEl);
        shadowRoot = hostEl.attachShadow({ mode: 'open' });

        const style = document.createElement('style');
        style.textContent = CSS;
        shadowRoot.appendChild(style);

        await Store.init();
        trackedSections = Store.get(CONFIG.KEYS.SECTIONS, []) || [];
        currentTheme = Store.get(CONFIG.KEYS.THEME, 'blue');
        notifications = Store.get(CONFIG.KEYS.NOTIF, []) || [];
        const cached = Store.get(CONFIG.KEYS.PROFILE, null);
        if (cached?.username) userProfile = cached;

        toastRoot = document.createElement('div');
        shadowRoot.appendChild(toastRoot);

        backdropEl = document.createElement('div');
        backdropEl.className = 'vp-backdrop';
        backdropEl.onclick = () => collapseToMini();
        shadowRoot.appendChild(backdropEl);

        appEl = buildApp();
        shadowRoot.appendChild(appEl);
        bindApp();

        notifPanelEl = $('vp-notif-panel');

        miniEl = buildMini();
        shadowRoot.appendChild(miniEl);
        setupMiniDrag();

        const alreadyAuthorized = Store.get(CONFIG.KEYS.AUTHORIZED, false);

        if (!alreadyAuthorized) {
            splashEl = buildSplash();
            splashEl.dataset.theme = currentTheme;
            shadowRoot.appendChild(splashEl);
            await runSplash();
            Store.set(CONFIG.KEYS.AUTHORIZED, true);
            addNotification('Добро пожаловать в Vegas+', `Версия ${CONFIG.VERSION} успешно загружена`, 'success', '🎉');
        } else {
            await detectProfile();
        }

        renderTopbarUser();
        updateBellBadge();

        const flame = getFlameDisplay();
        if (flame.best > 0 && !flame.alive && flame.streak === 0) {
            setTimeout(() => {
                addNotification('🔥 Огонёк погас',
                    `Твой лучший стрик: ${flame.best} дн. Отметься, чтобы зажечь заново!`,
                    'warn', '🔥');
            }, 1200);
        } else if (!flame.checkedToday && flame.alive) {
            setTimeout(() => {
                addNotification('🔥 Не забудь отметиться',
                    `Стрик ${flame.streak} дн. Продолжи его сегодня!`,
                    'info', '🔥');
            }, 1200);
        }

        const mode = Store.get(CONFIG.KEYS.MODE, 'modal');
        if (mode === 'mini') miniEl.classList.add('vp-show');
        else openApp();

        updateStats(true);
        setInterval(updateStats, CONFIG.REFRESH_INTERVAL);
    }

    if (window.top === window.self && !document.getElementById('vegas-plus-root')) {
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', init, { once: true });
        } else {
            init();
        }
    }
})();